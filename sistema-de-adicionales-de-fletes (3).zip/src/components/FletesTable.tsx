import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Check,
  CheckCircle2,
  X,
  ExternalLink,
  Eye,
  Download,
  FileSpreadsheet,
  ChevronLeft,
  ChevronRight,
  UserCheck,
  ArrowUpDown,
} from 'lucide-react';
import { FleteAdicional, EstadoFlete } from '../types';
import { formatCOP, exportFletesToCSV, extractSupportUrls } from '../services/sheetsSync';
import { exportPremiumExcel } from '../services/excelExport';

interface FletesTableProps {
  fletes: FleteAdicional[];
  onQuickApprove: (id: string) => void;
  onQuickReject: (id: string) => void;
  onOpenReview: (flete: FleteAdicional) => void;
  statusFilter: string;
  onStatusFilterChange: (status: string) => void;
  onOpenExcelModal?: () => void;
}

export const FletesTable: React.FC<FletesTableProps> = ({
  fletes,
  onQuickApprove,
  onQuickReject,
  onOpenReview,
  statusFilter,
  onStatusFilterChange,
  onOpenExcelModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [transportadoraFilter, setTransportadoraFilter] = useState('Todas');
  const [placaFilter, setPlacaFilter] = useState('Todas');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState<'fecha' | 'costo' | 'placa' | 'estado'>('fecha');
  const [sortAsc, setSortAsc] = useState(false);
  const pageSize = 10;

  // Extract unique transportadoras & placas
  const transportadoras = useMemo(() => {
    const list = Array.from(new Set(fletes.map(f => f.transportadora).filter(Boolean)));
    return ['Todas', ...list];
  }, [fletes]);

  const placas = useMemo(() => {
    const list = Array.from(new Set(fletes.map(f => f.placa).filter(Boolean))).sort();
    return ['Todas', ...list];
  }, [fletes]);

  const counts = useMemo(() => {
    return {
      Todos: fletes.length,
      Pendiente: fletes.filter(f => f.estado === 'Pendiente').length,
      Aprobado: fletes.filter(f => f.estado === 'Aprobado').length,
      Rechazado: fletes.filter(f => f.estado === 'Rechazado').length,
    };
  }, [fletes]);

  // Filter and sort
  const filteredFletes = useMemo(() => {
    return fletes
      .filter(f => {
        // Status filter
        if (statusFilter !== 'Todos' && f.estado !== statusFilter) return false;
        // Transportadora filter
        if (transportadoraFilter !== 'Todas' && f.transportadora !== transportadoraFilter) return false;
        // Placa filter
        if (placaFilter !== 'Todas' && f.placa !== placaFilter) return false;
        // Search term
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          const matchId = f.id?.toLowerCase().includes(q);
          const matchPlaca = f.placa?.toLowerCase().includes(q);
          const matchTransp = f.transportadora?.toLowerCase().includes(q);
          const matchGuia = f.guia?.toLowerCase().includes(q);
          const matchOrden = f.ordenCarga?.toLowerCase().includes(q);
          const matchMotivo = f.motivo?.toLowerCase().includes(q);
          const matchAdicional = f.adicionalSolicitado?.toLowerCase().includes(q);
          if (
            !matchId &&
            !matchPlaca &&
            !matchTransp &&
            !matchGuia &&
            !matchOrden &&
            !matchMotivo &&
            !matchAdicional
          ) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        let comp = 0;
        if (sortField === 'fecha') {
          comp = a.marcaTemporal.localeCompare(b.marcaTemporal);
        } else if (sortField === 'costo') {
          comp = (a.costoAdicional || 0) - (b.costoAdicional || 0);
        } else if (sortField === 'placa') {
          comp = a.placa.localeCompare(b.placa);
        } else if (sortField === 'estado') {
          comp = a.estado.localeCompare(b.estado);
        }
        return sortAsc ? comp : -comp;
      });
  }, [fletes, statusFilter, transportadoraFilter, placaFilter, searchTerm, sortField, sortAsc]);

  const totalPages = Math.max(1, Math.ceil(filteredFletes.length / pageSize));
  const pagedFletes = filteredFletes.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const toggleSort = (field: 'fecha' | 'costo' | 'placa' | 'estado') => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  const handleExportCSV = () => {
    const csv = exportFletesToCSV(filteredFletes);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `adicionales_fletes_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
      {/* Table Toolbar */}
      <div className="p-4 border-b border-slate-200/80 bg-slate-50/50 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="input-table-search"
            type="text"
            value={searchTerm}
            onChange={e => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Buscar por placa, transportadora, guía, orden o radicado..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
          />
        </div>

        {/* Filter Badges & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Status filter tabs */}
          <div className="flex items-center bg-slate-200/70 p-0.5 rounded-lg text-xs font-medium">
            {(['Todos', 'Pendiente', 'Aprobado', 'Rechazado'] as const).map(st => (
              <button
                key={st}
                onClick={() => {
                  onStatusFilterChange(st);
                  setCurrentPage(1);
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition text-xs cursor-pointer ${
                  statusFilter === st
                    ? st === 'Aprobado'
                      ? 'bg-emerald-600 text-white font-bold shadow-xs'
                      : st === 'Pendiente'
                      ? 'bg-amber-500 text-white font-bold shadow-xs'
                      : st === 'Rechazado'
                      ? 'bg-rose-600 text-white font-bold shadow-xs'
                      : 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>{st}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    statusFilter === st
                      ? 'bg-black/20 text-white'
                      : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {counts[st]}
                </span>
              </button>
            ))}
          </div>

          {/* Placa dropdown */}
          <select
            id="select-filter-placa"
            value={placaFilter}
            onChange={e => {
              setPlacaFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="Todas">Todas las placas</option>
            {placas.filter(p => p !== 'Todas').map(p => (
              <option key={p} value={p}>
                Placa {p}
              </option>
            ))}
          </select>

          {/* Transportadora dropdown */}
          <select
            id="select-filter-transportadora"
            value={transportadoraFilter}
            onChange={e => {
              setTransportadoraFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="Todas">Transp: Todas</option>
            {transportadoras.filter(t => t !== 'Todas').map(t => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          {/* Export Excel Premium (.xlsx) button */}
          <button
            id="btn-export-excel-premium"
            onClick={() => {
              if (onOpenExcelModal) {
                onOpenExcelModal();
              } else {
                exportPremiumExcel(filteredFletes, {
                  fileName: `AJE_Reporte_Fletes_${statusFilter}_${new Date().toISOString().slice(0, 10)}.xlsx`,
                });
              }
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition cursor-pointer"
            title="Descargar libro Excel Premium (.xlsx) con todas las columnas y análisis"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-white" />
            <span>Bajar Excel Premium</span>
            <span className="px-1 py-0.2 rounded text-[9px] bg-amber-400 text-slate-950 font-black">
              XLSX
            </span>
          </button>

          {/* Export CSV button */}
          <button
            id="btn-export-csv"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 text-xs font-medium transition cursor-pointer"
            title="Exportar vista actual a formato CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>CSV</span>
          </button>
        </div>
      </div>

      {/* Banner Informativo cuando se visualizan Aprobados */}
      {statusFilter === 'Aprobado' && (
        <div className="px-4 py-3 bg-emerald-50 border-b border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-emerald-950 flex items-center gap-2">
                <span>Tabla Oficial: Fletes_Aprobados ({counts.Aprobado} fletes liquidados)</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-200/80 text-emerald-900 text-[10px] font-bold">100% Sincronizado</span>
              </p>
              <p className="text-[11px] text-emerald-700">
                Gastos Aprobados Totales: <span className="font-bold font-mono text-emerald-900">{formatCOP(fletes.filter(f => f.estado === 'Aprobado').reduce((a, b) => a + (b.costoAdicional || 0), 0))}</span> &bull; Información oficial auditada AJE Group
              </p>
            </div>
          </div>
          <button
            onClick={() => onOpenExcelModal ? onOpenExcelModal() : exportPremiumExcel(fletes)}
            className="self-start sm:self-auto px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Descargar Hoja Fletes Aprobados (.xlsx)</span>
          </button>
        </div>
      )}

      {/* Table Data */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[11px] tracking-wider">
              <th className="py-3 px-3">Radicado / ID</th>
              <th
                onClick={() => toggleSort('fecha')}
                className="py-3 px-3 cursor-pointer hover:bg-slate-200/50 select-none"
              >
                <div className="flex items-center gap-1">
                  <span>Fecha y Hora</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => toggleSort('placa')}
                className="py-3 px-3 cursor-pointer hover:bg-slate-200/50 select-none"
              >
                <div className="flex items-center gap-1">
                  <span>Vehículo / Placa</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="py-3 px-3">Adicional Solicitado</th>
              <th className="py-3 px-3">Guía / Orden</th>
              <th className="py-3 px-3 max-w-xs">Justificación Operativa</th>
              <th
                onClick={() => toggleSort('costo')}
                className="py-3 px-3 cursor-pointer hover:bg-slate-200/50 select-none text-right"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Costo Adicional</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => toggleSort('estado')}
                className="py-3 px-3 text-center cursor-pointer hover:bg-slate-200/50 select-none"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Estado</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="py-3 px-3 text-center">Acciones Auditoría</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {pagedFletes.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-8 text-center text-slate-400">
                  No se encontraron fletes adicionales con los filtros seleccionados.
                </td>
              </tr>
            ) : (
              pagedFletes.map(flete => (
                <tr
                  key={flete.id}
                  className="hover:bg-slate-50/80 transition-colors group"
                >
                  {/* ID */}
                  <td className="py-3 px-3 whitespace-nowrap font-mono font-medium text-slate-800">
                    <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      {flete.id}
                    </span>
                  </td>

                  {/* Timestamp */}
                  <td className="py-3 px-3 whitespace-nowrap text-slate-600">
                    <span className="font-medium">{flete.marcaTemporal.split(' ')[0]}</span>
                    <span className="block text-[10px] text-slate-400">{flete.marcaTemporal.split(' ')[1]}</span>
                  </td>

                  {/* Vehicle & Carrier */}
                  <td className="py-3 px-3 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-1 rounded font-mono font-bold bg-amber-100 text-amber-900 border border-amber-300 text-xs">
                        {flete.placa}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[11px] border border-slate-200">
                        {flete.transportadora}
                      </span>
                    </div>
                  </td>

                  {/* Tipo Adicional */}
                  <td className="py-3 px-3">
                    <span className="font-medium text-slate-900 block">{flete.adicionalSolicitado}</span>
                  </td>

                  {/* Guia / Orden */}
                  <td className="py-3 px-3 whitespace-nowrap text-slate-600">
                    <div>
                      <span className="text-[10px] text-slate-400">Guía: </span>
                      <span className="font-mono font-medium text-slate-800">{flete.guia || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400">OC: </span>
                      <span className="font-mono text-slate-700">{flete.ordenCarga || 'N/A'}</span>
                    </div>
                  </td>

                  {/* Motivo */}
                  <td className="py-3 px-3 max-w-xs">
                    <p className="line-clamp-2 text-slate-600 text-xs" title={flete.motivo}>
                      {flete.motivo}
                    </p>
                    {(() => {
                      const urls = extractSupportUrls(flete.soportesUrl);
                      if (urls.length === 0) return null;
                      if (urls.length === 1) {
                        return (
                          <a
                            href={urls[0]}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] text-emerald-600 hover:text-emerald-800 font-bold mt-1 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 shadow-2xs"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>Ver Soporte Drive</span>
                          </a>
                        );
                      }
                      return (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {urls.map((u, i) => (
                            <a
                              key={i}
                              href={u}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[10px] text-emerald-700 hover:text-emerald-900 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200"
                              title={`Abrir soporte #${i + 1}`}
                            >
                              <ExternalLink className="w-2.5 h-2.5" />
                              <span>Soporte {i + 1}</span>
                            </a>
                          ))}
                        </div>
                      );
                    })()}
                  </td>

                  {/* Costo */}
                  <td className="py-3 px-3 whitespace-nowrap text-right">
                    <span className="font-bold text-slate-900 text-sm">
                      {formatCOP(flete.costoAdicional)}
                    </span>
                    <span className="block text-[10px] text-slate-500 font-medium">
                      {flete.estado === 'Aprobado' ? (
                        <span className="text-emerald-700">Tarifa auditada</span>
                      ) : flete.estado === 'Rechazado' ? (
                        <span className="text-rose-600">No autorizado</span>
                      ) : (
                        <span className="text-slate-500">Tarifa oficial AJE</span>
                      )}
                    </span>
                  </td>

                  {/* Estado */}
                  <td className="py-3 px-3 whitespace-nowrap text-center">
                    <span
                      className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                        flete.estado === 'Aprobado'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : flete.estado === 'Rechazado'
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200 animate-pulse'
                      }`}
                    >
                      {flete.estado}
                    </span>
                    {flete.revisadoPor && (
                      <span className="block text-[9px] text-slate-400 mt-0.5">
                        {flete.revisadoPor}
                      </span>
                    )}
                  </td>

                  {/* Acciones */}
                  <td className="py-3 px-3 whitespace-nowrap text-center">
                    <div className="flex items-center justify-center gap-1">
                      {/* Review details */}
                      <button
                        onClick={() => onOpenReview(flete)}
                        className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition"
                        title="Ver detalle y auditar"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      {/* Quick Approve */}
                      <button
                        onClick={() => onQuickApprove(flete.id)}
                        disabled={flete.estado === 'Aprobado'}
                        className={`p-1.5 rounded-lg transition ${
                          flete.estado === 'Aprobado'
                            ? 'text-emerald-300 opacity-40 cursor-default'
                            : 'text-emerald-600 hover:bg-emerald-50 hover:text-emerald-700'
                        }`}
                        title="Aprobar adicional"
                      >
                        <Check className="w-4 h-4" />
                      </button>

                      {/* Quick Reject */}
                      <button
                        onClick={() => onQuickReject(flete.id)}
                        disabled={flete.estado === 'Rechazado'}
                        className={`p-1.5 rounded-lg transition ${
                          flete.estado === 'Rechazado'
                            ? 'text-rose-300 opacity-40 cursor-default'
                            : 'text-rose-600 hover:bg-rose-50 hover:text-rose-700'
                        }`}
                        title="Rechazar adicional"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3 border-t border-slate-200/80 bg-slate-50/50 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-600">
        <div>
          Mostrando {filteredFletes.length > 0 ? (currentPage - 1) * pageSize + 1 : 0} a{' '}
          {Math.min(currentPage * pageSize, filteredFletes.length)} de {filteredFletes.length} solicitudes
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded border border-slate-300 hover:bg-slate-100 disabled:opacity-40"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-2 font-medium">
            Página {currentPage} de {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded border border-slate-300 hover:bg-slate-100 disabled:opacity-40"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
