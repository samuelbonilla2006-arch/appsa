import React, { useState, useEffect } from 'react';
import {
  X,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  DollarSign,
  ShieldCheck,
  User,
  Truck,
  FileText,
  Sparkles,
  Copy,
  Check,
  Send,
} from 'lucide-react';
import { FleteAdicional, EstadoFlete } from '../types';
import { formatCOP, safeCopyToClipboard, extractSupportUrls } from '../services/sheetsSync';
import { detectTariff, generateFormalStatement } from '../data/pricingRules';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  flete: FleteAdicional | null;
  defaultAuditorName?: string;
  onSaveReview: (
    id: string,
    estado: EstadoFlete,
    costo: number,
    observaciones: string,
    revisadoPor: string
  ) => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  isOpen,
  onClose,
  flete,
  defaultAuditorName = 'Samuel Bonilla',
  onSaveReview,
}) => {
  const [estado, setEstado] = useState<EstadoFlete>('Pendiente');
  const [costo, setCosto] = useState<number>(85000);
  const [observaciones, setObservaciones] = useState<string>('');
  const [revisadoPor, setRevisadoPor] = useState<string>(defaultAuditorName);

  const detected = flete ? detectTariff(flete.adicionalSolicitado, flete.motivo) : null;

  const [copiedStatement, setCopiedStatement] = useState<boolean>(false);

  useEffect(() => {
    if (flete) {
      setEstado(flete.estado);
      const detectedInfo = detectTariff(flete.adicionalSolicitado, flete.motivo);
      setCosto(flete.costoAdicional || detectedInfo.costo);
      setObservaciones(flete.observaciones || (flete.estado === 'Pendiente' ? detectedInfo.detalleCalculo : ''));
      setRevisadoPor(flete.revisadoPor || defaultAuditorName || 'Samuel Bonilla');
    }
  }, [flete, defaultAuditorName]);

  const formalText = flete
    ? generateFormalStatement(
        flete,
        estado === 'Rechazado' ? 'rechazado' : 'aprobado',
        costo,
        revisadoPor,
        detected || undefined,
        observaciones
      )
    : '';

  const handleCopyStatement = async () => {
    if (formalText) {
      const ok = await safeCopyToClipboard(formalText);
      if (ok) {
        setCopiedStatement(true);
        setTimeout(() => setCopiedStatement(false), 2500);
      }
    }
  };

  if (!isOpen || !flete) return null;

  const handleSave = () => {
    onSaveReview(flete.id, estado, Number(costo), observaciones, revisadoPor);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-amber-400">{flete.id}</span>
                <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300">
                  {flete.marcaTemporal}
                </span>
              </div>
              <h2 className="text-base font-bold">Auditoría y Gestión de Solicitud</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Detail Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">Vehículo / Placa</span>
              <span className="font-mono font-black text-slate-900 text-base">{flete.placa}</span>
              <span className="text-[11px] text-slate-500 block">{flete.transportadora}</span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">Transportadora</span>
              <span className="font-bold text-slate-900 text-sm truncate block">{flete.transportadora}</span>
              <span className="text-[11px] text-slate-500 block">Flota vinculada AJE</span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 col-span-2 sm:col-span-1">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">Guía / Orden</span>
              <span className="font-mono font-bold text-slate-900 text-xs block">Guía: {flete.guia || 'N/A'}</span>
              <span className="font-mono text-[11px] text-slate-600 block">OC: {flete.ordenCarga || 'N/A'}</span>
            </div>
          </div>

          {/* Adicional & Motivo */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <div>
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">Concepto Solicitado</span>
              <span className="font-bold text-slate-900 text-sm">{flete.adicionalSolicitado}</span>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">
                Justificación y Datos Operativos
              </span>
              <p className="text-xs text-slate-700 mt-1 leading-relaxed bg-white p-3 rounded-lg border border-slate-200">
                {flete.motivo}
              </p>
            </div>

            {/* Google Drive Soportes */}
            {(() => {
              const urls = extractSupportUrls(flete.soportesUrl);
              if (urls.length === 0) return null;
              return (
                <div className="pt-2 border-t border-slate-200 mt-2 space-y-1.5">
                  <span className="text-xs font-bold text-slate-700 block">
                    Comprobantes y Soportes ({urls.length}):
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {urls.map((u, idx) => (
                      <a
                        key={idx}
                        href={u}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-300 transition shadow-2xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{urls.length === 1 ? 'Abrir Soporte en Google Drive' : `Abrir Soporte #${idx + 1}`}</span>
                      </a>
                    ))}
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Mini-IA NLP Analysis & Official Pricing Insight */}
          {detected && (
            <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-300 rounded-xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600 animate-pulse" />
                  <span>Cálculo Inteligente Mini-IA (Políticas Oficiales AJE)</span>
                </span>
                <span className="text-xs font-extrabold text-emerald-800 bg-white px-2.5 py-0.5 rounded-full border border-emerald-300 shadow-2xs">
                  {detected.nombreTarifa}
                </span>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed font-medium">
                {detected.detalleCalculo}
              </p>

              {/* Key points tags recognized */}
              {detected.puntosClave && detected.puntosClave.length > 0 && (
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[10px] uppercase font-bold text-slate-500 mr-1">Variables clave:</span>
                  {detected.puntosClave.map((p, idx) => (
                    <span key={idx} className="bg-white px-2 py-0.5 rounded-md text-[10px] font-bold text-emerald-900 border border-emerald-200 shadow-2xs">
                      {p}
                    </span>
                  ))}
                </div>
              )}

              {/* Savings indicator if standby or client difference */}
              {detected.diferenciaAhorro && detected.diferenciaAhorro > 0 && (
                <div className="p-2 rounded-lg bg-emerald-100/80 border border-emerald-300 flex items-center justify-between text-xs text-emerald-950 font-bold">
                  <span>💡 Ahorro AJE por regla del 50%: {formatCOP(detected.diferenciaAhorro)}</span>
                  <span className="text-[11px] font-normal text-emerald-800">
                    Solicitado por conductor: {formatCOP(detected.valorSolicitadoTransportador || 0)}
                  </span>
                </div>
              )}

              <div className="pt-1 flex items-center justify-between">
                <span className="text-xs text-slate-600 font-semibold">Valor oficial sugerido:</span>
                <button
                  type="button"
                  onClick={() => {
                    setCosto(detected.costo);
                    setObservaciones(detected.detalleCalculo);
                  }}
                  className="px-3 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold shadow-xs transition cursor-pointer flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Aplicar {formatCOP(detected.costo)}</span>
                </button>
              </div>
            </div>
          )}

          {/* Audit Controls: Decision */}
          <div className="space-y-4 pt-2 border-t border-slate-200">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Dictamen de Auditoría
            </h3>

            {/* Status Selector */}
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setEstado('Aprobado')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-bold transition ${
                  estado === 'Aprobado'
                    ? 'bg-emerald-500 text-white border-emerald-600 shadow-md ring-2 ring-emerald-300'
                    : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                }`}
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>Aprobar Flete</span>
              </button>

              <button
                type="button"
                onClick={() => setEstado('Pendiente')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-bold transition ${
                  estado === 'Pendiente'
                    ? 'bg-amber-500 text-white border-amber-600 shadow-md ring-2 ring-amber-300'
                    : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50'
                }`}
              >
                <Clock className="w-5 h-5" />
                <span>Mantener Pendiente</span>
              </button>

              <button
                type="button"
                onClick={() => setEstado('Rechazado')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-bold transition ${
                  estado === 'Rechazado'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-md ring-2 ring-rose-300'
                    : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
                }`}
              >
                <XCircle className="w-5 h-5" />
                <span>Rechazar Flete</span>
              </button>
            </div>

            {/* Cost adjustment */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700">
                  Costo Autorizado / Ajustado (COP)
                </label>
                <span className="text-[11px] text-emerald-700 font-bold">
                  {formatCOP(costo)}
                </span>
              </div>

              {/* Official Tariff Quick Chips */}
              <div className="flex flex-wrap gap-1.5 p-2 bg-slate-100 rounded-xl border border-slate-200">
                <span className="text-[10px] font-bold text-slate-500 self-center mr-1">Tarifas AJE:</span>
                <button
                  type="button"
                  onClick={() => setCosto(70000)}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-700 hover:bg-emerald-100 hover:text-emerald-900 border border-slate-200 transition cursor-pointer"
                >
                  1 Auxiliar: $70k
                </button>
                <button
                  type="button"
                  onClick={() => setCosto(140000)}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-700 hover:bg-emerald-100 hover:text-emerald-900 border border-slate-200 transition cursor-pointer"
                >
                  2 Auxiliares: $140k
                </button>
                <button
                  type="button"
                  onClick={() => setCosto(10000)}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-700 hover:bg-emerald-100 hover:text-emerald-900 border border-slate-200 transition cursor-pointer"
                >
                  Ladera Chana: $10k
                </button>
                <button
                  type="button"
                  onClick={() => setCosto(40000)}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-700 hover:bg-emerald-100 hover:text-emerald-900 border border-slate-200 transition cursor-pointer"
                >
                  Ladera NHR: $40k
                </button>
                <button
                  type="button"
                  onClick={() => setCosto(50000)}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-700 hover:bg-emerald-100 hover:text-emerald-900 border border-slate-200 transition cursor-pointer"
                >
                  Ladera Sencillo: $50k
                </button>
                <button
                  type="button"
                  onClick={() => setCosto(340000)}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-700 hover:bg-emerald-100 hover:text-emerald-900 border border-slate-200 transition cursor-pointer"
                >
                  Descargue: $340k
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <input
                    type="number"
                    step="1000"
                    value={costo}
                    onChange={e => setCosto(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <input
                    type="text"
                    value={revisadoPor}
                    onChange={e => setRevisadoPor(e.target.value)}
                    placeholder="Revisor / Auditor"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* Auditor notes */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Observaciones de Auditoría (Motivo de aprobación o causal de rechazo)
              </label>
              <textarea
                value={observaciones}
                onChange={e => setObservaciones(e.target.value)}
                rows={2}
                placeholder="Ej: Aprobado conforme a tabla de fletes por peso mayor a 6 Tn..."
                className="w-full text-xs p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>

            {/* Generador de Dictamen Formal AJE para Notificación */}
            <div className="bg-slate-900 text-slate-100 rounded-xl p-3.5 space-y-2 border border-slate-800">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5 uppercase tracking-wider">
                  <Send className="w-3.5 h-3.5 text-amber-400" />
                  <span>Dictamen Oficial para Transportadora (WhatsApp / Correo)</span>
                </span>
                <button
                  type="button"
                  onClick={handleCopyStatement}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black transition cursor-pointer shadow-xs"
                >
                  {copiedStatement ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-900" />
                      <span>¡Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar Dictamen</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="text-[10px] font-mono text-slate-300 bg-slate-950/80 p-2.5 rounded-lg border border-slate-800/80 whitespace-pre-wrap leading-relaxed max-h-[120px] overflow-y-auto select-all">
                {formalText}
              </pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg transition"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg shadow-sm shadow-indigo-900/20 transition"
          >
            Guardar Dictamen de Auditoría
          </button>
        </div>
      </div>
    </div>
  );
};
