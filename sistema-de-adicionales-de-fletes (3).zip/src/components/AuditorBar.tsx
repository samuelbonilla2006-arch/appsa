import React, { useState } from 'react';
import {
  Users,
  UserCheck,
  Edit2,
  Check,
  Shield,
  HelpCircle,
  ExternalLink,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { AuditorProfile } from '../types';

interface AuditorBarProps {
  auditors: AuditorProfile[];
  activeAuditor: AuditorProfile;
  onSelectAuditor: (auditorId: string) => void;
  onUpdateAuditor: (updated: AuditorProfile) => void;
  onOpenTeamHelp: () => void;
  pendingCount: number;
}

export const AuditorBar: React.FC<AuditorBarProps> = ({
  auditors,
  activeAuditor,
  onSelectAuditor,
  onUpdateAuditor,
  onOpenTeamHelp,
  pendingCount,
}) => {
  const [editingAuditorId, setEditingAuditorId] = useState<string | null>(null);
  const [tempName, setTempName] = useState('');
  const [tempRole, setTempRole] = useState('');

  const startEdit = (auditor: AuditorProfile, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingAuditorId(auditor.id);
    setTempName(auditor.name);
    setTempRole(auditor.role);
  };

  const saveEdit = (auditor: AuditorProfile, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!tempName.trim()) return;
    onUpdateAuditor({
      ...auditor,
      name: tempName.trim(),
      role: tempRole.trim() || auditor.role,
    });
    setEditingAuditorId(null);
  };

  return (
    <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border-b border-slate-800/90 text-white px-4 py-2.5 shadow-sm">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Left: Team indicator & Avatar Stack */}
        <div className="flex items-center gap-3">
          <div className="flex items-center -space-x-1.5 hover:space-x-1 transition-all duration-300 p-1 bg-slate-950/70 rounded-full border border-slate-800 shadow-inner">
            {auditors.map(aud => {
              const isActive = aud.id === activeAuditor.id;
              const initials = aud.name
                .split(' ')
                .map(p => p[0])
                .slice(0, 2)
                .join('')
                .toUpperCase();

              return (
                <div
                  key={aud.id}
                  onClick={() => onSelectAuditor(aud.id)}
                  title={`Cambiar firma activa a: ${aud.name} (${aud.role})`}
                  className={`relative inline-flex h-8 w-8 rounded-full cursor-pointer transition-all duration-200 transform hover:scale-115 hover:z-30 items-center justify-center text-[10px] font-black tracking-tight select-none shadow-sm ${
                    isActive
                      ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-900 z-20 scale-105 shadow-emerald-500/30'
                      : 'ring-1 ring-slate-700/80 opacity-75 hover:opacity-100 hover:ring-indigo-400'
                  } ${aud.avatarColor || 'bg-gradient-to-br from-indigo-600 to-indigo-800 text-white'}`}
                >
                  <span>{initials}</span>
                  {isActive && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-slate-900 animate-pulse" />
                  )}
                </div>
              );
            })}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                <Shield className="w-3 h-3 text-emerald-400" />
                Auditor en Turno
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-xs font-bold font-sans shadow-2xs">
                <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                {activeAuditor.name}
              </span>
              <span className="text-[11px] text-slate-400 hidden sm:inline font-medium">
                &bull; {activeAuditor.role}
              </span>
            </div>
            <p className="text-[11px] text-slate-400/90 leading-tight mt-0.5">
              Trazabilidad corporativa: cada flete aprobado o rechazado queda sellado bajo tu firma en Google Sheets.
            </p>
          </div>
        </div>

        {/* Right: Quick Switch Buttons for the 3 approvers */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950/70 p-1 rounded-xl border border-slate-800 shadow-inner">
            {auditors.map(aud => {
              const isActive = aud.id === activeAuditor.id;
              const isEditing = editingAuditorId === aud.id;

              if (isEditing) {
                return (
                  <div
                    key={aud.id}
                    className="flex items-center gap-1.5 px-2 py-1 bg-slate-900 rounded-lg border border-indigo-500 shadow-xs"
                    onClick={e => e.stopPropagation()}
                  >
                    <input
                      type="text"
                      value={tempName}
                      onChange={e => setTempName(e.target.value)}
                      placeholder="Nombre auditor"
                      className="text-xs bg-slate-800 text-white px-2 py-0.5 rounded border border-slate-700 focus:outline-none w-28 font-medium"
                    />
                    <button
                      onClick={e => saveEdit(aud, e)}
                      className="p-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer transition shadow-2xs"
                      title="Guardar nombre"
                    >
                      <Check className="w-3 h-3" />
                    </button>
                  </div>
                );
              }

              return (
                <div
                  key={aud.id}
                  onClick={() => onSelectAuditor(aud.id)}
                  className={`group relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all duration-150 ${
                    isActive
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs font-bold ring-1 ring-emerald-400/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                  }`}
                  title={`Seleccionar ${aud.name} como auditor en turno`}
                >
                  <span
                    className={`w-2 h-2 rounded-full transition-colors ${
                      isActive ? 'bg-white shadow-xs' : 'bg-slate-500 group-hover:bg-slate-300'
                    }`}
                  />
                  <span>{aud.name.split(' ')[0]}</span>

                  <button
                    onClick={e => startEdit(aud, e)}
                    title={`Editar nombre de ${aud.name}`}
                    className="opacity-0 group-hover:opacity-100 text-slate-300 hover:text-white transition p-0.5 rounded hover:bg-slate-700/60"
                  >
                    <Edit2 className="w-2.5 h-2.5" />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Guide for 3 approvers */}
          <button
            onClick={onOpenTeamHelp}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-950/70 hover:bg-indigo-900/90 border border-indigo-500/30 hover:border-indigo-400/50 text-indigo-300 hover:text-indigo-200 text-xs font-semibold transition cursor-pointer shadow-xs active:scale-95"
            title="Ver cómo colaboramos los 3 aprobadores en simultáneo"
          >
            <Users className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Guía 3 Aprobadores</span>
          </button>
        </div>
      </div>
    </div>
  );
};
