import React, { useState } from 'react';
import { X, Database, Check, RefreshCw, AlertCircle, Link as LinkIcon, ExternalLink, HelpCircle } from 'lucide-react';
import { SheetSyncConfig } from '../types';
import { DEFAULT_SHEET_URL } from '../data/initialData';

interface SheetSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  syncConfig: SheetSyncConfig;
  onUpdateConfig: (newUrl: string, autoSync: boolean, interval: number) => void;
  onTestConnection: () => Promise<void>;
}

export const SheetSettingsModal: React.FC<SheetSettingsModalProps> = ({
  isOpen,
  onClose,
  syncConfig,
  onUpdateConfig,
  onTestConnection,
}) => {
  const [sheetUrl, setSheetUrl] = useState(syncConfig.sheetUrl || DEFAULT_SHEET_URL);
  const [autoSync, setAutoSync] = useState(syncConfig.autoSync ?? true);
  const [intervalSec, setIntervalSec] = useState(syncConfig.syncIntervalSeconds || 30);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);

  if (!isOpen) return null;

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      await onTestConnection();
      setTestResult('success');
    } catch {
      setTestResult('error');
    } finally {
      setTesting(false);
    }
  };

  const handleSave = () => {
    onUpdateConfig(sheetUrl.trim(), autoSync, intervalSec);
    onClose();
  };

  const handleResetDefault = () => {
    setSheetUrl(DEFAULT_SHEET_URL);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 font-bold">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Conexión con Google Sheets & Forms</h2>
              <p className="text-xs text-slate-300">
                Sincronización de respuestas de formulario en tiempo real
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {/* Status banner */}
          <div className="p-3.5 rounded-xl border bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
              <div>
                <p className="text-xs font-bold text-slate-800">Conexión en Tiempo Real Activa</p>
                <p className="text-[11px] text-slate-500">
                  {syncConfig.lastSyncTime ? `Última sincronización: ${syncConfig.lastSyncTime}` : 'Listo para sincronizar'}
                </p>
              </div>
            </div>
            <button
              onClick={handleTest}
              disabled={testing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
              <span>Probar Enlace</span>
            </button>
          </div>

          {testResult === 'success' && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Conexión exitosa. El Google Sheet responde y los datos están sincronizados.</span>
            </div>
          )}

          {testResult === 'error' && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>No se pudo leer el CSV. Asegúrate de que el documento esté publicado en la web en formato CSV.</span>
            </div>
          )}

          {/* URL Input */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700">
                Enlace Publicado del Google Sheet (Formato CSV)
              </label>
              <button
                type="button"
                onClick={handleResetDefault}
                className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold"
              >
                Restablecer URL oficial AJE
              </button>
            </div>
            <div className="relative">
              <LinkIcon className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={sheetUrl}
                onChange={e => setSheetUrl(e.target.value)}
                placeholder="https://docs.google.com/spreadsheets/d/e/2PACX-.../pub?output=csv"
                className="w-full text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Auto Sync Settings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoSync}
                  onChange={e => setAutoSync(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
                />
                <span className="text-xs font-bold text-slate-800">Auto-sincronizar en segundo plano</span>
              </label>
              <p className="text-[11px] text-slate-500 mt-1 pl-6">
                Consulta automáticamente nuevas respuestas del Google Forms registradas en el Sheet.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Frecuencia de Actualización
              </label>
              <select
                value={intervalSec}
                onChange={e => setIntervalSec(Number(e.target.value))}
                disabled={!autoSync}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium disabled:opacity-50"
              >
                <option value={15}>Cada 15 segundos (Alta frecuencia)</option>
                <option value={30}>Cada 30 segundos (Recomendado)</option>
                <option value={60}>Cada 1 minuto</option>
                <option value={300}>Cada 5 minutos</option>
              </select>
            </div>
          </div>

          {/* Instructions Guide */}
          <div className="bg-indigo-50/70 p-4 rounded-xl border border-indigo-100 text-xs text-indigo-950 space-y-2">
            <h4 className="font-bold flex items-center gap-1.5 text-indigo-900">
              <HelpCircle className="w-4 h-4 text-indigo-600" />
              ¿Cómo conectar un Google Sheet / Forms?
            </h4>
            <ol className="list-decimal pl-4 space-y-1 text-[11px] text-indigo-900/90">
              <li>En Google Sheets, abre el archivo vinculado a tu Google Forms.</li>
              <li>Haz clic en <b>Archivo &gt; Compartir &gt; Publicar en la Web</b>.</li>
              <li>Selecciona la pestaña deseada y en el desplegable elige <b>Valores separados por comas (.csv)</b>.</li>
              <li>Copia el enlace generado (terminado en <code className="font-mono bg-indigo-100 px-1 py-0.5 rounded">pub?output=csv</code>) y pégalo aquí.</li>
            </ol>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg transition"
          >
            Cerrar
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg shadow-sm transition"
          >
            Guardar Configuración
          </button>
        </div>
      </div>
    </div>
  );
};
