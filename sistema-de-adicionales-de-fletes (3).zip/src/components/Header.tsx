import React from 'react';
import {
  RefreshCw,
  PlusCircle,
  FileText,
  Database,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  WifiOff,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { SheetSyncConfig } from '../types';

interface HeaderProps {
  syncConfig: SheetSyncConfig;
  onManualSync: () => void;
  onOpenNewModal: () => void;
  onOpenReportModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenImportModal: () => void;
  onOpenAjeSyncModal: () => void;
  onOpenExcelModal: () => void;
  pendingCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  syncConfig,
  onManualSync,
  onOpenNewModal,
  onOpenReportModal,
  onOpenSettingsModal,
  onOpenImportModal,
  onOpenAjeSyncModal,
  onOpenExcelModal,
  pendingCount,
}) => {
  const getSourceLabel = (source?: string) => {
    switch (source) {
      case 'apps_script':
        return { label: 'Apps Script Web App', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' };
      case 'sheet_csv':
        return { label: 'Google Sheet CSV Export', color: 'bg-blue-500/20 text-blue-300 border-blue-500/40' };
      default:
        return { label: 'Caché Local / Datos precargados', color: 'bg-amber-500/20 text-amber-300 border-amber-500/40' };
    }
  };

  const sourceInfo = getSourceLabel(syncConfig.dataSource);

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between py-3 gap-3">
          {/* Logo and Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold shadow-inner">
              <span className="text-xl tracking-tighter">AF</span>
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-lg font-bold text-white tracking-tight">
                  Control de Adicionales de Fletes
                </h1>

                {/* Persistent Dynamic Live Indicator */}
                {syncConfig.status === 'syncing' ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                    <RefreshCw className="w-3 h-3 animate-spin text-amber-400" />
                    Sincronizando...
                  </span>
                ) : syncConfig.status === 'offline' ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                    <WifiOff className="w-3 h-3 text-slate-400" />
                    Sin conexión: mostrando datos locales ({syncConfig.lastSyncTime || 'N/A'})
                  </span>
                ) : syncConfig.status === 'error' ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                    <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
                    <span>Error de sincronización: {syncConfig.errorMessage || 'Fallo de red'}</span>
                    <button
                      onClick={onManualSync}
                      className="ml-1 px-1.5 py-0.2 rounded bg-rose-600/80 hover:bg-rose-600 text-white font-bold text-[10px] transition cursor-pointer flex items-center gap-1"
                      title="Reintentar sincronización ahora"
                    >
                      <RotateCcw className="w-2.5 h-2.5" /> Reintentar
                    </button>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>En vivo ({syncConfig.lastSyncTime || 'Conectado'})</span>
                    {syncConfig.latencyMs !== undefined && (
                      <span className="text-[10px] bg-emerald-950/80 text-emerald-300 font-mono px-1.5 py-0.5 rounded border border-emerald-600/40 font-bold">
                        ⚡ {syncConfig.latencyMs < 1000 ? `${syncConfig.latencyMs}ms` : `${(syncConfig.latencyMs / 1000).toFixed(1)}s`}
                      </span>
                    )}
                    {syncConfig.autoSync && (
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-200 px-1.5 py-0.5 rounded border border-emerald-500/30 font-semibold hidden sm:inline-flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                        Tiempo Real (15s)
                      </span>
                    )}
                  </span>
                )}
              </div>

              {/* Subtitle & Data Source pill */}
              <div className="flex items-center gap-2 mt-0.5 flex-wrap text-xs text-slate-400">
                <span>AJE Group &bull; Base de Datos Logística</span>
                <span className="text-slate-600">&bull;</span>
                <span className={`px-2 py-0.2 text-[10px] font-mono rounded border ${sourceInfo.color}`}>
                  Fuente: {sourceInfo.label}
                </span>
              </div>
            </div>
          </div>

          {/* Sync status & Actions */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Sheet sync badge */}
            <div
              onClick={onOpenSettingsModal}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 cursor-pointer text-xs transition"
              title="Click para ver o cambiar la URL del Google Sheet / Apps Script"
            >
              {syncConfig.status === 'syncing' ? (
                <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              ) : syncConfig.status === 'offline' ? (
                <WifiOff className="w-3.5 h-3.5 text-slate-400" />
              ) : syncConfig.status === 'error' ? (
                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
              ) : (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <div className="flex flex-col text-left">
                <span className="font-medium text-slate-200">
                  {syncConfig.status === 'syncing' ? 'Sincronizando' : syncConfig.status === 'error' ? 'Con fallo' : syncConfig.status === 'offline' ? 'Offline' : 'Google Sheet'}
                </span>
                <span className="text-[10px] text-slate-400">
                  {syncConfig.lastSyncTime ? `Sync: ${syncConfig.lastSyncTime}` : 'Conectado'}
                </span>
              </div>
            </div>

            {/* Manual Sync Button / Retry */}
            <button
              id="btn-sync-manual"
              onClick={onManualSync}
              disabled={syncConfig.status === 'syncing'}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition disabled:opacity-50 cursor-pointer"
              title="Actualizar datos desde Google Sheets ahora (30s timeout, máx 2 reintentos)"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncConfig.status === 'syncing' ? 'animate-spin text-amber-400' : ''}`} />
              <span className="hidden sm:inline">
                {syncConfig.status === 'error' ? 'Reintentar' : 'Sincronizar'}
              </span>
            </button>

            {/* Import / Paste Sheet button */}
            <button
              id="btn-open-import-csv"
              onClick={onOpenImportModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-xs font-semibold text-emerald-300 transition"
              title="Pegar filas o subir archivo CSV de Google Sheets"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Importar / Pegar Sheet</span>
            </button>

            {/* Settings button */}
            <button
              id="btn-open-settings"
              onClick={onOpenSettingsModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition"
              title="Configurar conexión con Google Sheets y Forms"
            >
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Conexión Sheet</span>
            </button>

            {/* Excel Premium Export button */}
            <button
              id="btn-open-excel-premium"
              onClick={onOpenExcelModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-md shadow-emerald-950/40 border border-emerald-400/40 transition cursor-pointer"
              title="Descargar libro Excel Premium (.xlsx) con toda la información de cada adicional"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-100" />
              <span>Bajar Excel Premium</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] bg-amber-400 text-slate-950 font-black">
                XLSX
              </span>
            </button>

            {/* AJE Sheet Control & Export button */}
            <button
              id="btn-open-aje-sync"
              onClick={onOpenAjeSyncModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 shadow-xs transition cursor-pointer"
              title="Sincronizar con Google Sheets, exportar a Fletes_Aprobados y ver script"
            >
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>Control Sheet AJE</span>
            </button>

            {/* Monthly Reports button */}
            <button
              id="btn-open-reports"
              onClick={onOpenReportModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-xs font-semibold text-amber-300 transition"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Reportes Mensuales</span>
            </button>

            {/* Register New Additional */}
            <button
              id="btn-new-flete"
              onClick={onOpenNewModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm shadow-indigo-900/30 transition"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Registrar Adicional</span>
              {pendingCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[10px] font-bold">
                  {pendingCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
