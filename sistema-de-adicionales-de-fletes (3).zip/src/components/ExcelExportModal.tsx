import React, { useState } from 'react';
import {
  X,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  Layers,
  BarChart3,
  Truck,
  FileText,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { FleteAdicional } from '../types';
import { exportPremiumExcel } from '../services/excelExport';

interface ExcelExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  fletes: FleteAdicional[];
  activeAuditorName?: string;
  activeAuditorEmail?: string;
  onSuccessToast?: (msg: string) => void;
}

export const ExcelExportModal: React.FC<ExcelExportModalProps> = ({
  isOpen,
  onClose,
  fletes,
  activeAuditorName = 'Samuel Bonilla',
  activeAuditorEmail = 'samuel.bonilla.co@ajegroup.com',
  onSuccessToast,
}) => {
  const [filterStatus, setFilterStatus] = useState<'Todos' | 'Aprobado' | 'Pendiente' | 'Rechazado'>('Todos');
  const [includeSummary, setIncludeSummary] = useState(true);
  const [includeDetail, setIncludeDetail] = useState(true);
  const [includeConcept, setIncludeConcept] = useState(true);
  const [includeCarrier, setIncludeCarrier] = useState(true);
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  // Filtrar según selección
  const targetFletes =
    filterStatus === 'Todos' ? fletes : fletes.filter(f => f.estado === filterStatus);

  const totalAprobados = targetFletes.filter(f => f.estado === 'Aprobado').length;
  const montoTotalAprobado = targetFletes
    .filter(f => f.estado === 'Aprobado')
    .reduce((sum, f) => sum + (f.costoAdicional || 0), 0);

  const handleDownload = () => {
    setIsExporting(true);
    try {
      const result = exportPremiumExcel(fletes, {
        auditorName: activeAuditorName,
        auditorEmail: activeAuditorEmail,
        filterStatus,
        includeSummarySheet: includeSummary,
        includeDetailSheet: includeDetail,
        includeConceptBreakdownSheet: includeConcept,
        includeCarrierBreakdownSheet: includeCarrier,
      });

      if (onSuccessToast) {
        onSuccessToast(`Excel Premium descargado con éxito (${result.rowCount} fletes)`);
      }
      setTimeout(() => {
        setIsExporting(false);
        onClose();
      }, 700);
    } catch (err) {
      console.error('Error generando Excel:', err);
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-inner">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold tracking-tight">Descargar Excel Premium Corporativo</h3>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-400 text-slate-950 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  XLSX Multitabla
                </span>
              </div>
              <p className="text-xs text-emerald-200/80">
                AJE Group &bull; Auditoría Oficial y Liquidación Detallada de Adicionales
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-600">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200/80 text-center">
            <div>
              <span className="block text-[11px] text-slate-500 font-medium">Registros a Exportar</span>
              <span className="text-lg font-bold text-slate-900">{targetFletes.length}</span>
              <span className="text-[10px] text-slate-400 block">Fletes en archivo</span>
            </div>
            <div className="border-x border-slate-200 px-2">
              <span className="block text-[11px] text-slate-500 font-medium">Fletes Aprobados</span>
              <span className="text-lg font-bold text-emerald-700">{totalAprobados}</span>
              <span className="text-[10px] text-slate-400 block">Listos para liquidación</span>
            </div>
            <div>
              <span className="block text-[11px] text-slate-500 font-medium">Monto Aprobado (COP)</span>
              <span className="text-lg font-bold text-indigo-700">
                ${montoTotalAprobado.toLocaleString('es-CO')}
              </span>
              <span className="text-[10px] text-slate-400 block">Valor liquidable</span>
            </div>
          </div>

          {/* Scope Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              1. Alcance de los Datos a Exportar
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'Todos', label: 'Todos los Registros', sub: `${fletes.length} fletes`, color: 'slate' },
                {
                  id: 'Aprobado',
                  label: 'Solo Aprobados',
                  sub: `${fletes.filter(f => f.estado === 'Aprobado').length} listos`,
                  color: 'emerald',
                },
                {
                  id: 'Pendiente',
                  label: 'Solo Pendientes',
                  sub: `${fletes.filter(f => f.estado === 'Pendiente').length} por revisar`,
                  color: 'amber',
                },
                {
                  id: 'Rechazado',
                  label: 'Solo Rechazados',
                  sub: `${fletes.filter(f => f.estado === 'Rechazado').length} no procedentes`,
                  color: 'rose',
                },
              ].map(opt => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setFilterStatus(opt.id as any)}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between cursor-pointer ${
                    filterStatus === opt.id
                      ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950 font-semibold ring-2 ring-emerald-500/20'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className="text-xs">{opt.label}</span>
                  <span className="text-[10px] text-slate-500 mt-1">{opt.sub}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Sheets Included */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              2. Pestañas que Contendrá el Archivo Excel (.xlsx)
            </label>
            <div className="space-y-2">
              {/* Sheet 1 */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50/60 transition cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeSummary}
                  onChange={e => setIncludeSummary(e.target.checked)}
                  className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                    <FileText className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Hoja 1: Resumen Ejecutivo & Indicadores Clave (KPIs)</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Membrete oficial AJE, totales, gasto aprobado, ticket promedio, tabla de conceptos y resumen por transportadora.
                  </p>
                </div>
              </label>

              {/* Sheet 2 */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50/60 transition cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeDetail}
                  onChange={e => setIncludeDetail(e.target.checked)}
                  className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                    <Layers className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Hoja 2: Detalle Completo de cada Flete y Adicional</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Base completa fila por fila: ID Consecutivo, Placa, Guía, Orden de Carga, Concepto, Tarifa COP, Fechas, Auditor y Enlace Soporte Drive.
                  </p>
                </div>
              </label>

              {/* Sheet 3 */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50/60 transition cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeConcept}
                  onChange={e => setIncludeConcept(e.target.checked)}
                  className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                    <BarChart3 className="w-3.5 h-3.5 text-amber-600" />
                    <span>Hoja 3: Análisis y Estadísticas por Tipo de Adicional</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Desglose analítico de Auxiliar adicional, Stand by, Descargue, etc. con costos mínimos, promedios y máximos.
                  </p>
                </div>
              </label>

              {/* Sheet 4 */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50/60 transition cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeCarrier}
                  onChange={e => setIncludeCarrier(e.target.checked)}
                  className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                    <Truck className="w-3.5 h-3.5 text-cyan-600" />
                    <span>Hoja 4: Liquidación por Empresa Transportadora</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Consolidado de viajes, placas activas, montos a pagar por empresa transportadora y concepto más cobrado.
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Supervisor Information Box */}
          <div className="p-3 rounded-xl bg-indigo-50/70 border border-indigo-100 flex items-center justify-between">
            <div className="flex items-center gap-2 text-indigo-900">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>
                Certificado por Auditor Logístico: <strong>{activeAuditorName}</strong> ({activeAuditorEmail})
              </span>
            </div>
            <span className="text-[10px] text-indigo-700 bg-indigo-100/80 px-2 py-0.5 rounded font-semibold">
              Formato XLSX Oficial
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-semibold hover:bg-slate-200 transition cursor-pointer"
          >
            Cancelar
          </button>

          <button
            type="button"
            onClick={handleDownload}
            disabled={isExporting || targetFletes.length === 0}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-md shadow-emerald-700/20 transition cursor-pointer disabled:opacity-50"
          >
            {isExporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Generando Libro Excel...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Descargar Excel Premium ({targetFletes.length} fletes)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
