import React from 'react';
import { FleteAdicional } from '../types';
import { formatCOP } from '../services/sheetsSync';
import { Clock, CheckCircle2, XCircle, ExternalLink, Check, X, Eye } from 'lucide-react';

interface KanbanBoardProps {
  fletes: FleteAdicional[];
  onQuickApprove: (id: string) => void;
  onQuickReject: (id: string) => void;
  onOpenReview: (flete: FleteAdicional) => void;
}

export const KanbanBoard: React.FC<KanbanBoardProps> = ({
  fletes,
  onQuickApprove,
  onQuickReject,
  onOpenReview,
}) => {
  const pendientes = fletes.filter(f => f.estado === 'Pendiente');
  const aprobados = fletes.filter(f => f.estado === 'Aprobado');
  const rechazados = fletes.filter(f => f.estado === 'Rechazado');

  const sumPendientes = pendientes.reduce((acc, f) => acc + (f.costoAdicional || 0), 0);
  const sumAprobados = aprobados.reduce((acc, f) => acc + (f.costoAdicional || 0), 0);
  const sumRechazados = rechazados.reduce((acc, f) => acc + (f.costoAdicional || 0), 0);

  const columns = [
    {
      id: 'Pendiente',
      title: 'Pendientes por Aprobar',
      icon: Clock,
      items: pendientes,
      total: sumPendientes,
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-300',
      headerBg: 'bg-amber-500/10 border-amber-200',
      columnBg: 'bg-amber-50/20 border-amber-200/60',
    },
    {
      id: 'Aprobado',
      title: 'Aprobados (Facturables)',
      icon: CheckCircle2,
      items: aprobados,
      total: sumAprobados,
      badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      headerBg: 'bg-emerald-500/10 border-emerald-200',
      columnBg: 'bg-emerald-50/20 border-emerald-200/60',
    },
    {
      id: 'Rechazado',
      title: 'Rechazados / Auditados',
      icon: XCircle,
      items: rechazados,
      total: sumRechazados,
      badgeColor: 'bg-rose-100 text-rose-900 border-rose-300',
      headerBg: 'bg-rose-500/10 border-rose-200',
      columnBg: 'bg-rose-50/20 border-rose-200/60',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {columns.map(col => {
        const Icon = col.icon;
        return (
          <div
            key={col.id}
            className={`rounded-xl border ${col.columnBg} p-3 flex flex-col h-[750px] shadow-xs`}
          >
            {/* Column Header */}
            <div className={`p-3 rounded-lg border ${col.headerBg} bg-white shadow-xs mb-3`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-slate-700" />
                  <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800">
                    {col.title}
                  </h3>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${col.badgeColor}`}>
                  {col.items.length}
                </span>
              </div>
              <div className="mt-2 flex items-baseline justify-between border-t border-slate-100 pt-2">
                <span className="text-[11px] text-slate-500">Monto total:</span>
                <span className="text-sm font-bold text-slate-900">{formatCOP(col.total)}</span>
              </div>
            </div>

            {/* Column Cards List */}
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              {col.items.length === 0 ? (
                <div className="h-40 flex items-center justify-center text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-lg">
                  Sin solicitudes en este estado
                </div>
              ) : (
                col.items.map(flete => (
                  <div
                    key={flete.id}
                    className="p-3 bg-white rounded-lg border border-slate-200/90 shadow-xs hover:shadow-md transition group"
                  >
                    {/* Header: ID + Placa */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-[11px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                        {flete.id}
                      </span>
                      <span className="font-mono text-xs font-black bg-amber-100 text-amber-950 px-2 py-0.5 rounded border border-amber-300">
                        {flete.placa}
                      </span>
                    </div>

                    {/* Carrier & Date */}
                    <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="font-semibold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">
                        {flete.transportadora}
                      </span>
                      <span>{flete.marcaTemporal.split(' ')[0]}</span>
                    </div>

                    {/* Additional Requested */}
                    <p className="mt-1 text-xs font-bold text-slate-900">
                      {flete.adicionalSolicitado}
                    </p>

                    {/* Guia / Orden */}
                    <div className="mt-1 text-[11px] text-slate-500 flex items-center gap-2">
                      <span>Guía: <b className="text-slate-700">{flete.guia || 'N/A'}</b></span>
                      <span>OC: <b className="text-slate-700">{flete.ordenCarga || 'N/A'}</b></span>
                    </div>

                    {/* Motivo snippet */}
                    <p className="mt-1.5 text-[11px] text-slate-600 line-clamp-2 bg-slate-50 p-1.5 rounded border border-slate-100">
                      {flete.motivo}
                    </p>

                    {/* Cost & Actions */}
                    <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 block leading-none">Costo Adicional</span>
                        <span className="text-xs font-black text-slate-900">
                          {formatCOP(flete.costoAdicional)}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {flete.soportesUrl && (
                          <a
                            href={flete.soportesUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1 rounded text-sky-600 hover:bg-sky-50"
                            title="Ver soporte Drive"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}

                        <button
                          onClick={() => onOpenReview(flete)}
                          className="p-1 rounded text-slate-600 hover:bg-slate-100"
                          title="Detalles y auditoría"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {flete.estado !== 'Aprobado' && (
                          <button
                            onClick={() => onQuickApprove(flete.id)}
                            className="p-1 rounded text-emerald-600 hover:bg-emerald-50"
                            title="Aprobar"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {flete.estado !== 'Rechazado' && (
                          <button
                            onClick={() => onQuickReject(flete.id)}
                            className="p-1 rounded text-rose-600 hover:bg-rose-50"
                            title="Rechazar"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
