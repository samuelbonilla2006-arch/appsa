import React, { useState } from 'react';
import { X, Upload, ClipboardPaste, Check, AlertCircle, FileSpreadsheet, Sparkles } from 'lucide-react';
import { FleteAdicional } from '../types';
import { parseRawCSVData, saveFletes } from '../services/sheetsSync';

interface ImportCsvModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataImported: (imported: FleteAdicional[]) => void;
}

export const ImportCsvModal: React.FC<ImportCsvModalProps> = ({
  isOpen,
  onClose,
  onDataImported,
}) => {
  const [csvText, setCsvText] = useState('');
  const [parsedCount, setParsedCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleProcessText = (customText?: string) => {
    setError(null);
    const textToProcess = (customText !== undefined ? customText : csvText).trim();
    if (!textToProcess) {
      setError('Por favor pega el contenido CSV o las filas copiadas desde Google Sheets');
      return;
    }

    try {
      const items = parseRawCSVData(textToProcess);
      if (items.length === 0) {
        setError('No se detectaron registros con placas válidas. Verifica que los datos incluyan cabeceras o filas de fletes.');
        return;
      }
      setParsedCount(items.length);
      saveFletes(items);
      onDataImported(items);
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (e: any) {
      setError(e?.message || 'Error al procesar los datos');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const content = evt.target?.result as string;
      if (content) {
        setCsvText(content);
        try {
          const items = parseRawCSVData(content);
          if (items.length > 0) {
            setParsedCount(items.length);
            saveFletes(items);
            onDataImported(items);
            setTimeout(() => {
              onClose();
            }, 1200);
          } else {
            setError('El archivo no contiene filas válidas de fletes adicionales');
          }
        } catch (err: any) {
          setError(err?.message || 'Error al leer el archivo CSV');
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Importar Fletes desde Archivo o Portapapeles</h2>
              <p className="text-xs text-slate-300">
                Carga datos directamente desde Google Sheets respetando las columnas oficiales
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Info */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-700 leading-relaxed">
            <p className="font-bold text-slate-900 mb-1">Formato de Google Sheet reconocido:</p>
            <p className="text-[11px] text-slate-600">
              Marca temporal, Transportadora, Placa, Adicional solicitado, Guía, Orden de Carga, Observaciones, Soportes.
            </p>
          </div>

          {/* File input */}
          <div className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-xl p-4 text-center transition bg-slate-50">
            <input
              type="file"
              id="csv-file-input"
              accept=".csv,text/csv,text/plain"
              onChange={handleFileUpload}
              className="hidden"
            />
            <label
              htmlFor="csv-file-input"
              className="cursor-pointer flex flex-col items-center justify-center gap-1.5"
            >
              <Upload className="w-6 h-6 text-emerald-600" />
              <span className="text-xs font-bold text-slate-800">
                Seleccionar archivo .CSV descargado de Google Sheets
              </span>
              <span className="text-[11px] text-slate-500">
                (En Sheets: Archivo &gt; Descargar &gt; Valores separados por comas .csv)
              </span>
            </label>
          </div>

          {/* Or Paste Raw Text */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-700 flex items-center gap-1">
                <ClipboardPaste className="w-3.5 h-3.5 text-slate-500" />
                <span>O pega aquí las celdas copiadas directamente de tu Sheet:</span>
              </label>
              {csvText && (
                <button
                  type="button"
                  onClick={() => setCsvText('')}
                  className="text-[11px] text-slate-400 hover:text-rose-600"
                >
                  Limpiar texto
                </button>
              )}
            </div>
            <textarea
              value={csvText}
              onChange={e => setCsvText(e.target.value)}
              rows={5}
              placeholder="Pega las filas copiadas desde Google Sheets aquí..."
              className="w-full text-xs font-mono p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {parsedCount !== null && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2 font-semibold">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>¡{parsedCount} fletes adicionales procesados e integrados correctamente al dashboard!</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg transition"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={() => handleProcessText()}
            disabled={!csvText.trim()}
            className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm transition flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Procesar e Integrar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
