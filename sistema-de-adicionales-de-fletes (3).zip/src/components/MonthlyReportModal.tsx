import React, { useState, useMemo } from 'react';
import {
  X,
  Printer,
  Download,
  Calendar,
  DollarSign,
  TrendingUp,
  CheckCircle2,
  XCircle,
  Clock,
  Truck,
  Building2,
  FileSpreadsheet,
} from 'lucide-react';
import { FleteAdicional } from '../types';
import { formatCOP, exportFletesToCSV } from '../services/sheetsSync';

interface MonthlyReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  fletes: FleteAdicional[];
}

export const MonthlyReportModal: React.FC<MonthlyReportModalProps> = ({
  isOpen,
  onClose,
  fletes,
}) => {
  // Extract distinct year-months
  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    fletes.forEach(f => {
      const iso = f.fechaIso || '2026-09-15';
      const ym = iso.slice(0, 7); // e.g. "2026-09"
      set.add(ym);
    });
    const arr = Array.from(set).sort().reverse();
    return arr.length > 0 ? arr : ['2026-09'];
  }, [fletes]);

  const [selectedMonth, setSelectedMonth] = useState<string>(availableMonths[0] || '2026-09');

  // Month names in Spanish
  const formatMonthName = (ym: string) => {
    const [y, m] = ym.split('-');
    const months = [
      'Enero',
      'Febrero',
      'Marzo',
      'Abril',
      'Mayo',
      'Junio',
      'Julio',
      'Agosto',
      'Septiembre',
      'Octubre',
      'Noviembre',
      'Diciembre',
    ];
    const monthIndex = parseInt(m, 10) - 1;
    return `${months[monthIndex] || m} ${y}`;
  };

  // Filter fletes for this month
  const monthFletes = useMemo(() => {
    return fletes.filter(f => (f.fechaIso || '').startsWith(selectedMonth));
  }, [fletes, selectedMonth]);

  // Aggregate stats
  const stats = useMemo(() => {
    const total = monthFletes.length;
    const aprobados = monthFletes.filter(f => f.estado === 'Aprobado');
    const pendientes = monthFletes.filter(f => f.estado === 'Pendiente');
    const rechazados = monthFletes.filter(f => f.estado === 'Rechazado');

    const costoAprobado = aprobados.reduce((a, b) => a + (b.costoAdicional || 0), 0);
    const costoPendiente = pendientes.reduce((a, b) => a + (b.costoAdicional || 0), 0);
    const ahorroRechazo = rechazados.reduce((a, b) => a + (b.costoAdicional || 0), 0);
    const costoPromedio = aprobados.length > 0 ? Math.round(costoAprobado / aprobados.length) : 0;
    const gastoTotalProyectado = costoAprobado + costoPendiente;

    // By transportadora
    const porTransp: Record<string, { fletes: number; costo: number; aprobados: number; rechazados: number }> = {};
    monthFletes.forEach(f => {
      const t = f.transportadora || 'CCM';
      if (!porTransp[t]) porTransp[t] = { fletes: 0, costo: 0, aprobados: 0, rechazados: 0 };
      porTransp[t].fletes += 1;
      porTransp[t].costo += f.costoAdicional || 0;
      if (f.estado === 'Aprobado') porTransp[t].aprobados += 1;
      if (f.estado === 'Rechazado') porTransp[t].rechazados += 1;
    });

    // By plate
    const porPlaca: Record<string, { fletes: number; costo: number; transportadora: string; aprobados: number }> = {};
    monthFletes.forEach(f => {
      if (!porPlaca[f.placa]) {
        porPlaca[f.placa] = { fletes: 0, costo: 0, transportadora: f.transportadora, aprobados: 0 };
      }
      porPlaca[f.placa].fletes += 1;
      porPlaca[f.placa].costo += f.costoAdicional || 0;
      if (f.estado === 'Aprobado') porPlaca[f.placa].aprobados += 1;
    });

    // By concept
    const porTipo: Record<string, { cantidad: number; total: number }> = {};
    monthFletes.forEach(f => {
      const t = f.adicionalSolicitado || 'Auxiliar adicional';
      if (!porTipo[t]) porTipo[t] = { cantidad: 0, total: 0 };
      porTipo[t].cantidad += 1;
      porTipo[t].total += f.costoAdicional || 0;
    });

    return {
      total,
      aprobadosCount: aprobados.length,
      pendientesCount: pendientes.length,
      rechazadosCount: rechazados.length,
      costoAprobado,
      costoPendiente,
      ahorroRechazo,
      costoPromedio,
      gastoTotalProyectado,
      porTransp,
      porPlaca: Object.entries(porPlaca).sort((a, b) => b[1].costo - a[1].costo),
      porTipo: Object.entries(porTipo).sort((a, b) => b[1].total - a[1].total),
    };
  }, [monthFletes]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCSV = () => {
    const csv = exportFletesToCSV(monthFletes);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_mensual_fletes_${selectedMonth}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl max-w-5xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Generador Automático de Reportes Mensuales</h2>
              <p className="text-xs text-slate-300">
                Auditoría consolidada de costos adicionales de transporte y fletes
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Month selector */}
            <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
              <span className="text-xs text-slate-400">Mes:</span>
              <select
                value={selectedMonth}
                onChange={e => setSelectedMonth(e.target.value)}
                className="bg-transparent text-xs font-bold text-amber-300 focus:outline-none cursor-pointer"
              >
                {availableMonths.map(m => (
                  <option key={m} value={m} className="bg-slate-900 text-white">
                    {formatMonthName(m)}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
              title="Imprimir o guardar como PDF"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Imprimir / PDF</span>
            </button>

            <button
              onClick={handleDownloadCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition"
              title="Descargar datos en CSV/Excel"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Exportar Excel/CSV</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50" id="monthly-report-printable">
          {/* Corporate Header */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded bg-slate-900 text-white text-xs font-black tracking-wider">
                  AJE GROUP
                </span>
                <span className="text-xs font-bold text-slate-500">DEPARTAMENTO DE LOGÍSTICA & TRANSPORTE</span>
              </div>
              <h1 className="text-xl font-black text-slate-900 mt-1">
                INFORME MENSUAL DE ADICIONALES DE FLETES
              </h1>
              <p className="text-xs text-slate-500">
                Periodo auditado: <b className="text-slate-800">{formatMonthName(selectedMonth)}</b> &bull; Fecha de emisión: {new Date().toLocaleDateString('es-CO')}
              </p>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-400 block">Total Solicitudes Auditadas</span>
              <span className="text-2xl font-black text-slate-900">{stats.total} fletes</span>
              <span className="text-xs text-emerald-600 font-semibold block">
                {stats.aprobadosCount} aprobados &bull; {stats.rechazadosCount} rechazados
              </span>
            </div>
          </div>

          {/* Financial KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-xs">
              <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider block">
                Total Gastos Aprobados
              </span>
              <p className="text-xl font-black text-emerald-700 mt-1">
                {formatCOP(stats.costoAprobado)}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                {stats.aprobadosCount} fletes facturables
              </p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs">
              <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider block">
                Gastos Pendientes
              </span>
              <p className="text-xl font-black text-amber-700 mt-1">
                {formatCOP(stats.costoPendiente)}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                {stats.pendientesCount} en revisión de auditoría
              </p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-rose-200 shadow-xs">
              <span className="text-xs font-semibold text-rose-800 uppercase tracking-wider block">
                Ahorro por Rechazo
              </span>
              <p className="text-xl font-black text-rose-700 mt-1">
                {formatCOP(stats.ahorroRechazo)}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                {stats.rechazadosCount} fletes no autorizados
              </p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-xs">
              <span className="text-xs font-semibold text-blue-800 uppercase tracking-wider block">
                Costo Promedio / Flete
              </span>
              <p className="text-xl font-black text-blue-900 mt-1">
                {formatCOP(stats.costoPromedio)}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Gasto proyectado: {formatCOP(stats.gastoTotalProyectado)}
              </p>
            </div>
          </div>

          {/* Breakdown Tables in Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* By Transportadora */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-indigo-600" />
                Desglose por Transportadora
              </h3>
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                    <th className="pb-2">Transportadora</th>
                    <th className="pb-2 text-center">Fletes</th>
                    <th className="pb-2 text-center">Aprob/Rech</th>
                    <th className="pb-2 text-right">Gasto Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {Object.entries(stats.porTransp).map(([transp, data]) => (
                    <tr key={transp}>
                      <td className="py-2 font-bold text-slate-900">{transp}</td>
                      <td className="py-2 text-center text-slate-600">{data.fletes}</td>
                      <td className="py-2 text-center">
                        <span className="text-emerald-700 font-bold">{data.aprobados}</span> /{' '}
                        <span className="text-rose-700 font-bold">{data.rechazados}</span>
                      </td>
                      <td className="py-2 text-right font-mono font-bold text-slate-900">
                        {formatCOP(data.costo)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* By Concept */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                Desglose por Concepto / Adicional
              </h3>
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                    <th className="pb-2">Concepto</th>
                    <th className="pb-2 text-center">Cantidad</th>
                    <th className="pb-2 text-right">Monto Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stats.porTipo.map(([tipo, data]) => (
                    <tr key={tipo}>
                      <td className="py-2 font-medium text-slate-800">{tipo}</td>
                      <td className="py-2 text-center text-slate-600">{data.cantidad}</td>
                      <td className="py-2 text-right font-mono font-bold text-slate-900">
                        {formatCOP(data.total)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Vehicles & Plates */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Truck className="w-4 h-4 text-amber-600" />
              Consolidado por Placa de Vehículo y Transportadora en {formatMonthName(selectedMonth)}
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                    <th className="pb-2">Placa Vehículo</th>
                    <th className="pb-2">Transportadora</th>
                    <th className="pb-2 text-center">Fletes Solicitados</th>
                    <th className="pb-2 text-center">Aprobados</th>
                    <th className="pb-2 text-right">Costo Acumulado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stats.porPlaca.map(([placa, data]) => (
                    <tr key={placa}>
                      <td className="py-2 font-mono font-bold text-slate-900">
                        <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-300">
                          {placa}
                        </span>
                      </td>
                      <td className="py-2 font-medium text-slate-700">{data.transportadora}</td>
                      <td className="py-2 text-center text-slate-600">{data.fletes}</td>
                      <td className="py-2 text-center font-bold text-emerald-700">{data.aprobados}</td>
                      <td className="py-2 text-right font-mono font-bold text-slate-900">
                        {formatCOP(data.costo)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Audit & Approvals Signatures Block (for official documentation / PDF) */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs mt-6">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-8 text-center">
              Firmas de Aprobación y Auditoría Logística
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center text-xs">
              <div className="border-t border-slate-400 pt-2">
                <p className="font-bold text-slate-900">Jefe de Transporte</p>
                <p className="text-slate-500 text-[11px]">AJE Group - Operaciones</p>
              </div>
              <div className="border-t border-slate-400 pt-2">
                <p className="font-bold text-slate-900">Auditor de Fletes & Costos</p>
                <p className="text-slate-500 text-[11px]">Control Operacional</p>
              </div>
              <div className="border-t border-slate-400 pt-2">
                <p className="font-bold text-slate-900">Contabilidad & Pagos</p>
                <p className="text-slate-500 text-[11px]">Cuentas por Pagar</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Reporte generado automáticamente desde base de datos sincronizada
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
