import React from 'react';
import { CheckCircle2, Clock, XCircle, Calculator, Wallet, Package } from 'lucide-react';
import { FleteAdicional } from '../types';
import { formatCOP } from '../services/sheetsSync';

interface KpiMetricsProps {
  fletes: FleteAdicional[];
  onFilterStatus?: (status: 'Todos' | 'Pendiente' | 'Aprobado' | 'Rechazado') => void;
  activeStatusFilter?: string;
}

export const KpiMetrics: React.FC<KpiMetricsProps> = ({
  fletes,
  onFilterStatus,
  activeStatusFilter = 'Todos',
}) => {
  const pendientes = fletes.filter(f => f.estado === 'Pendiente');
  const aprobados = fletes.filter(f => f.estado === 'Aprobado');
  const rechazados = fletes.filter(f => f.estado === 'Rechazado');

  const costoAprobado = aprobados.reduce((acc, f) => acc + (f.costoAdicional || 0), 0);
  const costoPendiente = pendientes.reduce((acc, f) => acc + (f.costoAdicional || 0), 0);
  const ahorroRechazado = rechazados.reduce((acc, f) => acc + (f.costoAdicional || 0), 0);

  // Métricas 100% reales basadas en tarifas de auditoría AJE (Opción 1)
  const costoPromedioAprobado =
    aprobados.length > 0 ? Math.round(costoAprobado / aprobados.length) : 0;
  const gastoTotalProyectado = costoAprobado + costoPendiente;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
      {/* 1. Aprobados */}
      <div
        onClick={() => onFilterStatus && onFilterStatus(activeStatusFilter === 'Aprobado' ? 'Todos' : 'Aprobado')}
        className={`p-4 rounded-xl border bg-white shadow-xs cursor-pointer transition-all duration-150 ${
          activeStatusFilter === 'Aprobado'
            ? 'ring-2 ring-emerald-500 border-emerald-300 bg-emerald-50/40'
            : 'border-slate-200/80 hover:border-emerald-300 hover:shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Gastos Aprobados</span>
          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <CheckCircle2 className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2">
          <p className="text-xl font-bold text-slate-900 tracking-tight">{formatCOP(costoAprobado)}</p>
          <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
            <span className="font-medium text-emerald-700">{aprobados.length} fletes aprobados</span>
            <span>{fletes.length > 0 ? Math.round((aprobados.length / fletes.length) * 100) : 0}%</span>
          </div>
        </div>
      </div>

      {/* 2. Pendientes */}
      <div
        onClick={() => onFilterStatus && onFilterStatus(activeStatusFilter === 'Pendiente' ? 'Todos' : 'Pendiente')}
        className={`p-4 rounded-xl border bg-white shadow-xs cursor-pointer transition-all duration-150 ${
          activeStatusFilter === 'Pendiente'
            ? 'ring-2 ring-amber-500 border-amber-300 bg-amber-50/40'
            : 'border-slate-200/80 hover:border-amber-300 hover:shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Por Aprobar</span>
          <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center relative">
            <Clock className="w-4 h-4" />
            {pendientes.length > 0 && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-500 rounded-full animate-ping"></span>
            )}
          </div>
        </div>
        <div className="mt-2">
          <p className="text-xl font-bold text-amber-700 tracking-tight">{formatCOP(costoPendiente)}</p>
          <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
            <span className="font-medium text-amber-800">{pendientes.length} pendientes</span>
            <span className="text-amber-600 font-semibold">En revisión</span>
          </div>
        </div>
      </div>

      {/* 3. Rechazados / Ahorro */}
      <div
        onClick={() => onFilterStatus && onFilterStatus(activeStatusFilter === 'Rechazado' ? 'Todos' : 'Rechazado')}
        className={`p-4 rounded-xl border bg-white shadow-xs cursor-pointer transition-all duration-150 ${
          activeStatusFilter === 'Rechazado'
            ? 'ring-2 ring-rose-500 border-rose-300 bg-rose-50/40'
            : 'border-slate-200/80 hover:border-rose-300 hover:shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Ahorro / Rechazos</span>
          <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
            <XCircle className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2">
          <p className="text-xl font-bold text-slate-900 tracking-tight">{formatCOP(ahorroRechazado)}</p>
          <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
            <span className="font-medium text-rose-700">{rechazados.length} rechazados</span>
            <span className="text-slate-400 font-medium">No facturado</span>
          </div>
        </div>
      </div>

      {/* 4. Costo Promedio / Flete Aprobado */}
      <div className="p-4 rounded-xl border border-slate-200/80 bg-white shadow-xs">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Costo Promedio</span>
          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
            <Calculator className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2">
          <p className="text-xl font-bold text-blue-900 tracking-tight">{formatCOP(costoPromedioAprobado)}</p>
          <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
            <span>Por flete aprobado</span>
            <span className="text-blue-700 font-semibold">Tarifa real auditada</span>
          </div>
        </div>
      </div>

      {/* 5. Gasto Total Proyectado */}
      <div className="p-4 rounded-xl border border-slate-200/80 bg-white shadow-xs">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Gasto Proyectado</span>
          <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
            <Wallet className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2">
          <p className="text-xl font-bold text-indigo-950 tracking-tight">{formatCOP(gastoTotalProyectado)}</p>
          <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
            <span className="text-slate-600">Aprobados + Pendientes</span>
            <span className="text-indigo-600 font-semibold">{fletes.length - rechazados.length} fletes</span>
          </div>
        </div>
      </div>

      {/* 6. Total Solicitudes */}
      <div
        onClick={() => onFilterStatus && onFilterStatus('Todos')}
        className={`p-4 rounded-xl border bg-white shadow-xs cursor-pointer transition-all duration-150 ${
          activeStatusFilter === 'Todos'
            ? 'ring-2 ring-slate-800 border-slate-400'
            : 'border-slate-200/80 hover:border-slate-400'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Registros</span>
          <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
            <Package className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2">
          <p className="text-xl font-bold text-slate-900 tracking-tight">{fletes.length}</p>
          <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
            <span className="text-slate-600">En base de datos</span>
            <span className="text-blue-600 font-medium">Ver todos</span>
          </div>
        </div>
      </div>
    </div>
  );
};
