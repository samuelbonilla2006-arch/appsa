import React, { useState } from 'react';
import { X, PlusCircle, Truck, FileText, DollarSign, Link as LinkIcon } from 'lucide-react';
import { FleteAdicional } from '../types';
import { formatCOP } from '../services/sheetsSync';

interface NewFleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (newFlete: FleteAdicional) => void;
  nextIdNumber: number;
}

export const NewFleteModal: React.FC<NewFleteModalProps> = ({
  isOpen,
  onClose,
  onSave,
  nextIdNumber,
}) => {
  const [transportadora, setTransportadora] = useState('CCM');
  const [placa, setPlaca] = useState('KUL753');
  const [adicionalSolicitado, setAdicionalSolicitado] = useState('Auxiliar adicional');
  const [guia, setGuia] = useState('');
  const [ordenCarga, setOrdenCarga] = useState('');
  const [pacas, setPacas] = useState('850');
  const [pesoKg, setPesoKg] = useState('6800');
  const [detalleMotivo, setDetalleMotivo] = useState(
    'Se solicita auxiliar adicional debido al volumen de la operación: descargue de pacas.'
  );
  const [soportesUrl, setSoportesUrl] = useState('');
  const [costoAdicional, setCostoAdicional] = useState(70000);
  const [ingresoFacturado, setIngresoFacturado] = useState(70000);

  if (!isOpen) return null;

  // When concept changes, auto-suggest official AJE rate
  const handleAdicionalChange = (val: string) => {
    setAdicionalSolicitado(val);
    if (val.includes('2do Piso') || val.includes('Arrumar') || val.includes('2 Auxiliares')) {
      setCostoAdicional(140000);
      setIngresoFacturado(140000);
    } else if (val === 'Ladera Chana') {
      setCostoAdicional(10000);
      setIngresoFacturado(10000);
    } else if (val === 'Ladera NHR') {
      setCostoAdicional(40000);
      setIngresoFacturado(40000);
    } else if (val === 'Ladera Sencillo') {
      setCostoAdicional(50000);
      setIngresoFacturado(50000);
    } else if (val.includes('Standby') || val.includes('Estadía')) {
      setCostoAdicional(250000);
      setIngresoFacturado(250000);
    } else if (val.includes('descargue') || val.includes('Descargue')) {
      setCostoAdicional(340000);
      setIngresoFacturado(340000);
    } else {
      setCostoAdicional(70000);
      setIngresoFacturado(70000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    const marcaTemporal = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
    const fechaIso = `${year}-${month}-${day}`;
    const id = `SOL-2026-${String(nextIdNumber).padStart(4, '0')}`;

    const motivoCompleto = `${detalleMotivo} (${pacas ? `${pacas} pacas, ` : ''}${pesoKg ? `${pesoKg} kg` : ''})`;

    const newRecord: FleteAdicional = {
      id,
      marcaTemporal,
      fechaIso,
      transportadora,
      placa: placa.toUpperCase().trim(),
      adicionalSolicitado,
      guia: guia.trim(),
      ordenCarga: ordenCarga.trim(),
      motivo: motivoCompleto,
      soportesUrl: soportesUrl.trim() || 'https://drive.google.com/open?id=soporte_generado',
      costoAdicional: Number(costoAdicional) || 70000,
      ingresoFacturado: Number(ingresoFacturado) || Number(costoAdicional) || 70000,
      estado: 'Pendiente',
      origen: 'formulario_interno',
    };

    onSave(newRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Registrar Nuevo Adicional de Flete</h2>
              <p className="text-xs text-slate-300">
                Alimentación en tiempo real de base de datos y sincronización con Sheet
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Row 1: Transportadora & Placa */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Transportadora
              </label>
              <select
                value={transportadora}
                onChange={e => setTransportadora(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                required
              >
                <option value="CCM">CCM (Transportes)</option>
                <option value="TCC">TCC</option>
                <option value="Coltanques">Coltanques</option>
                <option value="Servientrega">Servientrega</option>
                <option value="Coordinadora">Coordinadora</option>
                <option value="Transportes Alianza">Transportes Alianza</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Placa del Vehículo
              </label>
              <input
                type="text"
                value={placa}
                onChange={e => setPlaca(e.target.value.toUpperCase())}
                placeholder="Ej: KUL753"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold uppercase focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                required
              />
            </div>
          </div>

          {/* Row 2: Adicional Solicitado */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Adicional Solicitado
            </label>
            <select
              value={adicionalSolicitado}
              onChange={e => handleAdicionalChange(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              required
            >
              <option value="Auxiliar adicional">Auxiliar adicional (1 persona - $70.000 COP)</option>
              <option value="Auxiliar adicional (2do Piso)">2 Auxiliares adicionales (Subida 2do piso - $140.000 COP)</option>
              <option value="Auxiliar adicional (Arrumar)">2 Auxiliares adicionales (Arrumar tenderos - $140.000 COP)</option>
              <option value="Ladera Chana">Ladera Chana ($10.000 COP)</option>
              <option value="Ladera NHR">Ladera NHR ($40.000 COP)</option>
              <option value="Ladera Sencillo">Ladera Sencillo ($50.000 COP)</option>
              <option value="Estadía / Standby">Estadía / Standby (Mitad de flete - 50%)</option>
              <option value="Cobro por descargue">Cobro por descargue (Según cliente / Cañaveral)</option>
            </select>
          </div>

          {/* Row 3: Guía & Orden de Carga */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Número de Guía
              </label>
              <input
                type="text"
                value={guia}
                onChange={e => setGuia(e.target.value)}
                placeholder="Ej: 101088"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Orden de Carga (OC)
              </label>
              <input
                type="text"
                value={ordenCarga}
                onChange={e => setOrdenCarga(e.target.value)}
                placeholder="Ej: CL26260140"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                required
              />
            </div>
          </div>

          {/* Row 4: Pacas & Peso */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Cantidad de Pacas
              </label>
              <input
                type="number"
                value={pacas}
                onChange={e => setPacas(e.target.value)}
                placeholder="Ej: 850"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Peso Total (Kg)
              </label>
              <input
                type="number"
                value={pesoKg}
                onChange={e => setPesoKg(e.target.value)}
                placeholder="Ej: 6800"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Motivo Detallado */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ¿Por qué se está solicitando el adicional?
            </label>
            <textarea
              value={detalleMotivo}
              onChange={e => setDetalleMotivo(e.target.value)}
              rows={2}
              className="w-full text-xs p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              placeholder="Justificación operativa del adicional solicitado..."
              required
            />
          </div>

          {/* Soportes Google Drive */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
              <LinkIcon className="w-3.5 h-3.5 text-slate-400" />
              <span>Enlace de Soportes (Google Drive / Foto comprobante)</span>
            </label>
            <input
              type="url"
              value={soportesUrl}
              onChange={e => setSoportesUrl(e.target.value)}
              placeholder="https://drive.google.com/open?id=..."
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 font-mono text-slate-700"
            />
          </div>

          {/* Costos e Ingresos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Costo Adicional (Gasto Operación COP)
              </label>
              <input
                type="number"
                step="1000"
                value={costoAdicional}
                onChange={e => setCostoAdicional(Number(e.target.value))}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-slate-900 bg-white"
                required
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Monto: <b>{formatCOP(costoAdicional)}</b>
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Ingreso Facturado / Cobro Cliente (COP)
              </label>
              <input
                type="number"
                step="1000"
                value={ingresoFacturado}
                onChange={e => setIngresoFacturado(Number(e.target.value))}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 font-mono font-bold text-emerald-700 bg-white"
                required
              />
              <span className="text-[11px] text-emerald-700 mt-1 block">
                Monto: <b>{formatCOP(ingresoFacturado)}</b>
              </span>
            </div>
          </div>

          {/* Footer buttons */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-sm shadow-emerald-900/20 transition"
            >
              Registrar en Base de Datos
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
