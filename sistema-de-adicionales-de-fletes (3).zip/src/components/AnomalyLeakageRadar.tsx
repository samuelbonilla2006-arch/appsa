import React, { useMemo } from 'react';
import {
  ShieldAlert,
  TrendingDown,
  Truck,
  AlertTriangle,
  Building2,
  FileCheck2,
  Layers,
  ChevronRight,
  Info,
  Clock,
  Sparkles,
} from 'lucide-react';
import { FleteAdicional } from '../types';
import { formatCOP } from '../services/sheetsSync';
import { detectTariff, evaluateAuditRisk } from '../data/pricingRules';

interface AnomalyLeakageRadarProps {
  fletes: FleteAdicional[];
  onSelectPlateFilter?: (plate: string) => void;
  onSelectCarrierFilter?: (carrier: string) => void;
}

export const AnomalyLeakageRadar: React.FC<AnomalyLeakageRadarProps> = ({
  fletes,
  onSelectPlateFilter,
  onSelectCarrierFilter,
}) => {
  // 1. Calculate Total Savings Protected by AJE Rules
  const savingsMetrics = useMemo(() => {
    let standbySavings = 0;
    let duplicateRiskCount = 0;
    let highRiskCount = 0;
    let safeCount = 0;

    const plateMap: Record<string, number> = {};
    fletes.forEach(f => {
      const p = (f.placa || '').trim().toUpperCase();
      if (p) {
        plateMap[p] = (plateMap[p] || 0) + 1;
      }
    });

    fletes.forEach(f => {
      const detected = detectTariff(f.adicionalSolicitado || '', f.motivo || '');
      if (detected.diferenciaAhorro && detected.diferenciaAhorro > 0) {
        standbySavings += detected.diferenciaAhorro;
      }

      const pKey = (f.placa || '').trim().toUpperCase();
      const plateCount = pKey ? (plateMap[pKey] || 1) : 1;
      const risk = evaluateAuditRisk(f, detected, plateCount);
      if (risk.nivel === 'alto') highRiskCount++;
      if (risk.nivel === 'bajo') safeCount++;
      if (plateCount > 1) duplicateRiskCount++;
    });

    return {
      standbySavings,
      duplicateRiskCount,
      highRiskCount,
      safeCount,
      totalAnalyzed: fletes.length,
    };
  }, [fletes]);

  // 2. Carrier Anomaly Matrix
  const carrierStats = useMemo(() => {
    const map: Record<
      string,
      {
        nombre: string;
        total: number;
        aprobados: number;
        pendientes: number;
        costoTotal: number;
        dosAuxiliares: number;
        standby: number;
      }
    > = {};

    fletes.forEach(f => {
      const c = f.transportadora || 'Sin Asignar';
      if (!map[c]) {
        map[c] = {
          nombre: c,
          total: 0,
          aprobados: 0,
          pendientes: 0,
          costoTotal: 0,
          dosAuxiliares: 0,
          standby: 0,
        };
      }
      map[c].total++;
      if (f.estado === 'Aprobado') map[c].aprobados++;
      if (f.estado === 'Pendiente') map[c].pendientes++;
      map[c].costoTotal += f.costoAdicional || 70000;

      const text = `${f.adicionalSolicitado || ''} ${f.motivo || ''}`.toLowerCase();
      if (text.includes('2 auxiliar') || text.includes('arruma') || text.includes('2 piso')) {
        map[c].dosAuxiliares++;
      }
      if (text.includes('standby') || text.includes('stanby')) {
        map[c].standby++;
      }
    });

    return Object.values(map).sort((a, b) => b.total - a.total);
  }, [fletes]);

  // 3. Repeated Plates (High Audit Alert)
  const repeatedPlates = useMemo(() => {
    const map: Record<string, { placa: string; transportadora: string; count: number; items: FleteAdicional[] }> = {};
    fletes.forEach(f => {
      const p = (f.placa || '').trim().toUpperCase();
      if (!p) return;
      if (!map[p]) {
        map[p] = { placa: p, transportadora: f.transportadora || 'Sin Asignar', count: 0, items: [] };
      }
      map[p].count++;
      map[p].items.push(f);
    });

    return Object.values(map)
      .filter(item => item.count > 1)
      .sort((a, b) => b.count - a.count);
  }, [fletes]);

  return (
    <div className="space-y-6">
      {/* Banner Superior de Inteligencia de Fugas */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 shadow-xl border border-indigo-900/50">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" />
                Control de Fugas Activo
              </span>
              <span className="text-xs text-slate-400">Logística AJE Group</span>
            </div>
            <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
              Radar Predictivo de Fugas de Dinero y Patrones Operativos
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              La IA audita en tiempo real duplicidades de placas, sobreprecios en estadías y desvíos de auxiliares frente a la norma reglamentaria de transporte AJE.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-3">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-center min-w-[130px]">
              <span className="text-[10px] uppercase font-bold text-emerald-300 block">
                Ahorro Standby Protegido
              </span>
              <span className="text-base font-black text-white font-mono">
                {formatCOP(savingsMetrics.standbySavings)}
              </span>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-center min-w-[110px]">
              <span className="text-[10px] uppercase font-bold text-amber-300 block">
                Alertas Reincidencia
              </span>
              <span className="text-base font-black text-white font-mono">
                {savingsMetrics.duplicateRiskCount} casos
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid de 3 Columnas de Diagnóstico */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Columna 1: Semáforo de Riesgo */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5 uppercase tracking-wider">
                <ShieldAlert className="w-4 h-4 text-indigo-600" />
                Semáforo de Riesgo IA
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                {savingsMetrics.totalAnalyzed} fletes
              </span>
            </div>

            <div className="mt-4 space-y-3">
              {/* Verde */}
              <div className="p-3 rounded-xl bg-emerald-50/80 border border-emerald-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-xs" />
                  <div>
                    <span className="text-xs font-bold text-emerald-950 block">
                      🟢 Bajo Riesgo (Pre-Aprobables)
                    </span>
                    <span className="text-[10px] text-emerald-700">
                      Soporte en Drive, placa única, tarifa exacta AJE
                    </span>
                  </div>
                </div>
                <span className="text-sm font-black text-emerald-900 font-mono">
                  {savingsMetrics.safeCount}
                </span>
              </div>

              {/* Amarillo */}
              <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-3 h-3 rounded-full bg-amber-500 shadow-xs" />
                  <div>
                    <span className="text-xs font-bold text-amber-950 block">
                      🟡 Riesgo Medio (Revisión Sugerida)
                    </span>
                    <span className="text-[10px] text-amber-700">
                      Standby sin horas, o 2 auxiliares en volumen bajo
                    </span>
                  </div>
                </div>
                <span className="text-sm font-black text-amber-900 font-mono">
                  {savingsMetrics.totalAnalyzed - savingsMetrics.safeCount - savingsMetrics.highRiskCount}
                </span>
              </div>

              {/* Rojo */}
              <div className="p-3 rounded-xl bg-rose-50/80 border border-rose-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-3 h-3 rounded-full bg-rose-500 shadow-xs animate-pulse" />
                  <div>
                    <span className="text-xs font-bold text-rose-950 block">
                      🔴 Alto Riesgo / Fuga Potencial
                    </span>
                    <span className="text-[10px] text-rose-700">
                      Reincidencia de placa, sin soporte o sobreprecio
                    </span>
                  </div>
                </div>
                <span className="text-sm font-black text-rose-900 font-mono">
                  {savingsMetrics.highRiskCount}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Permite pre-aprobar el lote verde con 1 solo clic desde el panel de pendientes.</span>
          </div>
        </div>

        {/* Columna 2: Vehículos con Reincidencia */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5 uppercase tracking-wider">
                <Truck className="w-4 h-4 text-amber-600" />
                Reincidencia de Placas (Doble Cobro)
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                {repeatedPlates.length} alertas
              </span>
            </div>

            <div className="mt-3 space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {repeatedPlates.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400">
                  No se detectaron placas con múltiples radicados hoy.
                </div>
              ) : (
                repeatedPlates.slice(0, 5).map(item => (
                  <div
                    key={item.placa}
                    onClick={() => onSelectPlateFilter && onSelectPlateFilter(item.placa)}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/30 transition cursor-pointer flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-amber-300 text-slate-950 border border-amber-400">
                          {item.placa}
                        </span>
                        <span className="text-[11px] font-bold text-slate-700">
                          {item.transportadora}
                        </span>
                      </div>
                      <span className="text-[10px] text-rose-600 font-semibold mt-0.5 block">
                        ⚠️ {item.count} radicaciones en el sistema
                      </span>
                    </div>

                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            Haz clic en una placa para auditar sus solicitudes simultáneas.
          </div>
        </div>

        {/* Columna 3: Comportamiento por Transportadora */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5 uppercase tracking-wider">
                <Building2 className="w-4 h-4 text-indigo-600" />
                Matriz de Desvío por Flota
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                {carrierStats.length} empresas
              </span>
            </div>

            <div className="mt-3 space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {carrierStats.slice(0, 5).map(c => {
                const percentStandby = c.total > 0 ? Math.round((c.standby / c.total) * 100) : 0;
                const percent2Aux = c.total > 0 ? Math.round((c.dosAuxiliares / c.total) * 100) : 0;

                return (
                  <div
                    key={c.nombre}
                    onClick={() => onSelectCarrierFilter && onSelectCarrierFilter(c.nombre)}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-slate-50 transition cursor-pointer flex items-center justify-between"
                  >
                    <div>
                      <span className="text-xs font-bold text-slate-800 block truncate max-w-[150px]">
                        {c.nombre}
                      </span>
                      <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-500">
                        <span>{c.total} solicitudes</span>
                        <span>•</span>
                        <span className={percent2Aux > 25 ? 'text-amber-600 font-bold' : ''}>
                          2 Aux: {percent2Aux}%
                        </span>
                        {percentStandby > 0 && (
                          <>
                            <span>•</span>
                            <span className="text-purple-600 font-bold">
                              Standby: {c.standby}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <span className="text-xs font-black text-slate-900 font-mono">
                      {formatCOP(c.costoTotal)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            Filtra directamente por transportadora para ver sus radicados pendientes.
          </div>
        </div>
      </div>
    </div>
  );
};
