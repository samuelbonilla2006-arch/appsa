import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  AreaChart,
  Area,
} from 'recharts';
import { FleteAdicional } from '../types';
import { formatCOP } from '../services/sheetsSync';
import { TrendingUp, PieChart as PieIcon, Truck, Layers } from 'lucide-react';

interface ChartsDashboardProps {
  fletes: FleteAdicional[];
}

const COLORS_ESTADO = {
  Aprobado: '#10b981', // emerald-500
  Pendiente: '#f59e0b', // amber-500
  Rechazado: '#f43f5e', // rose-500
};

export const ChartsDashboard: React.FC<ChartsDashboardProps> = ({ fletes }) => {
  const [activeTab, setActiveTab] = useState<'timeline' | 'vehicles' | 'types'>('timeline');

  // 1. Group by Date
  const dateMap: Record<string, { fecha: string; gastos: number; pendientes: number; cantidad: number }> = {};
  fletes.forEach(f => {
    const key = f.fechaIso || '2026-09-15';
    if (!dateMap[key]) {
      dateMap[key] = { fecha: key, gastos: 0, pendientes: 0, cantidad: 0 };
    }
    dateMap[key].cantidad += 1;
    if (f.estado === 'Aprobado') {
      dateMap[key].gastos += f.costoAdicional || 0;
    } else if (f.estado === 'Pendiente') {
      dateMap[key].pendientes += f.costoAdicional || 0;
    }
  });
  const timelineData = Object.values(dateMap).sort((a, b) => a.fecha.localeCompare(b.fecha));

  // 2. Status counts
  const estadoData = [
    { name: 'Aprobado', value: fletes.filter(f => f.estado === 'Aprobado').length, color: COLORS_ESTADO.Aprobado },
    { name: 'Pendiente', value: fletes.filter(f => f.estado === 'Pendiente').length, color: COLORS_ESTADO.Pendiente },
    { name: 'Rechazado', value: fletes.filter(f => f.estado === 'Rechazado').length, color: COLORS_ESTADO.Rechazado },
  ].filter(d => d.value > 0);

  // 3. Group by Vehicle Plate (Top plates)
  const plateMap: Record<string, { placa: string; costo: number; fletes: number; transportadora: string }> = {};
  fletes.forEach(f => {
    if (!plateMap[f.placa]) {
      plateMap[f.placa] = { placa: f.placa, costo: 0, fletes: 0, transportadora: f.transportadora };
    }
    plateMap[f.placa].fletes += 1;
    plateMap[f.placa].costo += f.costoAdicional || 0;
  });
  const topPlates = Object.values(plateMap)
    .sort((a, b) => b.costo - a.costo)
    .slice(0, 6);

  // 4. Group by Additional Type
  const typeMap: Record<string, { tipo: string; total: number; cantidad: number }> = {};
  fletes.forEach(f => {
    let typeKey = f.adicionalSolicitado || 'Auxiliar adicional';
    if (f.motivo?.toLowerCase().includes('2 auxiliar') || f.costoAdicional === 140000) {
      typeKey = 'Auxiliar adicional (2 Auxiliares)';
    }

    if (!typeMap[typeKey]) {
      typeMap[typeKey] = { tipo: typeKey, total: 0, cantidad: 0 };
    }
    typeMap[typeKey].cantidad += 1;
    typeMap[typeKey].total += f.costoAdicional || 0;
  });
  const typeData = Object.values(typeMap).sort((a, b) => b.total - a.total);

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-indigo-600" />
            Monitoreo Financiero y Operativo de Adicionales
          </h2>
          <p className="text-xs text-slate-500">
            Visualización analítica de gastos auditados, estados y concentración por vehículo (100% Real)
          </p>
        </div>

        {/* View switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium self-start sm:self-auto">
          <button
            id="tab-timeline"
            onClick={() => setActiveTab('timeline')}
            className={`px-3 py-1.5 rounded-md transition ${
              activeTab === 'timeline' ? 'bg-white text-indigo-700 font-semibold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Evolución de Gastos
          </button>
          <button
            id="tab-vehicles"
            onClick={() => setActiveTab('vehicles')}
            className={`px-3 py-1.5 rounded-md transition flex items-center gap-1.5 ${
              activeTab === 'vehicles' ? 'bg-white text-indigo-700 font-semibold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            Por Placa / Vehículo
          </button>
          <button
            id="tab-types"
            onClick={() => setActiveTab('types')}
            className={`px-3 py-1.5 rounded-md transition flex items-center gap-1.5 ${
              activeTab === 'types' ? 'bg-white text-indigo-700 font-semibold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Por Concepto
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-1">
        {/* Main Chart (2 cols) */}
        <div className="lg:col-span-2">
          {activeTab === 'timeline' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-700">Gastos Aprobados vs Monto en Revisión (COP)</span>
                <span className="text-[11px] text-slate-400">Valores auditados AJE</span>
              </div>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={timelineData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorGastos" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                      </linearGradient>
                      <linearGradient id="colorPendientes" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis
                      dataKey="fecha"
                      stroke="#94a3b8"
                      fontSize={11}
                      tickFormatter={val => val.split('-').slice(1).join('/')}
                    />
                    <YAxis
                      stroke="#94a3b8"
                      fontSize={11}
                      tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(value: any) => [formatCOP(Number(value)), '']}
                      labelFormatter={label => `Fecha: ${label}`}
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Area
                      type="monotone"
                      name="Gastos Aprobados"
                      dataKey="gastos"
                      stroke="#10b981"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorGastos)"
                    />
                    <Area
                      type="monotone"
                      name="Monto en Revisión (Pendientes)"
                      dataKey="pendientes"
                      stroke="#f59e0b"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorPendientes)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {activeTab === 'vehicles' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-700">Top Placas con Mayor Costo en Adicionales</span>
                <span className="text-[11px] text-slate-400">Total acumulado</span>
              </div>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topPlates} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="placa" stroke="#94a3b8" fontSize={11} />
                    <YAxis
                      stroke="#94a3b8"
                      fontSize={11}
                      tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(value: any, name: any, item: any) => [
                        formatCOP(Number(value)),
                        `Transportadora: ${item.payload.transportadora}`,
                      ]}
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                    />
                    <Bar dataKey="costo" name="Costo Adicional" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {activeTab === 'types' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-700">Costos por Tipo de Adicional</span>
                <span className="text-[11px] text-slate-400">Acumulado por categoría</span>
              </div>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={typeData} layout="vertical" margin={{ top: 10, right: 20, left: 80, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis type="number" stroke="#94a3b8" fontSize={11} tickFormatter={val => `$${(val / 1000).toFixed(0)}k`} />
                    <YAxis dataKey="tipo" type="category" stroke="#94a3b8" fontSize={11} width={100} />
                    <Tooltip
                      formatter={(value: any) => [formatCOP(Number(value)), 'Costo']}
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                    />
                    <Bar dataKey="total" name="Costo Total" fill="#0ea5e9" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>

        {/* Donut Chart: Estado de Solicitudes (1 col) */}
        <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-100 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <PieIcon className="w-4 h-4 text-emerald-600" />
                Estado de Solicitudes
              </span>
              <span className="text-[11px] font-semibold text-slate-500">{fletes.length} total</span>
            </div>
            <p className="text-[11px] text-slate-500 mb-2">Proporción de fletes aprobados, en espera y rechazados</p>
          </div>

          <div className="h-44 w-full my-auto">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={estadoData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={68}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {estadoData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any, name: any) => [`${val} solicitudes (${Math.round((Number(val) / fletes.length) * 100)}%)`, name]}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Custom Legend */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-200/60 text-center">
            {estadoData.map(item => (
              <div key={item.name} className="flex flex-col items-center">
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-[11px] font-medium text-slate-600">{item.name}</span>
                </div>
                <span className="text-xs font-bold text-slate-900">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
