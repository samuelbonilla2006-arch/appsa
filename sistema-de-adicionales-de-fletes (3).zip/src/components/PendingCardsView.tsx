import React, { useState, useMemo } from 'react';
import {
  Clock,
  ExternalLink,
  CheckCircle2,
  XCircle,
  FileSpreadsheet,
  Search,
  DollarSign,
  AlertTriangle,
  Info,
  Check,
  Copy,
  Layers,
  Sparkles,
  SlidersHorizontal,
  ShieldCheck,
  CheckSquare,
  Square,
  Zap,
  Filter,
  UserCheck,
  Send,
  ShieldAlert,
  Eye,
  X,
} from 'lucide-react';
import { FleteAdicional } from '../types';
import { formatCOP, safeCopyToClipboard, extractSupportUrls } from '../services/sheetsSync';
import { detectTariff, OFFICIAL_TARIFFS, evaluateAuditRisk, generateFormalStatement } from '../data/pricingRules';

// Helper to get Google Drive /preview URL for embedding or previewing
function getDrivePreviewUrl(url: string): string {
  const match = url.match(/[-\w]{25,}/);
  if (match) {
    return `https://drive.google.com/file/d/${match[0]}/preview`;
  }
  return url;
}

interface PendingCardsViewProps {
  fletes: FleteAdicional[];
  onApproveWithCost: (id: string, cost: number, observaciones?: string) => void;
  onQuickReject: (id: string) => void;
  onOpenReview: (flete: FleteAdicional) => void;
  onBatchApprove?: (items: { id: string; cost: number; obs: string }[]) => void;
  onBatchReject?: (ids: string[]) => void;
  activeAuditorName?: string;
}

export const PendingCardsView: React.FC<PendingCardsViewProps> = ({
  fletes,
  onApproveWithCost,
  onQuickReject,
  onOpenReview,
  onBatchApprove,
  onBatchReject,
  activeAuditorName = 'Samuel Bonilla',
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [carrierFilter, setCarrierFilter] = useState('Todos');
  const [categoryFilter, setCategoryFilter] = useState('Todos');
  const [riskFilter, setRiskFilter] = useState<'Todos' | 'Bajo' | 'Medio' | 'Alto'>('Todos');
  const [sortBy, setSortBy] = useState<'recent' | 'plate' | 'cost_desc'>('recent');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedStatementId, setCopiedStatementId] = useState<string | null>(null);

  // Batch selection state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [previewSupportUrl, setPreviewSupportUrl] = useState<{ url: string; title: string } | null>(null);

  // Local state for customized costs on cards before clicking approve
  const [customCosts, setCustomCosts] = useState<Record<string, number>>({});

  // Filter only pending
  const pendingFletes = useMemo(() => {
    return fletes.filter(f => f.estado === 'Pendiente');
  }, [fletes]);

  // Duplicate detection map: Plate -> count
  const plateFrequencyMap = useMemo(() => {
    const map: Record<string, number> = {};
    pendingFletes.forEach(f => {
      const p = f.placa.toUpperCase().trim();
      if (p) map[p] = (map[p] || 0) + 1;
    });
    return map;
  }, [pendingFletes]);

  // Distinct carriers
  const carriers = useMemo(() => {
    const list = Array.from(new Set(pendingFletes.map(f => f.transportadora).filter(Boolean)));
    return ['Todos', ...list];
  }, [pendingFletes]);

  const getEffectiveCost = (flete: FleteAdicional) => {
    if (customCosts[flete.id] !== undefined) {
      return customCosts[flete.id];
    }
    if (flete.costoAdicional && flete.costoAdicional > 0) {
      return flete.costoAdicional;
    }
    return detectTariff(flete.adicionalSolicitado, flete.motivo).costo;
  };

  // Filtered and sorted pending cards
  const filteredPending = useMemo(() => {
    const list = pendingFletes.filter(f => {
      if (carrierFilter !== 'Todos' && f.transportadora !== carrierFilter) return false;

      // Category filter
      if (categoryFilter !== 'Todos') {
        const tariff = detectTariff(f.adicionalSolicitado, f.motivo);
        if (categoryFilter === '1 Auxiliar ($70k)' && tariff.tarifaId !== 'aux-1') return false;
        if (categoryFilter === '2 Auxiliares ($140k)' && tariff.tarifaId !== 'aux-2') return false;
        if (categoryFilter === 'Standby (50% AJE)' && !tariff.esStandby) return false;
        if (categoryFilter === 'Laderas' && !tariff.esLadera) return false;
        if (categoryFilter === 'Descargue' && !tariff.esDescargue) return false;
      }

      // Risk level filter (Semáforo IA)
      if (riskFilter !== 'Todos') {
        const tariff = detectTariff(f.adicionalSolicitado, f.motivo);
        const plateCount = plateFrequencyMap[f.placa.toUpperCase().trim()] || 1;
        const risk = evaluateAuditRisk(f, tariff, plateCount);
        if (riskFilter === 'Bajo' && risk.nivel !== 'bajo') return false;
        if (riskFilter === 'Medio' && risk.nivel !== 'medio') return false;
        if (riskFilter === 'Alto' && risk.nivel !== 'alto') return false;
      }

      if (!searchTerm) return true;
      const q = searchTerm.toLowerCase();
      return (
        f.id.toLowerCase().includes(q) ||
        f.placa.toLowerCase().includes(q) ||
        f.guia.toLowerCase().includes(q) ||
        f.ordenCarga.toLowerCase().includes(q) ||
        f.motivo.toLowerCase().includes(q) ||
        f.adicionalSolicitado.toLowerCase().includes(q)
      );
    });

    return list.sort((a, b) => {
      if (sortBy === 'plate') {
        return a.placa.localeCompare(b.placa);
      }
      if (sortBy === 'cost_desc') {
        return getEffectiveCost(b) - getEffectiveCost(a);
      }
      // 'recent': ID or date descending
      return b.id.localeCompare(a.id);
    });
  }, [pendingFletes, carrierFilter, categoryFilter, searchTerm, sortBy, customCosts]);

  // Total pending cost calculation
  const totalPendingCost = useMemo(() => {
    return filteredPending.reduce((sum, f) => {
      return sum + getEffectiveCost(f);
    }, 0);
  }, [filteredPending, customCosts]);

  // Total for selected batch
  const batchSelectedCost = useMemo(() => {
    return pendingFletes
      .filter(f => selectedIds.has(f.id))
      .reduce((sum, f) => sum + getEffectiveCost(f), 0);
  }, [pendingFletes, selectedIds, customCosts]);

  const copyToClipboard = async (text: string, id: string) => {
    const ok = await safeCopyToClipboard(text);
    if (ok) {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const handleCostChange = (id: string, newCost: number) => {
    setCustomCosts(prev => ({
      ...prev,
      [id]: Math.max(0, newCost),
    }));
  };

  // Toggle selection
  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Select all matching $70k standard
  const selectAllStandard70k = () => {
    const ids = new Set<string>();
    filteredPending.forEach(f => {
      const cost = getEffectiveCost(f);
      if (cost === 70000) ids.add(f.id);
    });
    setSelectedIds(ids);
  };

  // Select all low-risk items (🟢 Score >= 80)
  const selectAllSafeItems = () => {
    const ids = new Set<string>();
    filteredPending.forEach(f => {
      const tariff = detectTariff(f.adicionalSolicitado, f.motivo);
      const plateCount = plateFrequencyMap[f.placa.toUpperCase().trim()] || 1;
      const risk = evaluateAuditRisk(f, tariff, plateCount);
      if (risk.nivel === 'bajo' && risk.score >= 80) {
        ids.add(f.id);
      }
    });
    setSelectedIds(ids);
  };

  // Quick Copy Formal Notification Statement
  const copyFormalStatement = async (flete: FleteAdicional) => {
    const tariff = detectTariff(flete.adicionalSolicitado, flete.motivo);
    const cost = getEffectiveCost(flete);
    const statement = generateFormalStatement(
      flete,
      'aprobado',
      cost,
      activeAuditorName,
      tariff
    );
    const ok = await safeCopyToClipboard(statement);
    if (ok) {
      setCopiedStatementId(flete.id);
      setTimeout(() => setCopiedStatementId(null), 2500);
    }
  };

  // Select all filtered
  const selectAllFiltered = () => {
    const ids = new Set<string>();
    filteredPending.forEach(f => ids.add(f.id));
    setSelectedIds(ids);
  };

  // Clear selection
  const clearSelection = () => {
    setSelectedIds(new Set());
  };

  // Execute Batch Approve
  const handleExecuteBatchApprove = () => {
    if (selectedIds.size === 0) return;
    const items = pendingFletes
      .filter(f => selectedIds.has(f.id))
      .map(f => {
        const tariffInfo = detectTariff(f.adicionalSolicitado, f.motivo);
        const cost = getEffectiveCost(f);
        return {
          id: f.id,
          cost,
          obs: tariffInfo.detalleCalculo,
        };
      });

    if (onBatchApprove) {
      onBatchApprove(items);
    } else {
      // Fallback one by one
      items.forEach(item => onApproveWithCost(item.id, item.cost, item.obs));
    }
    clearSelection();
  };

  // Execute Batch Reject
  const handleExecuteBatchReject = () => {
    if (selectedIds.size === 0) return;
    const ids = Array.from(selectedIds);
    if (onBatchReject) {
      onBatchReject(ids);
    } else {
      ids.forEach(id => onQuickReject(id));
    }
    clearSelection();
  };

  return (
    <div className="space-y-4">
      {/* Top Banner & Fast Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
              </span>
              <h3 className="text-base font-bold text-slate-900">
                Ventanitas de Fletes Pendientes de Auditoría
              </h3>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold">
                {filteredPending.length} pendientes
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Revise la justificación operativa, abra el soporte fotográfico en Google Drive y autorice con la tarifa oficial AJE en 1 clic.
            </p>
          </div>

          {/* Quick Stats Pills */}
          <div className="flex items-center gap-3 self-start lg:self-auto bg-slate-50 border border-slate-200/80 px-4 py-2 rounded-xl">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block leading-tight">
                Costo Total Pendiente
              </span>
              <span className="text-sm font-extrabold text-slate-900 font-mono">
                {formatCOP(totalPendingCost)}
              </span>
            </div>
            <div className="h-7 w-px bg-slate-200" />
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block leading-tight">
                Tarifa Auxiliar AJE
              </span>
              <span className="text-xs font-bold text-emerald-700 font-mono">
                $70.000 / $140.000
              </span>
            </div>
          </div>
        </div>

        {/* Fast Tariff Categories Selector */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
          <span className="text-xs text-slate-400 font-semibold flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" />
            Tarifas AJE:
          </span>
          {[
            'Todos',
            '1 Auxiliar ($70k)',
            '2do Piso / Arrumar ($140k)',
            'Standby (50% AJE)',
            'Laderas',
            'Descargue',
          ].map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                categoryFilter === cat
                  ? 'bg-amber-500 text-white shadow-xs font-bold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Semáforo Predictivo de Riesgo IA (Pillar 1) */}
        <div className="mt-2.5 pt-2.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-slate-400 font-semibold flex items-center gap-1 mr-1">
              <ShieldAlert className="w-3.5 h-3.5 text-indigo-500" />
              Semáforo IA:
            </span>
            {[
              { id: 'Todos', label: 'Todos' },
              { id: 'Bajo', label: '🟢 Bajo Riesgo (Seguros)' },
              { id: 'Medio', label: '🟡 Riesgo Medio' },
              { id: 'Alto', label: '🔴 Alto Riesgo / Alertas' },
            ].map(r => (
              <button
                key={r.id}
                onClick={() => setRiskFilter(r.id as any)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  riskFilter === r.id
                    ? 'bg-slate-900 text-white shadow-xs font-bold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>

          <button
            onClick={selectAllSafeItems}
            className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-700 hover:bg-emerald-600 text-white shadow-xs transition cursor-pointer flex items-center gap-1.5"
            title="Seleccionar en lote todas las solicitudes con Score >= 80"
          >
            <Zap className="w-3.5 h-3.5 fill-current text-emerald-200" />
            <span>Seleccionar Seguros (🟢 Score ≥ 80)</span>
          </button>
        </div>

        {/* Filter / Search & Batch Selection Controls */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-col md:flex-row gap-3 items-center justify-between">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Buscar por placa, motivo, guía, orden..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {/* Batch Selection Quick Buttons */}
            <button
              onClick={selectAllStandard70k}
              className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 transition cursor-pointer"
              title="Seleccionar todos los fletes de tarifa estándar $70.000 COP"
            >
              Seleccionar Auxiliares ($70k)
            </button>

            <button
              onClick={selectedIds.size === filteredPending.length && filteredPending.length > 0 ? clearSelection : selectAllFiltered}
              className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300 transition cursor-pointer"
            >
              {selectedIds.size === filteredPending.length && filteredPending.length > 0
                ? 'Deseleccionar Todo'
                : 'Seleccionar Todos'}
            </button>

            {/* Sort Order Selector */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400 font-medium">Orden:</span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="text-xs px-2.5 py-1 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 font-semibold cursor-pointer"
              >
                <option value="recent">Más recientes</option>
                <option value="plate">Por Placa (A-Z)</option>
                <option value="cost_desc">Mayor Valor</option>
              </select>
            </div>

            {/* Carrier Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400 font-medium">Transp:</span>
              <select
                value={carrierFilter}
                onChange={e => setCarrierFilter(e.target.value)}
                className="text-xs px-2.5 py-1 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 font-semibold"
              >
                {carriers.map(c => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Batch Action Bar (When items are selected) */}
      {selectedIds.size > 0 && (
        <div className="sticky top-16 z-20 bg-slate-950 text-white rounded-2xl p-3 sm:p-4 shadow-xl border-2 border-emerald-500/80 flex flex-col sm:flex-row items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <span className="flex h-3 w-3 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-extrabold text-white">
                  {selectedIds.size} fletes seleccionados
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold font-mono">
                  {formatCOP(batchSelectedCost)} COP
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Auditor firmante: <b className="text-emerald-400">{activeAuditorName}</b>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
            <button
              onClick={clearSelection}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition cursor-pointer"
            >
              Cancelar
            </button>

            <button
              onClick={handleExecuteBatchReject}
              className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <XCircle className="w-4 h-4" />
              <span>Rechazar Selección</span>
            </button>

            <button
              onClick={handleExecuteBatchApprove}
              className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-900/30"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Aprobar {selectedIds.size} en 1 Clic</span>
            </button>
          </div>
        </div>
      )}

      {/* Grid of Pending "Ventanitas" */}
      {filteredPending.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-bold text-slate-800">¡Al día! No hay fletes pendientes con este filtro</h4>
          <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
            Todas las solicitudes del formulario han sido auditadas o coinciden con otros criterios de búsqueda.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredPending.map(flete => {
            const tariffInfo = detectTariff(flete.adicionalSolicitado, flete.motivo);
            const currentCost = getEffectiveCost(flete);
            const isSelected = selectedIds.has(flete.id);

            // Duplicate detection
            const plateCount = plateFrequencyMap[flete.placa.toUpperCase().trim()] || 1;
            const hasDuplicateRisk = plateCount > 1;

            // Audit Risk Assessment (Pillar 1)
            const risk = evaluateAuditRisk(flete, tariffInfo, plateCount);

            return (
              <div
                key={flete.id}
                id={`ventanita-${flete.id}`}
                className={`bg-white rounded-2xl border-2 transition-all duration-200 flex flex-col justify-between overflow-hidden ${
                  isSelected
                    ? 'border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                    : 'border-amber-200/80 hover:border-indigo-400 shadow-sm'
                }`}
              >
                {/* Header of Ventanita */}
                <div className="p-4 pb-3 border-b border-slate-100 bg-linear-to-r from-amber-50/40 via-white to-slate-50/30">
                  <div className="flex items-center justify-between gap-2">
                    {/* Colombian License Plate Badge + Selection Checkbox */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleSelect(flete.id)}
                        className="p-1 rounded text-slate-400 hover:text-emerald-600 transition cursor-pointer"
                        title={isSelected ? 'Deseleccionar' : 'Seleccionar para lote'}
                      >
                        {isSelected ? (
                          <CheckSquare className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                        ) : (
                          <Square className="w-5 h-5 text-slate-400" />
                        )}
                      </button>

                      <span className="px-2.5 py-1 rounded-md font-mono font-black text-xs tracking-wider bg-amber-300 text-slate-950 border-2 border-amber-400 shadow-2xs">
                        {flete.placa}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-bold border border-slate-200">
                        {flete.transportadora}
                      </span>
                    </div>

                    {/* Semáforo IA Score Badge + Status Pill */}
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`px-2 py-0.5 rounded-full font-extrabold text-[10px] border shadow-2xs ${risk.badgeClass}`}
                        title={risk.alertas.join(' • ') || 'Auditoría conforme sin anomalías'}
                      >
                        {risk.nivel === 'bajo' && '🟢 '}
                        {risk.nivel === 'medio' && '🟡 '}
                        {risk.nivel === 'alto' && '🔴 '}
                        {risk.score}/100
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-[10px] border border-amber-300">
                        Pendiente
                      </span>
                    </div>
                  </div>

                  {/* ID & Timestamp */}
                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="font-mono font-semibold text-slate-700">{flete.id}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {flete.marcaTemporal}
                    </span>
                  </div>

                  {/* Operational Risk Warnings if present */}
                  {risk.alertas.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {risk.alertas.map((alerta, aIdx) => (
                        <div
                          key={aIdx}
                          className="p-1 px-2 rounded-lg bg-rose-50/90 border border-rose-200 text-rose-800 text-[10px] font-bold flex items-center gap-1.5"
                        >
                          <AlertTriangle className="w-3 h-3 text-rose-600 shrink-0" />
                          <span>{alerta}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Body Content */}
                <div className="p-4 space-y-3.5 flex-1">
                  {/* Additional Concept Requested */}
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                      Concepto Solicitado
                    </span>
                    <span className="text-xs font-bold text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded inline-block mt-0.5 border border-indigo-100">
                      {flete.adicionalSolicitado}
                    </span>
                  </div>

                  {/* Guía & Orden de Carga Pills */}
                  <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-slate-400 block">
                        Guía
                      </span>
                      <div className="flex items-center justify-between font-mono text-xs font-bold text-slate-800">
                        <span>{flete.guia}</span>
                        <button
                          onClick={() => copyToClipboard(flete.guia, `guia-${flete.id}`)}
                          title="Copiar guía"
                          className="text-slate-400 hover:text-slate-600 p-0.5"
                        >
                          {copiedId === `guia-${flete.id}` ? (
                            <Check className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] uppercase font-semibold text-slate-400 block">
                        Orden Carga (OC)
                      </span>
                      <div className="flex items-center justify-between font-mono text-xs font-bold text-slate-800 truncate">
                        <span className="truncate">{flete.ordenCarga}</span>
                        <button
                          onClick={() => copyToClipboard(flete.ordenCarga, `oc-${flete.id}`)}
                          title="Copiar OC"
                          className="text-slate-400 hover:text-slate-600 p-0.5 shrink-0"
                        >
                          {copiedId === `oc-${flete.id}` ? (
                            <Check className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* ESPECIAL: POR QUÉ SE ESTÁ SOLICITANDO */}
                  <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-3">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-bold text-amber-900 flex items-center gap-1.5">
                        <Info className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        <span>¿Por qué se está solicitando?</span>
                      </span>

                      {/* Quick Highlight Badges */}
                      <div className="flex items-center gap-1">
                        {tariffInfo.esSegundoPiso && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-200 text-amber-900 border border-amber-300">
                            2do Piso
                          </span>
                        )}
                        {tariffInfo.esArrumador && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-900 border border-blue-200">
                            Arrumar
                          </span>
                        )}
                        {tariffInfo.esStandby && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-900 border border-purple-200">
                            Standby
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-800 leading-relaxed font-normal">
                      {flete.motivo}
                    </p>

                    {/* Operational metrics tags recognized by IA */}
                    {tariffInfo.puntosClave && tariffInfo.puntosClave.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-amber-200/60 flex items-center gap-1.5 flex-wrap text-[10px] font-semibold text-amber-950">
                        <span className="text-[9px] uppercase tracking-wider text-amber-800 font-bold mr-0.5">Puntos Clave IA:</span>
                        {tariffInfo.puntosClave.map((punto, pIdx) => (
                          <span
                            key={pIdx}
                            className="bg-white/95 px-2 py-0.5 rounded-md border border-amber-300 text-amber-950 font-bold shadow-2xs"
                          >
                            {punto}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* ESPECIAL: SOPORTES GOOGLE DRIVE */}
                  <div className="bg-slate-900 text-white rounded-xl p-3 shadow-xs">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1.5">
                        <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Soportes Documentales</span>
                      </span>
                      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/60">
                        Google Drive
                      </span>
                    </div>

                    {(() => {
                      const supportLinks = extractSupportUrls(flete.soportesUrl);
                      if (supportLinks.length === 0) {
                        return (
                          <div className="text-xs text-rose-300 bg-rose-950/40 p-2.5 rounded-lg border border-rose-800/50 flex items-center gap-2">
                            <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                            <span className="font-medium">Sin soporte adjunto en el formulario</span>
                          </div>
                        );
                      }

                      if (supportLinks.length === 1) {
                        const singleUrl = supportLinks[0];
                        return (
                          <div className="mt-1 flex items-center gap-2">
                            <a
                              href={singleUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-xs cursor-pointer"
                              title="Abrir soporte en pestaña nueva de Google Drive"
                            >
                              <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                              <span>Ver Soporte Drive</span>
                            </a>

                            <button
                              type="button"
                              onClick={() =>
                                setPreviewSupportUrl({
                                  url: singleUrl,
                                  title: `Soporte Placa ${flete.placa} • ${flete.transportadora} (${flete.id})`,
                                })
                              }
                              title="Vista previa rápida en pantalla"
                              className="px-2.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-xs"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Ver</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => copyToClipboard(singleUrl, `url-${flete.id}`)}
                              title="Copiar enlace de Google Drive"
                              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
                            >
                              {copiedId === `url-${flete.id}` ? (
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        );
                      }

                      return (
                        <div className="space-y-1.5 mt-1">
                          <span className="text-[10px] text-slate-400 font-semibold block">
                            {supportLinks.length} archivos adjuntos detectados:
                          </span>
                          {supportLinks.map((url, uIdx) => (
                            <div key={uIdx} className="flex items-center gap-1.5">
                              <a
                                href={url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex-1 inline-flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition shadow-xs cursor-pointer"
                              >
                                <span className="flex items-center gap-1 truncate">
                                  <ExternalLink className="w-3 h-3 shrink-0" />
                                  <span className="truncate">Soporte #{uIdx + 1}</span>
                                </span>
                                <span className="text-[9px] bg-emerald-800/70 px-1.5 py-0.5 rounded ml-1">Abrir ↗</span>
                              </a>

                              <button
                                type="button"
                                onClick={() =>
                                  setPreviewSupportUrl({
                                    url,
                                    title: `Soporte #${uIdx + 1} • Placa ${flete.placa} (${flete.id})`,
                                  })
                                }
                                title="Vista previa en pantalla"
                                className="p-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition cursor-pointer"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>

                              <button
                                type="button"
                                onClick={() => copyToClipboard(url, `url-${flete.id}-${uIdx}`)}
                                title="Copiar enlace"
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
                              >
                                {copiedId === `url-${flete.id}-${uIdx}` ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          ))}
                        </div>
                      );
                    })()}
                  </div>

                  {/* Official Tariff Rule & Editable Amount */}
                  <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold uppercase text-emerald-900 tracking-wider flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Tarifa Oficial AJE Aplicada</span>
                      </span>
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full">
                        {tariffInfo.nombreTarifa}
                      </span>
                    </div>

                    <p className="text-[11px] text-emerald-900 font-medium mb-2 leading-relaxed">
                      {tariffInfo.detalleCalculo}
                    </p>

                    {tariffInfo.diferenciaAhorro && tariffInfo.diferenciaAhorro > 0 && (
                      <div className="mb-2 p-1.5 bg-emerald-100/90 border border-emerald-300 rounded-lg text-[10px] font-bold text-emerald-900 flex items-center justify-between flex-wrap gap-1">
                        <span className="flex items-center gap-1">
                          <span>💰 Ahorro AJE:</span>
                          <b>{formatCOP(tariffInfo.diferenciaAhorro)}</b>
                        </span>
                        <span className="text-emerald-700 font-medium">
                          (Flete reportado: {formatCOP(tariffInfo.valorSolicitadoTransportador || 0)})
                        </span>
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      <div className="flex-1 relative">
                        <span className="absolute left-2.5 top-2 text-xs font-bold text-slate-400">$</span>
                        <input
                          type="number"
                          step="1000"
                          value={currentCost}
                          onChange={e => handleCostChange(flete.id, Number(e.target.value))}
                          className="w-full pl-6 pr-2 py-1.5 text-xs font-mono font-black text-slate-900 bg-white rounded-lg border border-emerald-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 shadow-2xs"
                        />
                      </div>
                      <span className="text-[11px] text-slate-600 font-semibold">COP a autorizar</span>
                    </div>
                  </div>
                </div>

                {/* Footer Action Buttons */}
                <div className="p-3 border-t border-slate-100 bg-slate-50/80 flex items-center gap-2">
                  {/* Approve Button stamped with active auditor */}
                  <button
                    onClick={() => onApproveWithCost(flete.id, currentCost, tariffInfo.detalleCalculo)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                    title={`Aprobar como ${activeAuditorName}`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Aprobar ({formatCOP(currentCost)})</span>
                  </button>

                  {/* Reject Button */}
                  <button
                    onClick={() => onQuickReject(flete.id)}
                    title="Rechazar flete"
                    className="p-2 rounded-xl bg-white hover:bg-rose-50 text-rose-600 border border-slate-200 hover:border-rose-300 transition cursor-pointer"
                  >
                    <XCircle className="w-4 h-4" />
                  </button>

                  {/* Detail Review Modal Button */}
                  <button
                    onClick={() => onOpenReview(flete)}
                    title="Auditoría completa con observaciones"
                    className="p-2 rounded-xl bg-white hover:bg-slate-200/70 text-slate-600 border border-slate-200 transition cursor-pointer"
                  >
                    <SlidersHorizontal className="w-4 h-4" />
                  </button>

                  {/* Copy Formal Statement Button (Pillar 3) */}
                  <button
                    onClick={() => copyFormalStatement(flete)}
                    title="Copiar Dictamen Formal para Notificar a la Transportadora"
                    className="p-2 rounded-xl bg-white hover:bg-amber-50 text-amber-700 border border-slate-200 hover:border-amber-300 transition cursor-pointer"
                  >
                    {copiedStatementId === flete.id ? (
                      <Check className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Send className="w-4 h-4 text-amber-600" />
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
      {/* Modal de Vista Previa In-App de Soportes (Google Drive Preview) */}
      {previewSupportUrl && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-4xl w-full h-[85vh] flex flex-col shadow-2xl border border-slate-300 overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-2 rounded-lg bg-emerald-600 text-white shrink-0">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold truncate">{previewSupportUrl.title}</h3>
                  <p className="text-[11px] text-slate-400 truncate max-w-md">{previewSupportUrl.url}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <a
                  href={previewSupportUrl.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Abrir en Drive ↗</span>
                </a>
                <button
                  onClick={() => safeCopyToClipboard(previewSupportUrl.url)}
                  title="Copiar enlace"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setPreviewSupportUrl(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body / Google Drive Preview Iframe */}
            <div className="flex-1 bg-slate-950 relative flex flex-col">
              <iframe
                src={getDrivePreviewUrl(previewSupportUrl.url)}
                className="w-full flex-1 border-0"
                title="Vista previa de soporte documental"
                allow="autoplay"
              />
              <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between px-4">
                <span>¿No carga la vista previa? Google Drive puede requerir que inicies sesión con tu cuenta corporativa AJE.</span>
                <a
                  href={previewSupportUrl.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 font-bold hover:underline inline-flex items-center gap-1"
                >
                  <span>Abrir archivo directamente</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
