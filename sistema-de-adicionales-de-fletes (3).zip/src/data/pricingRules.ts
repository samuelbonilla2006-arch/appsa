// Official Tariff Rules for Fletes Adicionales - Logística AJE Group
// auxiliar adicional: $70.000 COP (2 auxiliares: $140.000 COP)
// laderas: chanas: $10.000 COP | NHR: $40.000 COP | sencillo: $50.000 COP
// stanby: mitad de flete (50% de flete)
// cobro por descargue: depende del cliente (ej. Cañaveral Tuluá $340.000)

export interface TariffRule {
  id: string;
  name: string;
  category: 'auxiliar' | 'ladera' | 'standby' | 'descargue' | 'otro';
  costoBase: number;
  descripcion: string;
}

export const OFFICIAL_TARIFFS: TariffRule[] = [
  {
    id: 'aux-1',
    name: 'Auxiliar Adicional (1 persona)',
    category: 'auxiliar',
    costoBase: 70000,
    descripcion: 'Tarifa estándar: 1 auxiliar para descargue o alto volumen ($70.000 COP)',
  },
  {
    id: 'aux-2',
    name: '2 Auxiliares Adicionales (2 personas)',
    category: 'auxiliar',
    costoBase: 140000,
    descripcion: 'Tarifa doble: 2 auxiliares (2do piso / arrumar en tenderos / alto peso > 10 Tn) ($140.000 COP)',
  },
  {
    id: 'lad-chana',
    name: 'Ladera Chana',
    category: 'ladera',
    costoBase: 10000,
    descripcion: 'Vehículo Chana en ladera ($10.000 COP)',
  },
  {
    id: 'lad-nhr',
    name: 'Ladera NHR',
    category: 'ladera',
    costoBase: 40000,
    descripcion: 'Vehículo NHR en ladera ($40.000 COP)',
  },
  {
    id: 'lad-sencillo',
    name: 'Ladera Sencillo',
    category: 'ladera',
    costoBase: 50000,
    descripcion: 'Vehículo Sencillo en ladera ($50.000 COP)',
  },
  {
    id: 'standby-mitad',
    name: 'Standby / Estadía (Mitad de Flete)',
    category: 'standby',
    costoBase: 250000, // Referencia base (~flete $500k / 2)
    descripcion: '50% del valor pactado del flete',
  },
  {
    id: 'descargue-cliente',
    name: 'Cobro por Descargue (Según Cliente)',
    category: 'descargue',
    costoBase: 340000, // Ej. Cañaveral Tulua
    descripcion: 'Cobro dependiente de la tarifa del cliente/muelle (ej. Cañaveral Tuluá $340.000)',
  },
];

export interface DetectedTariff {
  costo: number;
  tarifaId: string;
  nombreTarifa: string;
  detalleCalculo: string;
  confianza: number;
  pacas?: number;
  pesoKg?: number;
  esSegundoPiso: boolean;
  esArrumador: boolean;
  esStandby: boolean;
  esLadera: boolean;
  esDescargue: boolean;
  valorSolicitadoTransportador?: number;
  diferenciaAhorro?: number;
  puntosClave: string[];
}

/**
 * Automatically detects the appropriate tariff based on the concept and justification text
 * strictly calibrated with AJE Group official policies.
 */
export function detectTariff(adicionalSolicitado: string = '', motivo: string = ''): DetectedTariff {
  const adicLower = adicionalSolicitado.toLowerCase();
  const motLower = motivo.toLowerCase();
  const combined = `${adicLower} ${motLower}`;

  const puntosClave: string[] = [];

  // 1. Extraer pacas
  let pacas: number | undefined = undefined;
  const pm =
    motivo.match(/(?:descargue de\s*|operación:\s*|operación asignada:\s*|de\s*|con\s*|g)?([0-9.]+)\s*pacas/i) ||
    motivo.match(/([0-9.]+)\s*pacas/i);
  if (pm) {
    const rawNum = pm[1].replace(/\./g, '');
    const num = parseInt(rawNum, 10);
    if (!isNaN(num) && num > 0) {
      pacas = num;
      puntosClave.push(`${num.toLocaleString('es-CO')} pacas`);
    }
  }

  // 2. Extraer peso en Kg o Toneladas
  let pesoKg: number | undefined = undefined;
  const wm =
    motivo.match(/([0-9.]+)\s*(?:kg|kilos)/i) ||
    motivo.match(/peso\s*(?:total\s*de\s*)?([0-9.]+)/i);
  if (wm) {
    const rawNum = wm[1].replace(/\./g, '');
    const num = parseInt(rawNum, 10);
    if (!isNaN(num) && num > 0) {
      pesoKg = num;
      puntosClave.push(`${num.toLocaleString('es-CO')} kg`);
    }
  }
  const tonMatch = motivo.match(/([0-9.]+)\s*(?:ton|tonelada)/i);
  if (tonMatch && !pesoKg) {
    const tonVal = parseFloat(tonMatch[1].replace(/,/g, '.'));
    if (!isNaN(tonVal)) {
      pesoKg = Math.round(tonVal * 1000);
      puntosClave.push(`${tonVal} Ton`);
    }
  }

  // Flags operativas
  const esSegundoPiso =
    combined.includes('2 piso') ||
    combined.includes('2do piso') ||
    combined.includes('segundo piso') ||
    combined.includes('2do. piso') ||
    combined.includes('escalera');

  if (esSegundoPiso) puntosClave.push('2do Piso');

  const esArrumador =
    combined.includes('arruma') ||
    combined.includes('arrumador') ||
    combined.includes('tenderos');

  if (esArrumador) puntosClave.push('Arrumador / Tenderos');

  const esStandby =
    combined.includes('standby') ||
    combined.includes('stanby') ||
    combined.includes('stadby') ||
    combined.includes('estad') ||
    combined.includes('salida tarde');

  const esDescargue =
    combined.includes('descargue') ||
    combined.includes('canaveral') ||
    combined.includes('cañaveral');

  const esLadera =
    combined.includes('ladera') ||
    combined.includes('laderas');

  // A. REGLA 1: DESCARGUE POR CLIENTE (ej. Cañaveral Tuluá $340.000)
  if (esDescargue) {
    if (combined.includes('cañaveral') || combined.includes('canaveral') || combined.includes('tulua')) {
      puntosClave.push('Muelle Cañaveral Tuluá');
      return {
        costo: 340000,
        tarifaId: 'descargue-cliente',
        nombreTarifa: 'Cobro por descargue (Cañaveral Tuluá)',
        detalleCalculo: 'Tarifa fija acordada para muelle Cañaveral Tuluá: $340.000 COP',
        confianza: 100,
        pacas,
        pesoKg,
        esSegundoPiso,
        esArrumador,
        esStandby: false,
        esLadera: false,
        esDescargue: true,
        puntosClave,
      };
    }

    const priceMatch = motivo.match(/\$\s?([0-9.]+)/);
    if (priceMatch) {
      const cleanNum = parseInt(priceMatch[1].replace(/\./g, ''), 10);
      if (!isNaN(cleanNum) && cleanNum > 0) {
        puntosClave.push(`Tarifa cliente $${cleanNum.toLocaleString('es-CO')}`);
        return {
          costo: cleanNum,
          tarifaId: 'descargue-cliente',
          nombreTarifa: 'Cobro por descargue cliente',
          detalleCalculo: `Tarifa de descargue según soporte del cliente: $${cleanNum.toLocaleString('es-CO')} COP`,
          confianza: 95,
          pacas,
          pesoKg,
          esSegundoPiso,
          esArrumador,
          esStandby: false,
          esLadera: false,
          esDescargue: true,
          puntosClave,
        };
      }
    }
  }

  // B. REGLA 2: LADERAS (Chanas $10k | NHR $40k | Sencillo $50k)
  if (esLadera) {
    if (combined.includes('chana')) {
      puntosClave.push('Ladera Chana');
      return {
        costo: 10000,
        tarifaId: 'lad-chana',
        nombreTarifa: 'Ladera Chana ($10.000)',
        detalleCalculo: 'Regla AJE: Ladera en vehículo Chana = $10.000 COP',
        confianza: 100,
        pacas,
        pesoKg,
        esSegundoPiso,
        esArrumador,
        esStandby: false,
        esLadera: true,
        esDescargue: false,
        puntosClave,
      };
    }
    if (combined.includes('sencillo')) {
      puntosClave.push('Ladera Sencillo');
      return {
        costo: 50000,
        tarifaId: 'lad-sencillo',
        nombreTarifa: 'Ladera Sencillo ($50.000)',
        detalleCalculo: 'Regla AJE: Ladera en vehículo Sencillo = $50.000 COP',
        confianza: 100,
        pacas,
        pesoKg,
        esSegundoPiso,
        esArrumador,
        esStandby: false,
        esLadera: true,
        esDescargue: false,
        puntosClave,
      };
    }
    // Default NHR o general ladera
    puntosClave.push('Ladera NHR');
    return {
      costo: 40000,
      tarifaId: 'lad-nhr',
      nombreTarifa: 'Ladera NHR ($40.000)',
      detalleCalculo: 'Regla AJE: Ladera en vehículo NHR = $40.000 COP',
      confianza: 90,
      pacas,
      pesoKg,
      esSegundoPiso,
      esArrumador,
      esStandby: false,
      esLadera: true,
      esDescargue: false,
      puntosClave,
    };
  }

  // C. REGLA 3: STANDBY / ESTADÍA (Mitad de Flete = 50%)
  if (esStandby) {
    puntosClave.push('Standby (50% Flete)');
    // Extraer monto solicitado por el transportador en el texto (ej. $487.075, $450.000, etc.)
    const amountMatch = motivo.match(/\$\s*([0-9.]+)/);
    let valorTransportador = amountMatch ? parseInt(amountMatch[1].replace(/\./g, ''), 10) : undefined;
    if (valorTransportador && isNaN(valorTransportador)) valorTransportador = undefined;

    const baseFlete = valorTransportador || 500000;
    const mitadFlete = Math.round(baseFlete / 2);
    const ahorro = valorTransportador ? valorTransportador - mitadFlete : undefined;

    return {
      costo: mitadFlete,
      tarifaId: 'standby-mitad',
      nombreTarifa: `Standby (50% de flete)`,
      detalleCalculo: valorTransportador
        ? `Regla AJE 50% de flete pactado: Valor flete $${valorTransportador.toLocaleString('es-CO')} ÷ 2 = $${mitadFlete.toLocaleString('es-CO')} COP`
        : `Regla AJE 50% de flete estándar ($500.000 base ÷ 2) = $${mitadFlete.toLocaleString('es-CO')} COP`,
      confianza: 95,
      pacas,
      pesoKg,
      esSegundoPiso,
      esArrumador,
      esStandby: true,
      esLadera: false,
      esDescargue: false,
      valorSolicitadoTransportador: valorTransportador,
      diferenciaAhorro: ahorro,
      puntosClave,
    };
  }

  // D. REGLA 4: 2 AUXILIARES ($140.000 COP = 2 x $70.000)
  const menciona2Aux =
    adicLower.includes('2') ||
    combined.includes('2 auxiliar') ||
    combined.includes('2 auxiliares') ||
    combined.includes('dos (2)') ||
    combined.includes('dos auxiliar');

  const esDobleAuxiliar = menciona2Aux || esSegundoPiso || esArrumador;

  if (esDobleAuxiliar) {
    const motivos2 = [];
    if (menciona2Aux) motivos2.push('solicitud de 2 auxiliares');
    if (esSegundoPiso) motivos2.push('entrega en 2do piso');
    if (esArrumador) motivos2.push('arrume en casa de tenderos');
    const motivoTexto = motivos2.join(' y ') || 'complejidad de la operación';

    puntosClave.push('2 Auxiliares ($140k)');
    return {
      costo: 140000,
      tarifaId: 'aux-2',
      nombreTarifa: '2 Auxiliares Adicionales ($140.000)',
      detalleCalculo: `Regla AJE: 2 auxiliares autorizados (2 × $70.000 = $140.000 COP) por ${motivoTexto}`,
      confianza: 100,
      pacas,
      pesoKg,
      esSegundoPiso,
      esArrumador,
      esStandby: false,
      esLadera: false,
      esDescargue: false,
      puntosClave,
    };
  }

  // E. REGLA 5: 1 AUXILIAR ADICIONAL ESTÁNDAR ($70.000 COP)
  puntosClave.push('1 Auxiliar ($70k)');
  return {
    costo: 70000,
    tarifaId: 'aux-1',
    nombreTarifa: 'Auxiliar Adicional ($70.000)',
    detalleCalculo: 'Tarifa estándar oficial AJE: 1 auxiliar adicional = $70.000 COP',
    confianza: 100,
    pacas,
    pesoKg,
    esSegundoPiso: false,
    esArrumador: false,
    esStandby: false,
    esLadera: false,
    esDescargue: false,
    puntosClave,
  };
}

export interface AuditRiskEvaluation {
  nivel: 'bajo' | 'medio' | 'alto';
  score: number; // 0 to 100
  color: 'emerald' | 'amber' | 'rose';
  badgeClass: string;
  recomendacion: 'preaprobar' | 'revisar' | 'rechazar';
  alertas: string[];
  fortalezas: string[];
}

/**
 * Evaluates operational fraud and compliance risk for an additional freight request
 */
export function evaluateAuditRisk(
  flete: {
    placa?: string;
    ordenCarga?: string;
    guia?: string;
    motivo?: string;
    adicionalSolicitado?: string;
    soportesUrl?: string;
    costoAdicional?: number;
  },
  detected: DetectedTariff,
  plateOccurrences: number = 1
): AuditRiskEvaluation {
  let score = 100;
  const alertas: string[] = [];
  const fortalezas: string[] = [];

  const soportes = typeof flete?.soportesUrl === 'string' ? flete.soportesUrl.trim() : '';
  const motivo = typeof flete?.motivo === 'string' ? flete.motivo.trim() : '';

  // Check 1: Soportes Google Drive
  if (!soportes) {
    score -= 30;
    alertas.push('Sin soporte adjunto en Drive');
  } else {
    fortalezas.push('Soporte fotográfico/documental adjunto');
  }

  // Check 2: Duplicidad o reincidencia de placa hoy
  if (plateOccurrences > 2) {
    score -= 35;
    alertas.push(`Placa con ${plateOccurrences} solicitudes activas`);
  } else if (plateOccurrences === 2) {
    score -= 15;
    alertas.push('Segunda solicitud de esta placa hoy');
  } else {
    fortalezas.push('Placa única en el ciclo');
  }

  // Check 3: Justificación operativa
  if (!motivo || motivo.length < 25) {
    score -= 20;
    alertas.push('Justificación operativa corta o vaga');
  } else {
    fortalezas.push('Justificación con métricas operativas');
  }

  // Check 4: Inconsistencias en 2 auxiliares
  if (detected?.tarifaId === 'aux-2') {
    if (!detected.esSegundoPiso && !detected.esArrumador && (detected.pacas || 0) < 600) {
      score -= 20;
      alertas.push('2 auxiliares sin 2do piso ni arrumador');
    } else {
      fortalezas.push('Causal técnica válida para 2 auxiliares');
    }
  }

  // Check 5: Standby
  if (detected?.esStandby) {
    if (detected.diferenciaAhorro && detected.diferenciaAhorro > 0) {
      fortalezas.push(`Aplica 50% AJE (Ahorro $${detected.diferenciaAhorro.toLocaleString('es-CO')})`);
    }
  }

  score = Math.max(15, Math.min(100, score));

  let nivel: 'bajo' | 'medio' | 'alto' = 'bajo';
  let color: 'emerald' | 'amber' | 'rose' = 'emerald';
  let badgeClass = 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-emerald-400/20';
  let recomendacion: 'preaprobar' | 'revisar' | 'rechazar' = 'preaprobar';

  if (score < 55) {
    nivel = 'alto';
    color = 'rose';
    badgeClass = 'bg-rose-50 text-rose-800 border-rose-300 ring-rose-400/20';
    recomendacion = 'revisar';
  } else if (score < 80) {
    nivel = 'medio';
    color = 'amber';
    badgeClass = 'bg-amber-50 text-amber-800 border-amber-300 ring-amber-400/20';
    recomendacion = 'revisar';
  }

  return {
    nivel,
    score,
    color,
    badgeClass,
    recomendacion,
    alertas,
    fortalezas,
  };
}

/**
 * Generates an official, legal and professional statement text ready for carrier notification
 */
export function generateFormalStatement(
  flete: {
    id: string;
    placa?: string;
    transportadora?: string;
    ordenCarga?: string;
    guia?: string;
    adicionalSolicitado?: string;
    motivo?: string;
  },
  action: 'aprobado' | 'aprobado_ajustado' | 'rechazado',
  costo: number,
  auditorName: string,
  detected?: DetectedTariff,
  customReason?: string
): string {
  const fecha = new Date().toLocaleDateString('es-CO', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const safeCosto = typeof costo === 'number' && !isNaN(costo) ? costo : 0;
  const costoFormat = `$${safeCosto.toLocaleString('es-CO')} COP`;
  const safePlaca = flete.placa || 'N/A';
  const safeTransportadora = flete.transportadora || 'CCM';
  const safeConcepto = flete.adicionalSolicitado || 'Auxiliar adicional';

  if (action === 'rechazado') {
    const causal = customReason || 'No cumple con las políticas operativas de fletes adicionales AJE Group o soporte insuficiente.';
    return `📋 *AJE GROUP LOGÍSTICA - DICTAMEN DE NO AUTORIZACIÓN*\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `• *ID Solicitud:* ${flete.id}\n` +
      `• *Vehículo / Placa:* ${safePlaca}\n` +
      `• *Transportadora:* ${safeTransportadora}\n` +
      `• *Orden de Carga:* ${flete.ordenCarga || 'N/A'}\n` +
      `• *Concepto:* ${safeConcepto}\n` +
      `• *Dictamen:* ❌ NO AUTORIZADO ($0 COP)\n` +
      `• *Causal Técnica:* ${causal}\n` +
      `• *Auditor Responsable:* ${auditorName || 'Samuel Bonilla'}\n` +
      `• *Fecha:* ${fecha}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `_Sistema Oficial de Auditoría y Control de Fletes AJE_`;
  }

  if (action === 'aprobado_ajustado' || (detected?.diferenciaAhorro && detected.diferenciaAhorro > 0)) {
    return `📋 *AJE GROUP LOGÍSTICA - DICTAMEN DE AUTORIZACIÓN CON AJUSTE*\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `• *ID Solicitud:* ${flete.id}\n` +
      `• *Vehículo / Placa:* ${safePlaca}\n` +
      `• *Transportadora:* ${safeTransportadora}\n` +
      `• *Orden de Carga:* ${flete.ordenCarga || 'N/A'}\n` +
      `• *Concepto:* ${safeConcepto}\n` +
      `• *Valor Autorizado AJE:* ✅ ${costoFormat}\n` +
      `• *Regla Aplicada:* ${detected?.detalleCalculo || 'Ajuste a tarifa oficial reglamentaria AJE'}\n` +
      `• *Auditor Responsable:* ${auditorName || 'Samuel Bonilla'}\n` +
      `• *Fecha:* ${fecha}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `_Aprobado conforme a la política corporativa de logística y transporte AJE_`;
  }

  return `📋 *AJE GROUP LOGÍSTICA - DICTAMEN DE AUTORIZACIÓN*\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `• *ID Solicitud:* ${flete.id}\n` +
    `• *Vehículo / Placa:* ${safePlaca}\n` +
    `• *Transportadora:* ${safeTransportadora}\n` +
    `• *Orden de Carga:* ${flete.ordenCarga || 'N/A'}\n` +
    `• *Concepto:* ${safeConcepto}\n` +
    `• *Valor Autorizado:* ✅ ${costoFormat}\n` +
    `• *Concepto Liquidación:* ${detected?.detalleCalculo || 'Tarifa estándar oficial AJE autorizada'}\n` +
    `• *Auditor Responsable:* ${auditorName || 'Samuel Bonilla'}\n` +
    `• *Fecha:* ${fecha}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `_Aprobado conforme a la política corporativa de logística y transporte AJE_`;
}
