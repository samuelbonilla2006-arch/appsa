import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  LayoutList,
  Kanban,
  LayoutGrid,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  PlusCircle,
  FileText,
  Filter,
  Sparkles,
  Layers,
  Users,
  ShieldAlert,
} from 'lucide-react';
import { FleteAdicional, SheetSyncConfig, EstadoFlete, AuditorProfile, MiniIaReport } from './types';
import {
  getInitialFletes,
  getStoredSheetUrl,
  syncFromGoogleSheets,
  updateFleteRecord,
  saveFletes,
  saveStoredSheetUrl,
  parseRawCSVData,
  getAuditorProfiles,
  saveAuditorProfiles,
  getActiveAuditor,
  setActiveAuditor as saveActiveAuditor,
  getStoredAppsScriptUrl,
  saveStoredAppsScriptUrl,
  postFleteToGoogleSheet,
  getStoredMiniIaReport,
  triggerAdecuarSheet,
  clearStoredOverrides,
  getLocalOverridesCount,
} from './services/sheetsSync';
import { Header } from './components/Header';
import { AuditorBar } from './components/AuditorBar';
import { MiniIaStatusBar } from './components/MiniIaStatusBar';
import { KpiMetrics } from './components/KpiMetrics';
import { ChartsDashboard } from './components/ChartsDashboard';
import { FletesTable } from './components/FletesTable';
import { KanbanBoard } from './components/KanbanBoard';
import { PendingCardsView } from './components/PendingCardsView';
import { AnomalyLeakageRadar } from './components/AnomalyLeakageRadar';
import { AjeSheetIntegrationModal } from './components/AjeSheetIntegrationModal';
import { NewFleteModal } from './components/NewFleteModal';
import { ReviewModal } from './components/ReviewModal';
import { MonthlyReportModal } from './components/MonthlyReportModal';
import { SheetSettingsModal } from './components/SheetSettingsModal';
import { ImportCsvModal } from './components/ImportCsvModal';
import { ExcelExportModal } from './components/ExcelExportModal';

export default function App() {
  const [fletes, setFletes] = useState<FleteAdicional[]>(() => getInitialFletes());
  const [viewMode, setViewMode] = useState<'pending_cards' | 'table' | 'kanban' | 'radar'>('pending_cards');
  const [statusFilter, setStatusFilter] = useState<string>('Todos');

  // Auditors state for the 3 approvers
  const [auditors, setAuditors] = useState<AuditorProfile[]>(() => getAuditorProfiles());
  const [activeAuditor, setActiveAuditor] = useState<AuditorProfile>(() => getActiveAuditor());
  const [appsScriptUrl, setAppsScriptUrl] = useState<string>(() => getStoredAppsScriptUrl());
  const [miniIaReport, setMiniIaReport] = useState<MiniIaReport | null>(() => getStoredMiniIaReport());
  const [isAdequandoSheet, setIsAdequandoSheet] = useState(false);

  // Modals state
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isAjeModalOpen, setIsAjeModalOpen] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  const [reviewFlete, setReviewFlete] = useState<FleteAdicional | null>(null);

  // Sync state
  const [syncConfig, setSyncConfig] = useState<SheetSyncConfig>({
    sheetUrl: getStoredSheetUrl(),
    appsScriptUrl: getStoredAppsScriptUrl(),
    autoSync: true,
    syncIntervalSeconds: 45,
    lastSyncTime: new Date().toLocaleTimeString('es-CO'),
    status: 'idle',
    dataSource: 'apps_script',
  });

  // Concurrency and throttle guards to prevent duplicate or excessive fetch calls
  const isSyncingRef = useRef<boolean>(false);
  const lastSyncTimestampRef = useRef<number>(0);
  const previousPendingCountRef = useRef<number | null>(null);

  const playSoftChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {}
  };

  // Online / Offline connectivity tracker
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Notification toast
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Switch active auditor
  const handleSelectAuditor = (id: string) => {
    const found = auditors.find(a => a.id === id);
    if (found) {
      setActiveAuditor(found);
      saveActiveAuditor(id);
      showToast(`Auditor en turno cambiado a: ${found.name}`, 'info');
    }
  };

  // Update auditor profile (edit name / role)
  const handleUpdateAuditor = (updated: AuditorProfile) => {
    const next = auditors.map(a => (a.id === updated.id ? updated : a));
    setAuditors(next);
    saveAuditorProfiles(next);
    if (activeAuditor.id === updated.id) {
      setActiveAuditor(updated);
    }
    showToast(`Perfil de ${updated.name} actualizado`, 'success');
  };

  // Save Apps Script Web App URL
  const handleAppsScriptUrlSaved = (url: string) => {
    setAppsScriptUrl(url);
    saveStoredAppsScriptUrl(url);
    setSyncConfig(prev => ({ ...prev, appsScriptUrl: url }));
    showToast('Enlace Web App de Google Apps Script guardado exitosamente', 'success');
  };

  // Perform sync from Google Sheets / Apps Script Web App with concurrency guard
  const handleSync = useCallback(async (forceBypass: boolean = false, isManual: boolean = false) => {
    // Guard: Don't run overlapping syncs
    if (isSyncingRef.current) {
      console.debug('[Sync Concurrencia] Sincronización en curso; ignorando llamada simultánea.');
      return;
    }

    // Throttle: Don't run automatic background syncs within 15 seconds of each other
    const now = Date.now();
    if (!forceBypass && !isManual && now - lastSyncTimestampRef.current < 15000) {
      return;
    }

    isSyncingRef.current = true;
    lastSyncTimestampRef.current = now;
    setSyncConfig(prev => ({ ...prev, status: 'syncing' }));

    const shouldBypass = forceBypass || isManual;

    try {
      const result = await syncFromGoogleSheets(syncConfig.sheetUrl, appsScriptUrl, shouldBypass);
      const prevPending = previousPendingCountRef.current;
      const currentPending = result.fletes.filter(f => f.estado === 'Pendiente').length;

      setFletes(result.fletes);
      saveFletes(result.fletes);
      if (result.miniIA) {
        setMiniIaReport(result.miniIA);
      }

      if (prevPending !== null && currentPending > prevPending) {
        const diff = currentPending - prevPending;
        playSoftChime();
        showToast(`🔔 ¡${diff} nueva(s) solicitud(es) de flete recibida(s) en tiempo real!`, 'info');
      }
      previousPendingCountRef.current = currentPending;

      const nowTime = new Date().toLocaleTimeString('es-CO');

      if (result.isOffline) {
        setSyncConfig(prev => ({
          ...prev,
          status: 'offline',
          lastSyncTime: nowTime,
          dataSource: 'local_cache',
          errorMessage: 'Sin conexión: mostrando datos locales',
        }));
        if (isManual) {
          showToast('Sin conexión a internet: mostrando datos locales', 'info');
        }
      } else if (result.source === 'local_cache') {
        setSyncConfig(prev => ({
          ...prev,
          status: 'success',
          lastSyncTime: nowTime,
          dataSource: 'local_cache',
          errorMessage: undefined,
        }));
        if (isManual) {
          showToast(`Operando con ${result.fletes.length} fletes locales auditados (27 aprobados)`, 'info');
        }
      } else {
        const speedText = result.latencyMs
          ? (result.latencyMs < 1000 ? `${result.latencyMs}ms` : `${(result.latencyMs / 1000).toFixed(1)}s`)
          : '';

        setSyncConfig(prev => ({
          ...prev,
          status: 'success',
          lastSyncTime: nowTime,
          dataSource: result.source,
          errorMessage: undefined,
          latencyMs: result.latencyMs,
        }));

        if (isManual) {
          const sourceLabel =
            result.source === 'apps_script'
              ? 'Apps Script Web App'
              : 'Google Sheet CSV';

          const aprobadosC = result.fletes.filter(f => f.estado === 'Aprobado').length;
          const pendientesC = result.fletes.filter(f => f.estado === 'Pendiente').length;
          const dupMsg = result.miniIA?.duplicadosEliminados ? ` • ${result.miniIA.duplicadosEliminados} duplicados reconciliados` : '';
          const speedMsg = speedText ? ` en ${speedText}` : '';
          showToast(`⚡ Sincronizado vía ${sourceLabel}${speedMsg}: ${aprobadosC} aprobados y ${pendientesC} pendientes${dupMsg}`, 'success');
        }
      }
    } catch (err: any) {
      const errMsg = err?.message || 'Error general al sincronizar';
      console.warn('[Sync Fallo controlado]', err);
      setSyncConfig(prev => ({
        ...prev,
        status: 'idle',
        dataSource: 'local_cache',
        errorMessage: undefined,
      }));
      if (isManual) {
        showToast(`Conexión no completada. Operando con datos locales protegidos.`, 'info');
      }
    } finally {
      isSyncingRef.current = false;
    }
  }, [syncConfig.sheetUrl, appsScriptUrl]);

  // Action to format and mark green approved rows in Google Sheets
  const handleAdecuarSheet = async () => {
    if (!appsScriptUrl || !appsScriptUrl.includes('script.google.com')) {
      showToast('Configure el Web App de Google Apps Script primero', 'info');
      setIsAjeModalOpen(true);
      return;
    }
    setIsAdequandoSheet(true);
    showToast('Adecuando y organizando Google Sheets con la Mini-IA...', 'info');
    const res = await triggerAdecuarSheet(appsScriptUrl);
    setIsAdequandoSheet(false);
    if (res.success) {
      showToast(res.message, 'success');
      handleSync(true);
    } else {
      showToast(res.message, 'error');
    }
  };

  // Reset to 100% pure official Google Sheets data (clears any local test modifications)
  const handleResetToSheets = async () => {
    setSyncConfig(prev => ({ ...prev, status: 'syncing' }));
    clearStoredOverrides();
    try {
      const { fletes: syncedFletes, miniIA } = await syncFromGoogleSheets(
        syncConfig.sheetUrl,
        appsScriptUrl,
        true,
        true
      );
      setFletes(syncedFletes);
      saveFletes(syncedFletes);
      if (miniIA) {
        setMiniIaReport(miniIA);
      }
      const nowTime = new Date().toLocaleTimeString('es-CO');
      setSyncConfig(prev => ({
        ...prev,
        status: 'success',
        lastSyncTime: nowTime,
        errorMessage: undefined,
      }));
      const aprobadosC = syncedFletes.filter(f => f.estado === 'Aprobado').length;
      showToast(`¡Restablecido exitosamente a los ${aprobadosC} fletes aprobados oficiales de Google Sheets!`, 'success');
    } catch {
      setSyncConfig(prev => ({ ...prev, status: 'error' }));
      showToast('Error al restablecer datos oficiales', 'error');
    }
  };

  // Listen to network status changes
  useEffect(() => {
    const onOnline = () => {
      setIsOnline(true);
      handleSync(true);
    };
    const onOffline = () => {
      setIsOnline(false);
    };
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [handleSync]);

  // Initial sync attempt & periodic auto-sync with offline guards
  useEffect(() => {
    previousPendingCountRef.current = fletes.filter(f => f.estado === 'Pendiente').length;
    if (typeof navigator !== 'undefined' && navigator.onLine) {
      handleSync();
    }
  }, []);

  useEffect(() => {
    if (!syncConfig.autoSync || !isOnline) return;
    const intervalMs = Math.max(15, syncConfig.syncIntervalSeconds) * 1000;
    
    // Auto sync interval - only runs when tab is active/visible
    const intervalId = setInterval(() => {
      if (typeof navigator !== 'undefined' && !navigator.onLine) return;
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      handleSync(false, false);
    }, intervalMs);

    // Sync immediately when user switches back to this tab
    const handleVisibilityChange = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible' && navigator.onLine) {
        handleSync(false, false);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [syncConfig.autoSync, syncConfig.syncIntervalSeconds, isOnline, handleSync]);

  // Quick Approval Handler
  const handleQuickApprove = (id: string) => {
    const flete = fletes.find(f => f.id === id);
    const nowStr = new Date().toLocaleString('es-CO');
    const updated = updateFleteRecord(
      id,
      {
        estado: 'Aprobado',
        revisadoPor: activeAuditor.name,
        fechaRevision: nowStr,
      },
      fletes
    );
    setFletes(updated);
    setMiniIaReport(getStoredMiniIaReport());
    showToast(`Flete ${flete?.placa || id} Aprobado por ${activeAuditor.name}`, 'success');

    // Post to Apps Script Web App if configured
    if (appsScriptUrl && flete) {
      postFleteToGoogleSheet(appsScriptUrl, {
        id,
        placa: flete.placa,
        guia: flete.guia,
        ordenCarga: flete.ordenCarga,
        estado: 'Aprobado',
        costoAdicional: flete.costoAdicional || 70000,
        revisadoPor: activeAuditor.name,
        fechaRevision: nowStr,
      });
    }
  };

  // Quick Reject Handler
  const handleQuickReject = (id: string) => {
    const flete = fletes.find(f => f.id === id);
    const nowStr = new Date().toLocaleString('es-CO');
    const updated = updateFleteRecord(
      id,
      {
        estado: 'Rechazado',
        revisadoPor: activeAuditor.name,
        fechaRevision: nowStr,
        observaciones: 'Rechazado en revisión: no cumple política tarifaria AJE',
      },
      fletes
    );
    setFletes(updated);
    setMiniIaReport(getStoredMiniIaReport());
    showToast(`Flete ${flete?.placa || id} Rechazado por ${activeAuditor.name}`, 'error');

    if (appsScriptUrl && flete) {
      postFleteToGoogleSheet(appsScriptUrl, {
        id,
        placa: flete.placa,
        guia: flete.guia,
        ordenCarga: flete.ordenCarga,
        estado: 'Rechazado',
        costoAdicional: 0,
        revisadoPor: activeAuditor.name,
        fechaRevision: nowStr,
        observaciones: 'Rechazado en revisión: no cumple política tarifaria AJE',
      });
    }
  };

  // Approval with custom/tariff cost
  const handleApproveWithCost = (id: string, cost: number, observaciones?: string) => {
    const flete = fletes.find(f => f.id === id);
    const nowStr = new Date().toLocaleString('es-CO');
    const obs = observaciones || `Aprobado con tarifa oficial AJE: $${cost.toLocaleString('es-CO')}`;

    const updated = updateFleteRecord(
      id,
      {
        estado: 'Aprobado',
        costoAdicional: cost,
        ingresoFacturado: cost,
        revisadoPor: activeAuditor.name,
        fechaRevision: nowStr,
        observaciones: obs,
      },
      fletes
    );
    setFletes(updated);
    setMiniIaReport(getStoredMiniIaReport());
    showToast(`Flete ${flete?.placa || id} Aprobado por $${cost.toLocaleString('es-CO')} COP (${activeAuditor.name})`, 'success');

    if (appsScriptUrl && flete) {
      postFleteToGoogleSheet(appsScriptUrl, {
        id,
        placa: flete.placa,
        guia: flete.guia,
        ordenCarga: flete.ordenCarga,
        estado: 'Aprobado',
        costoAdicional: cost,
        revisadoPor: activeAuditor.name,
        fechaRevision: nowStr,
        observaciones: obs,
      });
    }
  };

  // Batch Approval Handler
  const handleBatchApprove = (items: { id: string; cost: number; obs: string }[]) => {
    let currentList = fletes;
    const nowStr = new Date().toLocaleString('es-CO');

    items.forEach(item => {
      const flete = fletes.find(f => f.id === item.id);
      currentList = updateFleteRecord(
        item.id,
        {
          estado: 'Aprobado',
          costoAdicional: item.cost,
          ingresoFacturado: item.cost,
          revisadoPor: activeAuditor.name,
          fechaRevision: nowStr,
          observaciones: item.obs,
        },
        currentList
      );

      if (appsScriptUrl && flete) {
        postFleteToGoogleSheet(appsScriptUrl, {
          id: item.id,
          placa: flete.placa,
          guia: flete.guia,
          ordenCarga: flete.ordenCarga,
          estado: 'Aprobado',
          costoAdicional: item.cost,
          revisadoPor: activeAuditor.name,
          fechaRevision: nowStr,
          observaciones: item.obs,
        });
      }
    });

    setFletes(currentList);
    setMiniIaReport(getStoredMiniIaReport());
    showToast(`¡${items.length} fletes aprobados en lote por ${activeAuditor.name}!`, 'success');
  };

  // Batch Reject Handler
  const handleBatchReject = (ids: string[]) => {
    let currentList = fletes;
    const nowStr = new Date().toLocaleString('es-CO');

    ids.forEach(id => {
      const flete = fletes.find(f => f.id === id);
      currentList = updateFleteRecord(
        id,
        {
          estado: 'Rechazado',
          revisadoPor: activeAuditor.name,
          fechaRevision: nowStr,
          observaciones: 'Rechazado en lote por política tarifaria AJE',
        },
        currentList
      );

      if (appsScriptUrl && flete) {
        postFleteToGoogleSheet(appsScriptUrl, {
          id,
          placa: flete.placa,
          guia: flete.guia,
          ordenCarga: flete.ordenCarga,
          estado: 'Rechazado',
          costoAdicional: 0,
          revisadoPor: activeAuditor.name,
          fechaRevision: nowStr,
          observaciones: 'Rechazado en lote por política tarifaria AJE',
        });
      }
    });

    setFletes(currentList);
    setMiniIaReport(getStoredMiniIaReport());
    showToast(`${ids.length} fletes rechazados en lote por ${activeAuditor.name}`, 'error');
  };

  // Detailed Review Save Handler
  const handleSaveReview = (
    id: string,
    estado: EstadoFlete,
    costo: number,
    observaciones: string,
    revisadoPor: string
  ) => {
    const flete = fletes.find(f => f.id === id);
    const nowStr = new Date().toLocaleString('es-CO');
    const updated = updateFleteRecord(
      id,
      {
        estado,
        costoAdicional: costo,
        ingresoFacturado: costo,
        revisadoPor: revisadoPor || activeAuditor.name,
        observaciones,
        fechaRevision: nowStr,
      },
      fletes
    );
    setFletes(updated);
    setMiniIaReport(getStoredMiniIaReport());
    setReviewFlete(null);
    showToast(`Flete ${flete?.placa || id} actualizado a estado ${estado}`, 'success');

    if (appsScriptUrl && flete) {
      postFleteToGoogleSheet(appsScriptUrl, {
        id,
        placa: flete.placa,
        guia: flete.guia,
        ordenCarga: flete.ordenCarga,
        estado,
        costoAdicional: costo,
        revisadoPor: revisadoPor || activeAuditor.name,
        fechaRevision: nowStr,
        observaciones,
      });
    }
  };

  // Save new flete from manual form
  const handleSaveNewFlete = (newFlete: FleteAdicional) => {
    const nextList = [newFlete, ...fletes];
    setFletes(nextList);
    saveFletes(nextList);
    showToast(`Adicional ${newFlete.id} registrado correctamente`, 'success');
  };

  // Update sync config
  const handleUpdateConfig = (newUrl: string, autoSync: boolean, interval: number) => {
    setSyncConfig(prev => ({
      ...prev,
      sheetUrl: newUrl,
      autoSync,
      syncIntervalSeconds: interval,
    }));
    saveStoredSheetUrl(newUrl);
    showToast('Configuración de Google Sheets guardada', 'success');
  };

  // Handle data imported from CSV / paste
  const handleDataImported = (importedList: FleteAdicional[]) => {
    setFletes(importedList);
    saveFletes(importedList);
    showToast(`Se importaron ${importedList.length} registros del Google Sheet correctamente`, 'success');
  };

  // Handle data pasted in AJE Sheet integration modal
  const handleImportPastedData = (pastedText: string) => {
    try {
      const parsed = parseRawCSVData(pastedText);
      if (parsed.length === 0) {
        showToast('No se detectaron filas válidas en el texto pegado', 'error');
        return;
      }

      // Preserve existing approved records so pasting new pending rows keeps historical approvals
      const existingApproved = fletes.filter(f => f.estado === 'Aprobado');
      const seenMap = new Set(parsed.map(p => `${p.placa}_${p.guia || p.ordenCarga || p.id}`));
      const nonOverlappingApproved = existingApproved.filter(a => !seenMap.has(`${a.placa}_${a.guia || a.ordenCarga || a.id}`));

      const combined = [...nonOverlappingApproved, ...parsed];
      setFletes(combined);
      saveFletes(combined);
      setIsAjeModalOpen(false);
      showToast(`¡Se cargaron ${parsed.length} solicitudes del Google Sheet con éxito! (${combined.length} en total)`, 'success');
    } catch {
      showToast('Error procesando el texto pegado', 'error');
    }
  };

  const pendingCount = useMemo(() => {
    return fletes.filter(f => f.estado === 'Pendiente').length;
  }, [fletes]);

  const approvedCount = useMemo(() => {
    return fletes.filter(f => f.estado === 'Aprobado').length;
  }, [fletes]);

  const nextIdNumber = useMemo(() => {
    let max = 100;
    fletes.forEach(f => {
      const match = f.id.match(/\d+$/);
      if (match) {
        const num = parseInt(match[0], 10);
        if (num > max) max = num;
      }
    });
    return max + 1;
  }, [fletes]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-100 text-slate-900 antialiased font-sans">
      {/* Notification Toast */}
      {notification && (
        <div
          className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl shadow-lg text-xs font-semibold transition-all duration-300 border ${
            notification.type === 'success'
              ? 'bg-slate-900 text-emerald-300 border-emerald-500/50 shadow-emerald-950/20'
              : notification.type === 'error'
              ? 'bg-slate-900 text-rose-300 border-rose-500/50 shadow-rose-950/20'
              : 'bg-slate-900 text-amber-300 border-amber-500/50 shadow-amber-950/20'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Main App Header */}
      <Header
        syncConfig={syncConfig}
        onManualSync={() => handleSync(true, true)}
        onOpenNewModal={() => setIsNewModalOpen(true)}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        onOpenImportModal={() => setIsImportModalOpen(true)}
        onOpenAjeSyncModal={() => setIsAjeModalOpen(true)}
        onOpenExcelModal={() => setIsExcelModalOpen(true)}
        pendingCount={pendingCount}
      />

      {/* Multi-user Team Bar for the 3 Approvers */}
      <AuditorBar
        auditors={auditors}
        activeAuditor={activeAuditor}
        onSelectAuditor={handleSelectAuditor}
        onUpdateAuditor={handleUpdateAuditor}
        onOpenTeamHelp={() => setIsAjeModalOpen(true)}
        pendingCount={pendingCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* 🤖 Mini-IA Heurística Control & Data Quality Banner */}
        <section>
          <MiniIaStatusBar
            miniIA={miniIaReport}
            fletes={fletes}
            onManualSync={() => handleSync(true, true)}
            isSyncing={syncConfig.status === 'syncing'}
            onOpenSheetModal={() => setIsAjeModalOpen(true)}
            onAdecuarSheet={handleAdecuarSheet}
            isAdequandoSheet={isAdequandoSheet}
            onResetToSheets={handleResetToSheets}
            localOverridesCount={getLocalOverridesCount()}
          />
        </section>

        {/* KPI Metric Cards */}
        <section>
          <KpiMetrics
            fletes={fletes}
            onFilterStatus={status => {
              setStatusFilter(status);
              if (status === 'Pendiente') {
                setViewMode('pending_cards');
              } else if (viewMode === 'pending_cards') {
                setViewMode('table');
              }
            }}
            activeStatusFilter={statusFilter}
          />
        </section>

        {/* Visual Analytics & Financial Charts */}
        <section>
          <ChartsDashboard fletes={fletes} />
        </section>

        {/* Operational Management Section (Ventanitas vs Table vs Kanban) */}
        <section className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <span>Gestión de Fletes y Aprobaciones en Tiempo Real</span>
                {statusFilter !== 'Todos' && (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-bold">
                    Filtro: {statusFilter}
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-500">
                Tarifas AJE ($70k auxiliar, $140k 2do piso, laderas $10k-$50k, standby 50%) &bull; Firmado como: <b className="text-emerald-700">{activeAuditor.name}</b>
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Integration AJE Sheet Action */}
              <button
                id="btn-open-sync-aje"
                onClick={() => setIsAjeModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition cursor-pointer"
                title="Pasar fletes aprobados a Google Sheets y configurar Web App"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Web App / Script AJE</span>
              </button>

              {/* View Switcher: Ventanitas Pendientes vs Table vs Kanban */}
              <div className="flex items-center gap-1 p-1 bg-slate-200/80 rounded-xl self-start sm:self-auto text-xs font-semibold">
                <button
                  id="btn-view-pending-cards"
                  onClick={() => setViewMode('pending_cards')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    viewMode === 'pending_cards'
                      ? 'bg-amber-500 text-white shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Ver solicitudes pendientes en ventanitas individuales con detalle y soporte"
                >
                  <LayoutGrid className="w-4 h-4" />
                  <span>Ventanitas Pendientes</span>
                  {pendingCount > 0 && (
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                        viewMode === 'pending_cards'
                          ? 'bg-slate-900 text-amber-300'
                          : 'bg-amber-400 text-slate-900'
                      }`}
                    >
                      {pendingCount}
                    </span>
                  )}
                </button>

                <button
                  id="btn-view-approved"
                  onClick={() => {
                    setViewMode('table');
                    setStatusFilter('Aprobado');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    viewMode === 'table' && statusFilter === 'Aprobado'
                      ? 'bg-emerald-600 text-white shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Ver los fletes aprobados de la tabla oficial Fletes_Aprobados"
                >
                  <CheckCircle2 className={`w-4 h-4 ${viewMode === 'table' && statusFilter === 'Aprobado' ? 'text-white' : 'text-emerald-600'}`} />
                  <span>Fletes Aprobados</span>
                  {approvedCount > 0 && (
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                        viewMode === 'table' && statusFilter === 'Aprobado'
                          ? 'bg-white text-emerald-800'
                          : 'bg-emerald-100 text-emerald-800 font-bold'
                      }`}
                    >
                      {approvedCount}
                    </span>
                  )}
                </button>

                <button
                  id="btn-view-table"
                  onClick={() => {
                    setViewMode('table');
                    if (statusFilter === 'Aprobado') setStatusFilter('Todos');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    viewMode === 'table' && statusFilter !== 'Aprobado'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <LayoutList className="w-4 h-4" />
                  <span>Vista Tabla</span>
                </button>

                <button
                  id="btn-view-kanban"
                  onClick={() => setViewMode('kanban')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    viewMode === 'kanban'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Kanban className="w-4 h-4" />
                  <span>Tablero Kanban</span>
                </button>

                <button
                  id="btn-view-radar"
                  onClick={() => setViewMode('radar')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    viewMode === 'radar'
                      ? 'bg-indigo-600 text-white shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Radar de Fugas de Dinero, alertas de reincidencia y patrones anómalos"
                >
                  <ShieldAlert className="w-4 h-4" />
                  <span>Radar Fugas IA</span>
                </button>
              </div>
            </div>
          </div>

          {/* View Container */}
          {viewMode === 'radar' ? (
            <AnomalyLeakageRadar
              fletes={fletes}
              onSelectPlateFilter={plate => {
                setStatusFilter('Todos');
                setViewMode('pending_cards');
              }}
              onSelectCarrierFilter={carrier => {
                setStatusFilter('Todos');
                setViewMode('pending_cards');
              }}
            />
          ) : viewMode === 'pending_cards' ? (
            <PendingCardsView
              fletes={fletes}
              onApproveWithCost={handleApproveWithCost}
              onQuickReject={handleQuickReject}
              onOpenReview={flete => setReviewFlete(flete)}
              onBatchApprove={handleBatchApprove}
              onBatchReject={handleBatchReject}
              activeAuditorName={activeAuditor.name}
            />
          ) : viewMode === 'table' ? (
            <FletesTable
              fletes={fletes}
              onQuickApprove={handleQuickApprove}
              onQuickReject={handleQuickReject}
              onOpenReview={flete => setReviewFlete(flete)}
              statusFilter={statusFilter}
              onStatusFilterChange={setStatusFilter}
              onOpenExcelModal={() => setIsExcelModalOpen(true)}
            />
          ) : (
            <KanbanBoard
              fletes={fletes}
              onQuickApprove={handleQuickApprove}
              onQuickReject={handleQuickReject}
              onOpenReview={flete => setReviewFlete(flete)}
            />
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/80 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <p>
            Control Fletes AJE &bull; Equipo de 3 Aprobadores ({activeAuditor.name} activo)
          </p>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsExcelModalOpen(true)}
              className="text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Descargar Excel Premium
            </button>
            <button
              onClick={() => setIsAjeModalOpen(true)}
              className="text-slate-600 hover:text-slate-900 font-medium cursor-pointer"
            >
              Control Sheet AJE (Apps Script)
            </button>
            <button
              onClick={() => setIsSettingsModalOpen(true)}
              className="text-slate-600 hover:text-indigo-600 font-medium cursor-pointer"
            >
              Configurar Google Sheet
            </button>
            <button
              onClick={() => setIsReportModalOpen(true)}
              className="text-slate-600 hover:text-indigo-600 font-medium cursor-pointer"
            >
              Reportes Mensuales
            </button>
            <span>v1.2 Producción Multi-Auditor</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ExcelExportModal
        isOpen={isExcelModalOpen}
        onClose={() => setIsExcelModalOpen(false)}
        fletes={fletes}
        activeAuditorName={activeAuditor.name}
        activeAuditorEmail={activeAuditor.email}
        onSuccessToast={msg => showToast(msg, 'success')}
      />

      <NewFleteModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        onSave={handleSaveNewFlete}
        nextIdNumber={nextIdNumber}
      />

      <ReviewModal
        isOpen={!!reviewFlete}
        onClose={() => setReviewFlete(null)}
        flete={reviewFlete}
        defaultAuditorName={activeAuditor.name}
        onSaveReview={handleSaveReview}
      />

      <MonthlyReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        fletes={fletes}
      />

      <SheetSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        syncConfig={syncConfig}
        onUpdateConfig={handleUpdateConfig}
        onTestConnection={() => handleSync(true, true)}
      />

      <ImportCsvModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onDataImported={handleDataImported}
      />

      <AjeSheetIntegrationModal
        isOpen={isAjeModalOpen}
        onClose={() => setIsAjeModalOpen(false)}
        fletes={fletes}
        onImportPastedData={handleImportPastedData}
        activeAuditorName={activeAuditor.name}
        onAppsScriptUrlSaved={handleAppsScriptUrlSaved}
      />
    </div>
  );
}
