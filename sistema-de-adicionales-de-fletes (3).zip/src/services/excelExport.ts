import * as XLSX from 'xlsx';
import { FleteAdicional } from '../types';

export interface ExcelExportOptions {
  fileName?: string;
  auditorName?: string;
  auditorEmail?: string;
  includeSummarySheet?: boolean;
  includeDetailSheet?: boolean;
  includeConceptBreakdownSheet?: boolean;
  includeCarrierBreakdownSheet?: boolean;
  filterStatus?: 'Todos' | 'Aprobado' | 'Pendiente' | 'Rechazado';
}

/**
 * Genera y descarga un archivo Excel (.xlsx) Premium Corporativo de AJE Group
 * con múltiples pestañas profesionales, fórmulas, anchos de columna automáticos
 * y el detalle completo de cada adicional de flete.
 */
export function exportPremiumExcel(
  fletes: FleteAdicional[],
  options: ExcelExportOptions = {}
): { success: boolean; rowCount: number; fileName: string } {
  const {
    fileName,
    auditorName = 'Samuel Bonilla',
    auditorEmail = 'samuel.bonilla.co@ajegroup.com',
    includeSummarySheet = true,
    includeDetailSheet = true,
    includeConceptBreakdownSheet = true,
    includeCarrierBreakdownSheet = true,
    filterStatus = 'Todos',
  } = options;

  // Filtrar según estado si se especificó
  const targetFletes =
    filterStatus === 'Todos' ? fletes : fletes.filter(f => f.estado === filterStatus);

  const now = new Date();
  const fechaStr = now.toLocaleDateString('es-CO', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const horaStr = now.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });

  // Crear libro de trabajo
  const wb = XLSX.utils.book_new();

  // --------------------------------------------------------------------------
  // HOJA 1: RESUMEN EJECUTIVO & KPIs CORPORATIVOS
  // --------------------------------------------------------------------------
  if (includeSummarySheet) {
    const totalSolicitudes = targetFletes.length;
    const aprobados = targetFletes.filter(f => f.estado === 'Aprobado');
    const pendientes = targetFletes.filter(f => f.estado === 'Pendiente');
    const rechazados = targetFletes.filter(f => f.estado === 'Rechazado');

    const montoTotalAprobado = aprobados.reduce((sum, f) => sum + (f.costoAdicional || 0), 0);
    const montoEstimadoPendiente = pendientes.reduce((sum, f) => sum + (f.costoAdicional || 0), 0);
    const ticketPromedioAprobado =
      aprobados.length > 0 ? Math.round(montoTotalAprobado / aprobados.length) : 0;

    // Agrupación por Concepto
    const conceptoMap: Record<
      string,
      { total: number; aprobados: number; pendientes: number; rechazados: number; montoAprobado: number }
    > = {};

    targetFletes.forEach(f => {
      const c = f.adicionalSolicitado || 'Otros Adicionales';
      if (!conceptoMap[c]) {
        conceptoMap[c] = { total: 0, aprobados: 0, pendientes: 0, rechazados: 0, montoAprobado: 0 };
      }
      conceptoMap[c].total += 1;
      if (f.estado === 'Aprobado') {
        conceptoMap[c].aprobados += 1;
        conceptoMap[c].montoAprobado += f.costoAdicional || 0;
      } else if (f.estado === 'Pendiente') {
        conceptoMap[c].pendientes += 1;
      } else if (f.estado === 'Rechazado') {
        conceptoMap[c].rechazados += 1;
      }
    });

    // Agrupación por Transportadora
    const carrierMap: Record<string, { total: number; aprobados: number; montoAprobado: number }> = {};
    targetFletes.forEach(f => {
      const t = f.transportadora || 'CCM';
      if (!carrierMap[t]) {
        carrierMap[t] = { total: 0, aprobados: 0, montoAprobado: 0 };
      }
      carrierMap[t].total += 1;
      if (f.estado === 'Aprobado') {
        carrierMap[t].aprobados += 1;
        carrierMap[t].montoAprobado += f.costoAdicional || 0;
      }
    });

    const summaryRows: any[][] = [
      ['AJE GROUP — OPERACIONES Y LOGÍSTICA COLOMBIA'],
      ['CONTROL Y LIQUIDACIÓN CORPORATIVA DE ADICIONALES DE FLETES'],
      ['INFORME EJECUTIVO DE GESTIÓN Y AUDITORÍA LOGÍSTICA'],
      [],
      ['INFORMACIÓN DEL REPORTE'],
      ['Fecha de Emisión:', `${fechaStr} a las ${horaStr}`],
      ['Supervisor / Auditor:', `${auditorName} (${auditorEmail})`],
      ['Filtro de Datos:', filterStatus === 'Todos' ? 'Base Completa (Todos los Estados)' : `Solo ${filterStatus}`],
      ['Fuente de Datos:', 'Google Sheets & Apps Script en Tiempo Real (2-Way Sync)'],
      [],
      ['INDICADORES CLAVE DE GESTIÓN (KPIS)'],
      ['Métrica', 'Cantidad', 'Monto Total (COP)', 'Observación'],
      ['Total Solicitudes Registradas', totalSolicitudes, montoTotalAprobado + montoEstimadoPendiente, '100% de radicados'],
      ['Fletes y Adicionales Aprobados', aprobados.length, montoTotalAprobado, 'Listos para liquidación contable'],
      ['Solicitudes Pendientes de Revisión', pendientes.length, montoEstimadoPendiente, 'Pendiente validación de soporte'],
      ['Solicitudes Rechazadas / No Procede', rechazados.length, 0, 'No cumplen política AJE'],
      ['Costo Promedio por Adicional Aprobado', aprobados.length > 0 ? 1 : 0, ticketPromedioAprobado, 'Ticket promedio por flete'],
      [],
      ['DISTRIBUCIÓN POR CONCEPTO DE ADICIONAL'],
      ['Concepto / Tipo de Servicio', 'Total Solicitudes', 'Aprobados', 'Pendientes', 'Rechazados', 'Total Liquidado (COP)', '% del Gasto Aprobado'],
    ];

    Object.entries(conceptoMap)
      .sort((a, b) => b[1].montoAprobado - a[1].montoAprobado)
      .forEach(([concepto, stats]) => {
        const pct = montoTotalAprobado > 0 ? ((stats.montoAprobado / montoTotalAprobado) * 100).toFixed(1) + '%' : '0%';
        summaryRows.push([
          concepto,
          stats.total,
          stats.aprobados,
          stats.pendientes,
          stats.rechazados,
          stats.montoAprobado,
          pct,
        ]);
      });

    summaryRows.push([]);
    summaryRows.push(['DISTRIBUCIÓN POR EMPRESA TRANSPORTADORA']);
    summaryRows.push(['Empresa Transportadora', 'Total Solicitudes', 'Fletes Aprobados', 'Monto Liquidado (COP)', '% Participación']);

    Object.entries(carrierMap)
      .sort((a, b) => b[1].montoAprobado - a[1].montoAprobado)
      .forEach(([carrier, stats]) => {
        const pct = montoTotalAprobado > 0 ? ((stats.montoAprobado / montoTotalAprobado) * 100).toFixed(1) + '%' : '0%';
        summaryRows.push([
          carrier,
          stats.total,
          stats.aprobados,
          stats.montoAprobado,
          pct,
        ]);
      });

    const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);

    // Configurar anchos de columna para visualización ejecutiva
    wsSummary['!cols'] = [
      { wch: 38 }, // Concepto / Métrica
      { wch: 18 }, // Cantidad / Total
      { wch: 24 }, // Monto Total (COP)
      { wch: 35 }, // Observación / %
      { wch: 16 },
      { wch: 22 },
      { wch: 22 },
    ];

    XLSX.utils.book_append_sheet(wb, wsSummary, 'Resumen Ejecutivo');
  }

  // --------------------------------------------------------------------------
  // HOJA 2: DETALLE COMPLETO DE CADA ADICIONAL (BASE MAESTRA)
  // --------------------------------------------------------------------------
  if (includeDetailSheet) {
    const detailHeaders = [
      'ID Flete Oficial',
      'ID Radicado Solicitud',
      'Estado Auditoría',
      'Placa Vehicular',
      'Número de Guía',
      'Orden de Carga (OC)',
      'Empresa Transportadora',
      'Concepto Adicional',
      'Monto Liquidado (COP)',
      'Fecha Solicitud',
      'Hora Solicitud',
      'Fecha Resolución',
      'Auditor / Aprobador',
      'Motivo / Justificación / Observaciones',
      'Enlace Soporte (Google Drive)',
      'Canal de Entrada',
    ];

    const detailRows: any[][] = [detailHeaders];

    targetFletes.forEach((f, idx) => {
      const idOficial = f.id.startsWith('FL-')
        ? f.id
        : `FL-2026-${('0000' + (idx + 1)).slice(-4)}`;

      const horaVal =
        f.marcaTemporal && f.marcaTemporal.length > 15
          ? f.marcaTemporal.substring(11, 16)
          : '10:00';
      const rawSoporte = f.soportesUrl || (f as any).soportes || '';
      let soporteCell: any = rawSoporte;
      if (rawSoporte && (rawSoporte.includes('http://') || rawSoporte.includes('https://'))) {
        const firstUrl = rawSoporte.split(/[\s,;\n\r]+/)[0];
        soporteCell = {
          f: `HYPERLINK("${firstUrl}", "Ver Soporte Drive ↗")`,
          v: firstUrl,
          t: 's',
        };
      }

      detailRows.push([
        idOficial,
        f.id || `SOL-${idx + 1}`,
        f.estado || 'Pendiente',
        (f.placa || '').toUpperCase().trim(),
        f.guia || '',
        f.ordenCarga || '',
        f.transportadora || 'CCM',
        f.adicionalSolicitado || 'Auxiliar adicional',
        Number(f.costoAdicional) || 0,
        f.marcaTemporal ? f.marcaTemporal.substring(0, 10) : '',
        horaVal,
        f.fechaRevision ? f.fechaRevision.substring(0, 10) : (f.estado === 'Aprobado' ? (f.marcaTemporal ? f.marcaTemporal.substring(0, 10) : '') : ''),
        f.revisadoPor || (f.estado === 'Aprobado' ? auditorEmail : 'Pendiente de asignación'),
        f.motivo || f.observaciones || `${f.adicionalSolicitado || 'Adicional'} para placa ${(f.placa || '').toUpperCase()}`,
        soporteCell,
        f.origen === 'google_sheets' ? 'Google Sheet / Form' : 'Dashboard Directo',
      ]);
    });

    const wsDetail = XLSX.utils.aoa_to_sheet(detailRows);

    // Ajuste de columnas
    wsDetail['!cols'] = [
      { wch: 18 }, // ID Flete
      { wch: 22 }, // ID Radicado
      { wch: 16 }, // Estado
      { wch: 16 }, // Placa
      { wch: 16 }, // Guía
      { wch: 18 }, // Orden Carga
      { wch: 22 }, // Transportadora
      { wch: 26 }, // Concepto
      { wch: 22 }, // Monto COP
      { wch: 16 }, // Fecha Solicitud
      { wch: 14 }, // Hora Solicitud
      { wch: 16 }, // Fecha Resolución
      { wch: 32 }, // Auditor
      { wch: 45 }, // Motivo / Justificación
      { wch: 40 }, // Enlace Soporte Drive
      { wch: 20 }, // Canal
    ];

    XLSX.utils.book_append_sheet(wb, wsDetail, 'Detalle de Adicionales');

    // --------------------------------------------------------------------------
    // HOJA ADICIONAL: FLETES APROBADOS (Exclusivo Tabla Fletes_Aprobados)
    // --------------------------------------------------------------------------
    const aprobadosList = targetFletes.filter(f => f.estado === 'Aprobado');
    const aprobHeaders = [
      'ID Flete Oficial',
      'ID Radicado',
      'Placa Vehicular',
      'Número de Guía',
      'Orden de Carga (OC)',
      'Empresa Transportadora',
      'Concepto Aprobado',
      'Gasto Aprobado (COP)',
      'Fecha Aprobación',
      'Auditor / Aprobador',
      'Observaciones / Justificación',
      'Canal'
    ];
    const aprobRows: any[][] = [
      ['AJE GROUP — TABLA OFICIAL DE FLETES APROBADOS (LIQUIDACIÓN CONTABLE)'],
      [`Total Aprobados: ${aprobadosList.length} | Gasto Aprobado Total: COP $${aprobadosList.reduce((s, f) => s + (f.costoAdicional || 0), 0).toLocaleString('es-CO')}`],
      [],
      aprobHeaders
    ];
    let sumaAprobados = 0;
    aprobadosList.forEach((f, idx) => {
      const idOficial = f.id.startsWith('FL-') ? f.id : `FL-2026-${('0000' + (idx + 1)).slice(-4)}`;
      const costo = Number(f.costoAdicional) || 0;
      sumaAprobados += costo;
      aprobRows.push([
        idOficial,
        f.id,
        (f.placa || '').toUpperCase().trim(),
        f.guia || '',
        f.ordenCarga || '',
        f.transportadora || 'CCM',
        f.adicionalSolicitado || 'Auxiliar adicional',
        costo,
        f.fechaRevision ? f.fechaRevision.substring(0, 10) : (f.marcaTemporal ? f.marcaTemporal.substring(0, 10) : ''),
        f.revisadoPor || auditorEmail,
        f.motivo || f.observaciones || 'Aprobado según tabla Fletes_Aprobados',
        'Fletes_Aprobados'
      ]);
    });
    aprobRows.push([]);
    aprobRows.push(['TOTAL GASTOS APROBADOS', '', '', '', '', '', '', sumaAprobados, '', '', '', '']);

    const wsAprob = XLSX.utils.aoa_to_sheet(aprobRows);
    wsAprob['!cols'] = [
      { wch: 18 }, { wch: 20 }, { wch: 16 }, { wch: 16 }, { wch: 18 },
      { wch: 22 }, { wch: 24 }, { wch: 22 }, { wch: 16 }, { wch: 32 },
      { wch: 45 }, { wch: 18 }
    ];
    XLSX.utils.book_append_sheet(wb, wsAprob, 'Fletes Aprobados');

    // --------------------------------------------------------------------------
    // HOJA ADICIONAL: FLETES PENDIENTES (Respuestas de formulario 1)
    // --------------------------------------------------------------------------
    const pendientesList = targetFletes.filter(f => f.estado === 'Pendiente');
    const pendHeaders = [
      'ID Radicado',
      'Placa Vehicular',
      'Número de Guía',
      'Orden de Carga (OC)',
      'Empresa Transportadora',
      'Concepto Solicitado',
      'Tarifa Estimada (COP)',
      'Fecha Solicitud',
      'Motivo / Justificación de la Solicitud',
      'Enlace Soporte Google Drive',
      'Estado'
    ];
    const pendRows: any[][] = [
      ['AJE GROUP — SOLICITUDES PENDIENTES DE AUDITORÍA (RESPUESTAS DE FORMULARIO 1)'],
      [`Total Pendientes: ${pendientesList.length} | Gasto Estimado Proyectado: COP $${pendientesList.reduce((s, f) => s + (f.costoAdicional || 0), 0).toLocaleString('es-CO')}`],
      [],
      pendHeaders
    ];
    let sumaPendientes = 0;
    pendientesList.forEach(f => {
      const costo = Number(f.costoAdicional) || 0;
      sumaPendientes += costo;
      pendRows.push([
        f.id,
        (f.placa || '').toUpperCase().trim(),
        f.guia || '',
        f.ordenCarga || '',
        f.transportadora || 'CCM',
        f.adicionalSolicitado || 'Auxiliar adicional',
        costo,
        f.marcaTemporal ? f.marcaTemporal.substring(0, 10) : '',
        f.motivo || f.observaciones || '',
        f.soportesUrl || (f as any).soportes || '',
        'Pendiente'
      ]);
    });
    pendRows.push([]);
    pendRows.push(['TOTAL GASTO ESTIMADO PENDIENTE', '', '', '', '', '', sumaPendientes, '', '', '', '']);

    const wsPend = XLSX.utils.aoa_to_sheet(pendRows);
    wsPend['!cols'] = [
      { wch: 20 }, { wch: 16 }, { wch: 16 }, { wch: 18 }, { wch: 22 },
      { wch: 24 }, { wch: 22 }, { wch: 16 }, { wch: 50 }, { wch: 40 },
      { wch: 14 }
    ];
    XLSX.utils.book_append_sheet(wb, wsPend, 'Fletes Pendientes');
  }

  // --------------------------------------------------------------------------
  // HOJA 3: DESGLOSE ANALÍTICO POR CONCEPTO ADICIONAL
  // --------------------------------------------------------------------------
  if (includeConceptBreakdownSheet) {
    const conceptStats: Record<
      string,
      {
        total: number;
        aprobados: number;
        pendientes: number;
        rechazados: number;
        montoTotalAprobado: number;
        costos: number[];
      }
    > = {};

    targetFletes.forEach(f => {
      const c = f.adicionalSolicitado || 'Otro adicional';
      if (!conceptStats[c]) {
        conceptStats[c] = {
          total: 0,
          aprobados: 0,
          pendientes: 0,
          rechazados: 0,
          montoTotalAprobado: 0,
          costos: [],
        };
      }
      conceptStats[c].total += 1;
      if (f.estado === 'Aprobado') {
        conceptStats[c].aprobados += 1;
        conceptStats[c].montoTotalAprobado += f.costoAdicional || 0;
        conceptStats[c].costos.push(f.costoAdicional || 0);
      } else if (f.estado === 'Pendiente') {
        conceptStats[c].pendientes += 1;
      } else if (f.estado === 'Rechazado') {
        conceptStats[c].rechazados += 1;
      }
    });

    const conceptRows: any[][] = [
      ['AJE GROUP — ANÁLISIS DE COSTOS POR TIPO DE ADICIONAL'],
      ['Evaluación de tarifas, frecuencias de cobro y montos totales liquidados'],
      [],
      [
        'Concepto Adicional',
        'Total Casos',
        'Casos Aprobados',
        'Casos Pendientes',
        'Casos Rechazados',
        '% Aprobación',
        'Costo Mínimo Aprobado (COP)',
        'Costo Promedio (COP)',
        'Costo Máximo Aprobado (COP)',
        'Gasto Total Aprobado (COP)',
      ],
    ];

    Object.entries(conceptStats)
      .sort((a, b) => b[1].montoTotalAprobado - a[1].montoTotalAprobado)
      .forEach(([concepto, data]) => {
        const minCost = data.costos.length > 0 ? Math.min(...data.costos) : 0;
        const maxCost = data.costos.length > 0 ? Math.max(...data.costos) : 0;
        const avgCost =
          data.costos.length > 0
            ? Math.round(data.montoTotalAprobado / data.costos.length)
            : 0;
        const pctAprob =
          data.total > 0 ? ((data.aprobados / data.total) * 100).toFixed(1) + '%' : '0%';

        conceptRows.push([
          concepto,
          data.total,
          data.aprobados,
          data.pendientes,
          data.rechazados,
          pctAprob,
          minCost,
          avgCost,
          maxCost,
          data.montoTotalAprobado,
        ]);
      });

    const wsConcept = XLSX.utils.aoa_to_sheet(conceptRows);
    wsConcept['!cols'] = [
      { wch: 28 }, // Concepto
      { wch: 14 }, // Total
      { wch: 16 }, // Aprobados
      { wch: 16 }, // Pendientes
      { wch: 16 }, // Rechazados
      { wch: 16 }, // % Aprob
      { wch: 24 }, // Min
      { wch: 22 }, // Avg
      { wch: 24 }, // Max
      { wch: 26 }, // Total COP
    ];

    XLSX.utils.book_append_sheet(wb, wsConcept, 'Análisis por Concepto');
  }

  // --------------------------------------------------------------------------
  // HOJA 4: LIQUIDACIÓN POR EMPRESA TRANSPORTADORA
  // --------------------------------------------------------------------------
  if (includeCarrierBreakdownSheet) {
    const carrierDetails: Record<
      string,
      {
        totalFletes: number;
        aprobados: number;
        pendientes: number;
        rechazados: number;
        totalMontoAprobado: number;
        placasUnicas: Set<string>;
        conceptos: Record<string, number>;
      }
    > = {};

    targetFletes.forEach(f => {
      const transp = f.transportadora || 'CCM';
      if (!carrierDetails[transp]) {
        carrierDetails[transp] = {
          totalFletes: 0,
          aprobados: 0,
          pendientes: 0,
          rechazados: 0,
          totalMontoAprobado: 0,
          placasUnicas: new Set(),
          conceptos: {},
        };
      }

      const cd = carrierDetails[transp];
      cd.totalFletes += 1;
      if (f.placa) cd.placasUnicas.add(f.placa.toUpperCase().trim());

      const c = f.adicionalSolicitado || 'Otros';
      cd.conceptos[c] = (cd.conceptos[c] || 0) + 1;

      if (f.estado === 'Aprobado') {
        cd.aprobados += 1;
        cd.totalMontoAprobado += f.costoAdicional || 0;
      } else if (f.estado === 'Pendiente') {
        cd.pendientes += 1;
      } else if (f.estado === 'Rechazado') {
        cd.rechazados += 1;
      }
    });

    const carrierRows: any[][] = [
      ['AJE GROUP — LIQUIDACIÓN POR EMPRESA TRANSPORTADORA'],
      ['Resumen consolidado para conciliación y pago a empresas de transporte'],
      [],
      [
        'Empresa Transportadora',
        'Total Fletes',
        'Vehículos Distintos (Placas)',
        'Fletes Aprobados',
        'Fletes Pendientes',
        'Fletes Rechazados',
        'Monto Total Liquidado (COP)',
        'Top Concepto Cobrado',
      ],
    ];

    Object.entries(carrierDetails)
      .sort((a, b) => b[1].totalMontoAprobado - a[1].totalMontoAprobado)
      .forEach(([transp, data]) => {
        // Encontrar concepto más frecuente
        let topConcept = 'N/A';
        let topCount = 0;
        Object.entries(data.conceptos).forEach(([cName, cnt]) => {
          if (cnt > topCount) {
            topCount = cnt;
            topConcept = `${cName} (${cnt})`;
          }
        });

        carrierRows.push([
          transp,
          data.totalFletes,
          data.placasUnicas.size,
          data.aprobados,
          data.pendientes,
          data.rechazados,
          data.totalMontoAprobado,
          topConcept,
        ]);
      });

    const wsCarrier = XLSX.utils.aoa_to_sheet(carrierRows);
    wsCarrier['!cols'] = [
      { wch: 26 }, // Transportadora
      { wch: 14 }, // Total
      { wch: 26 }, // Placas
      { wch: 16 }, // Aprobados
      { wch: 16 }, // Pendientes
      { wch: 16 }, // Rechazados
      { wch: 28 }, // Monto COP
      { wch: 32 }, // Top Concepto
    ];

    XLSX.utils.book_append_sheet(wb, wsCarrier, 'Liquidación Transportadoras');
  }

  // Nombre final del archivo
  const dateStamp = now.toISOString().slice(0, 10);
  const resolvedFileName =
    fileName ||
    `AJE_Group_Reporte_Premium_Fletes_${dateStamp}.xlsx`;

  // Descarga directa en el navegador
  XLSX.writeFile(wb, resolvedFileName);

  return {
    success: true,
    rowCount: targetFletes.length,
    fileName: resolvedFileName,
  };
}
