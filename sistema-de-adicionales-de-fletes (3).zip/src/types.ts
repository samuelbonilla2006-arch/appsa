export type EstadoFlete = 'Pendiente' | 'Aprobado' | 'Rechazado';

export interface FleteAdicional {
  id: string; // Radicado, e.g. "SOL-2026-0002"
  idFlete?: string; // Oficial AJE, e.g. "FL-2026-0003"
  marcaTemporal: string; // e.g. "15/9/2026 16:32:19"
  timestamp?: string; // Raw timestamp from sheet
  fechaIso: string; // e.g. "2026-09-15"
  horaSolicitud?: string;
  transportadora: string; // e.g. "CCM"
  placa: string; // e.g. "KUL753"
  adicionalSolicitado: string; // e.g. "Auxiliar adicional", "Cobro por descargue"
  adicional?: string; // Alias for concept
  guia: string; // e.g. "100391"
  ordenCarga: string; // e.g. "CL26258069"
  motivo: string; // Justificación con peso, pacas, etc.
  soportesUrl: string; // Google Drive link
  soportes?: string;
  soporte?: string;
  soporteUrl?: string;
  monto?: number;
  costoAdicional: number; // Costo / Gasto adicional en COP (e.g. 85000)
  ingresoFacturado: number; // Valor cobrado o transferido (e.g. 110000)
  estado: EstadoFlete;
  revisadoPor?: string;
  aprobadoPor?: string;
  fechaRevision?: string;
  fechaAprobacion?: string;
  observaciones?: string;
  canal?: string;
  origen: 'google_sheets' | 'formulario_interno' | 'csv_importado';
  duplicadoSospechoso?: boolean;
  filaHoja?: number;
  hojaOrigen?: string;
}

export type DataSourceType = 'apps_script' | 'sheet_csv' | 'local_cache';

export interface SheetSyncConfig {
  sheetUrl: string;
  appsScriptUrl?: string;
  autoSync: boolean;
  syncIntervalSeconds: number;
  lastSyncTime: string | null;
  status: 'idle' | 'syncing' | 'success' | 'error' | 'offline';
  dataSource?: DataSourceType;
  errorMessage?: string;
  latencyMs?: number;
}

export interface AuditorProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  avatarColor: string;
}

export interface MonthlyReportSummary {
  mes: string; // e.g. "2026-09"
  mesNombre: string; // e.g. "Septiembre 2026"
  totalSolicitudes: number;
  pendientes: number;
  aprobados: number;
  rechazados: number;
  costoTotalAprobado: number;
  costoTotalPendiente: number;
  ahorroPorRechazo: number;
  ingresoTotalFacturado: number;
  margenOperacional: number;
  porcentajeMargen: number;
  porTransportadora: { [key: string]: { cantidad: number; aprobado: number; rechazado: number; costo: number } };
  porAdicional: { [key: string]: { cantidad: number; total: number } };
  porPlaca: { [key: string]: { cantidad: number; total: number; aprobados: number } };
}

export interface MiniIaReport {
  version: string;
  scoreSalud: number;
  placasNormalizadas: number;
  guiasCorregidas: number;
  tarifasCalculadas: number;
  enlacesDriveSanados: number;
  anomalias: number;
  reconciliadosAprobados: number;
  totalAprobadosReales: number;
  totalPendientesReales: number;
  duplicadosEliminados: number;
  estado: string;
  ultimaAuditoria: string;
  detallesReconciliacion?: string;
}
