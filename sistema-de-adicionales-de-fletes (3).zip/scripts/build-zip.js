import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

async function packageZip() {
  console.log('📦 Starting Netlify ZIP packaging...');
  const distDir = path.resolve(import.meta.dirname, '../dist');
  
  if (!fs.existsSync(distDir)) {
    console.error('❌ dist/ directory does not exist! Please run "npm run build" first.');
    process.exit(1);
  }

  const zip = new JSZip();

  function addDirToZip(dirPath, zipFolder) {
    const items = fs.readdirSync(dirPath);
    for (const item of items) {
      const fullPath = path.join(dirPath, item);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        const subFolder = zipFolder.folder(item);
        addDirToZip(fullPath, subFolder);
      } else {
        const content = fs.readFileSync(fullPath);
        zipFolder.file(item, content);
      }
    }
  }

  addDirToZip(distDir, zip);

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  const outputZipPath = path.resolve(import.meta.dirname, '../public/aje-fletes-netlify.zip');
  fs.writeFileSync(outputZipPath, zipBuffer);

  const rootZipPath = path.resolve(import.meta.dirname, '../aje-fletes-netlify.zip');
  fs.writeFileSync(rootZipPath, zipBuffer);

  const sizeKb = Math.round(zipBuffer.length / 1024);
  console.log(`✅ Netlify ZIP generated successfully!`);
  console.log(`   -> File 1: public/aje-fletes-netlify.zip (${sizeKb} KB)`);
  console.log(`   -> File 2: aje-fletes-netlify.zip (${sizeKb} KB)`);
}

packageZip().catch(err => {
  console.error('Error generating zip:', err);
  process.exit(1);
});
